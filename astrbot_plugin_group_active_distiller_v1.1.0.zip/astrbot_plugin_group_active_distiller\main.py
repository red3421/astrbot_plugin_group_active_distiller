# -*- coding: utf-8 -*-
"""群友主动蒸馏器 · AstrBot 插件主入口。

架构：
    main.py            命令 / Web API / 定时任务 / 画像投放
    core/store.py      SQLite 存储
    core/collector.py  主动搜群 + 分页拉历史（OneBot v11）
    core/distiller.py  抽样 + 分批 + LLM + 合并
    core/prompts.py    蒸馏提示词与 system prompt 模板
    pages/蒸馏台/       AstrBot 插件拓展页（可视化后台）
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path
from typing import Any, Optional

from astrbot.api import AstrBotConfig, logger
from astrbot.api.event import AstrMessageEvent, MessageChain, filter
from astrbot.api.star import Context, Star, register

try:
    from astrbot.api.event.filter import PermissionType
except Exception:  # 老版本兜底
    from astrbot.api.provider import Provider  # noqa: F401

    class PermissionType:  # type: ignore
        ADMIN = "admin"
        MEMBER = "member"

try:
    from quart import request as quart_request
except Exception:  # 本地自测时没有 quart
    quart_request = None  # type: ignore

from .core.collector import CollectorError, GroupCollector
from .core.distiller import DistillError, PersonaDistiller
from .core.prompts import render_system_prompt
from .core.store import DistillerStore

PLUGIN_NAME = "astrbot_plugin_group_active_distiller"
PAGE_PREFIX = f"/{PLUGIN_NAME}/page"

_ONE_SHOT = object()


# ---------------------------------------------------------------------- #
#  配置读取工具
# ---------------------------------------------------------------------- #
def _cfg(config: Any, key: str, default: Any = None) -> Any:
    try:
        value = config.get(key, default)
    except Exception:
        try:
            value = getattr(config, key, default)
        except Exception:
            value = default
    return default if value is None else value


def _split_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    if isinstance(value, str):
        return [v.strip() for v in value.replace("，", ",").replace(";", ",").split(",") if v.strip()]
    return []


# ---------------------------------------------------------------------- #
#  数据目录解析
# ---------------------------------------------------------------------- #
LEGACY_DB_NAME = "distiller.db"


def _astrbot_data_root() -> Optional[Path]:
    """定位 AstrBot 的 data 根目录（<root>/data）。

    优先级：
        1. 环境变量 ASTRBOT_DATA_DIR / ASTRBOT_ROOT / ASTRBOT_HOME
        2. astrbot.core.utils.astrbot_path 提供的路径函数
        3. astrbot 包安装位置的上一级目录推导
        4. 插件目录向上遍历，找到同时含 data/plugins 的目录
    全部失败时返回 None（调用方退化为插件目录）。
    """
    for env_name in ("ASTRBOT_DATA_DIR",):
        raw = os.environ.get(env_name)
        if raw:
            return Path(raw)
    for env_name in ("ASTRBOT_ROOT", "ASTRBOT_HOME"):
        raw = os.environ.get(env_name)
        if raw:
            return Path(raw) / "data"

    try:  # AstrBot 4.x 官方路径工具
        from astrbot.core.utils import astrbot_path as _ap  # type: ignore

        for fn_name in (
            "get_astrbot_data_path",
            "get_data_path",
            "get_astrbot_root_path",
            "get_astrbot_path",
        ):
            fn = getattr(_ap, fn_name, None)
            if not callable(fn):
                continue
            try:
                resolved = Path(str(fn()))
            except Exception:
                continue
            if fn_name in ("get_astrbot_root_path", "get_astrbot_path"):
                resolved = resolved / "data"
            return resolved
    except Exception:
        pass

    try:  # 从安装位置推导：<root>/astrbot/core/utils/astrbot_path.py
        import astrbot as _astrbot_pkg  # type: ignore

        pkg_dir = Path(str(getattr(_astrbot_pkg, "__file__", ""))).parent
        for parent in pkg_dir.parents:
            if (parent / "data").is_dir():
                return parent / "data"
    except Exception:
        pass

    for parent in Path(__file__).resolve().parents:  # 就地在 astrbot 树内运行
        if (parent / "data" / "plugins").is_dir() or (parent / "plugins").is_dir():
            return parent / "data" if (parent / "data").is_dir() else parent
    return None


def _resolve_data_dir(plugin_name: str) -> Path:
    """持久化目录：data/plugin_data/<plugin_name>。

    规则要求用户数据统一落在 plugin_data 下，便于迁移与审计；老版本写在
    插件目录 data/ 下的库会在首次启动时自动搬过来。
    """
    plugin_dir = Path(__file__).resolve().parent
    root = _astrbot_data_root()
    if root is not None:
        target = root / "plugin_data" / plugin_name
    else:  # 无法定位 AstrBot 时退化为插件目录下的 plugin_data
        target = plugin_dir / "plugin_data" / plugin_name

    try:
        target.mkdir(parents=True, exist_ok=True)
    except Exception:
        logger.warning("[主动蒸馏] 无法创建数据目录 %s，回退到插件目录", target)
        target = plugin_dir / "plugin_data" / plugin_name
        target.mkdir(parents=True, exist_ok=True)

    legacy_dir = plugin_dir / "data"
    legacy = legacy_dir / LEGACY_DB_NAME
    new_db = target / LEGACY_DB_NAME
    if legacy.exists() and not new_db.exists():
        try:
            import shutil

            for suffix in ("", "-wal", "-shm"):
                src = legacy_dir / f"{LEGACY_DB_NAME}{suffix}"
                if src.exists():
                    shutil.copy2(src, target / f"{LEGACY_DB_NAME}{suffix}")
            logger.info("[主动蒸馏] 已迁移旧数据库 %s -> %s", legacy, new_db)
        except Exception as exc:
            logger.warning("[主动蒸馏] 旧数据库迁移失败（忽略）：%s", exc)
    return target


# ---------------------------------------------------------------------- #
#  插件主体
# ---------------------------------------------------------------------- #
@register(
    PLUGIN_NAME,
    "red3421",
    "主动搜索 QQ 群并抓取群历史消息，分块喂给 LLM 蒸馏出人设/说话习惯/表情包习惯画像，自带可视化蒸馏台。",
    "1.1.0",
    "",
)
class GroupActiveDistillerPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig = None) -> None:
        super().__init__(context)
        self.context = context
        self.config = config or {}

        self.data_dir = _resolve_data_dir(PLUGIN_NAME)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.data_dir / "distiller.db"

        self.store = DistillerStore(str(self.db_path))
        self.collector = GroupCollector(
            context, self.config, self.store, log=self._log
        )
        self.distiller = PersonaDistiller(
            context, self.config, self.store, log=self._log
        )

        self._tasks: list[asyncio.Task] = []
        self._running = False
        self._busy: dict[str, bool] = {"collect": False, "distill": False}
        self._page_tokens: set[str] = set()

        self._register_pages()

    # ------------------------------------------------------------------ #
    #  生命周期
    # ------------------------------------------------------------------ #
    async def initialize(self) -> None:
        await self.store.init()
        await self.store.mark_stale_jobs()
        self._running = True
        self._tasks.append(asyncio.create_task(self._collect_loop(), name="gad-collect"))
        self._tasks.append(asyncio.create_task(self._discover_loop(), name="gad-discover"))
        await self._log("系统", "主动蒸馏器已启动")
        logger.info("[主动蒸馏] 初始化完成，数据库: %s", self.db_path)

    async def terminate(self) -> None:
        self._running = False
        for task in self._tasks:
            task.cancel()
        for task in self._tasks:
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
        self._tasks.clear()
        await self.store.close()
        logger.info("[主动蒸馏] 已卸载")

    async def _log(self, scope: str, message: str, level: str = "info") -> None:
        try:
            await self.store.log(scope, message, level)
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    #  定时任务
    # ------------------------------------------------------------------ #
    async def _sleep_minutes(self, minutes: int) -> None:
        total = max(30, int(minutes) * 60)
        slept = 0
        while slept < total and self._running:
            await asyncio.sleep(min(30, total - slept))
            slept += 30

    async def _collect_loop(self) -> None:
        await asyncio.sleep(20)  # 等平台连接就绪
        while self._running:
            try:
                if bool(_cfg(self.config, "enable_auto_collect", True)):
                    await self._run_round()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                await self._log("定时采集", f"异常: {exc}", "error")
                logger.error("[主动蒸馏] 定时采集异常: %s", exc, exc_info=True)
            await self._sleep_minutes(int(_cfg(self.config, "collect_interval_minutes", 30) or 30))

    async def _discover_loop(self) -> None:
        await asyncio.sleep(45)
        while self._running:
            try:
                await self._discover_groups()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                await self._log("发现", f"异常: {exc}", "error")
            await self._sleep_minutes(
                int(_cfg(self.config, "discover_interval_minutes", 120) or 120)
            )

    async def _discover_groups(self) -> list[dict[str, Any]]:
        keywords = _split_list(_cfg(self.config, "discover_keywords", []))
        found: list[dict[str, Any]] = []
        if keywords:
            for kw in keywords:
                try:
                    found.extend(await self.collector.search_groups(kw))
                except Exception as exc:
                    await self._log("发现", f"关键词 {kw} 搜索失败: {exc}", "warning")
        else:
            found = await self.collector.search_groups("")
        # 去重
        seen: set[str] = set()
        uniq = []
        for g in found:
            if g["group_id"] in seen:
                continue
            seen.add(g["group_id"])
            uniq.append(g)
        if uniq:
            await self.collector.register_groups(uniq)
            await self._log("发现", f"登记 {len(uniq)} 个群")
        return uniq

    async def _run_round(self) -> list[dict[str, Any]]:
        if self._busy["collect"]:
            await self._log("采集", "上一轮采集尚未结束，跳过", "warning")
            return []
        self._busy["collect"] = True
        try:
            results = await self.collector.collect_all(only_auto=True)
            await self._log("采集", f"本轮完成 {len(results)} 个群")
        finally:
            self._busy["collect"] = False

        if bool(_cfg(self.config, "auto_distill_after_collect", True)):
            top_n = int(_cfg(self.config, "auto_distill_top_n", 3) or 0)
            if top_n > 0:
                await self._auto_distill(top_n)
        return results

    async def _auto_distill(self, top_n: int) -> None:
        if self._busy["distill"]:
            return
        self._busy["distill"] = True
        try:
            groups = await self.store.list_groups()
            auto_groups = [g for g in groups if int(g.get("auto_distill") or 0) == 1]
            limit = int(_cfg(self.config, "max_groups_per_round", 8) or 8)
            min_msgs = int(_cfg(self.config, "auto_distill_min_messages", 60) or 0)
            for g in auto_groups[:limit]:
                try:
                    await self.distiller.distill_batch(g["group_id"], top_n, min_msgs)
                except Exception as exc:
                    await self._log("自动蒸馏", f"群 {g['group_id']} 失败: {exc}", "error")
        finally:
            self._busy["distill"] = False

    # ------------------------------------------------------------------ #
    #  消息钩子：记录 bot 通道 + 顺手采集
    # ------------------------------------------------------------------ #
    @filter.event_message_type(filter.EventMessageType.ALL)
    async def on_any_message(self, event: AstrMessageEvent):
        """这里只做极轻的事：记住 bot 通道，供主动采集用。不 return 任何东西。"""
        try:
            self.collector.remember_bot(event)
        except Exception:
            pass
        return

    @filter.on_platform_loaded()
    async def on_platform_loaded(self):
        try:
            bots = self.collector.get_bots()
            await self._log("系统", f"平台就绪，可用 OneBot 通道 {len(bots)} 个")
        except Exception:
            pass
        return

    # ------------------------------------------------------------------ #
    #  命令区
    # ------------------------------------------------------------------ #
    @filter.command("蒸馏", alias={"主动蒸馏", "distill"})
    @filter.permission_type(PermissionType.ADMIN)
    async def cmd_distill(self, event: AstrMessageEvent, sub: str = "", *args: str):
        """主动蒸馏器总入口。用法见 /蒸馏 帮助"""
        sub = (sub or "").strip()
        argv = list(args)
        try:
            if sub in ("", "帮助", "help"):
                yield event.plain_result(self._help_text())
                return
            if sub in ("搜群", "search"):
                keyword = argv[0] if argv else ""
                groups = await self.collector.search_groups(keyword)
                if not groups:
                    yield event.plain_result("没搜到匹配的群。机器人需要在目标群里才能拉到数据。")
                    return
                await self.collector.register_groups(groups)
                lines = [f"· {g['group_id']}  {g['group_name'] or '(无名)'}  成员 {g['member_count']}" for g in groups[:30]]
                yield event.plain_result(f"搜到 {len(groups)} 个群（已登记）：\n" + "\n".join(lines))
                return

            if sub in ("采集", "collect"):
                if not argv:
                    yield event.plain_result("用法：/蒸馏 采集 <群号> [数量]")
                    return
                gid = argv[0]
                count = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else 0
                await event.send(MessageChain().message(f"开始采集群 {gid}…"))
                res = await self.collector.collect_group(gid, count=count)
                yield event.plain_result(
                    f"采集完成：拉取 {res['fetched']} 条，入库新增 {res['inserted']} 条"
                )
                return

            if sub in ("群列表", "groups"):
                groups = await self.store.list_groups()
                if not groups:
                    yield event.plain_result("还没登记任何群。先执行 /蒸馏 搜群")
                    return
                lines = [
                    f"· {g['group_id']} {g['group_name'] or '(无名)'} "
                    f"消息 {g['msg_count']} 采集={'开' if g['auto_collect'] else '关'} "
                    f"蒸馏={'开' if g['auto_distill'] else '关'}"
                    for g in groups[:40]
                ]
                yield event.plain_result("\n".join(lines))
                return

            if sub in ("对象", "users"):
                if not argv:
                    yield event.plain_result("用法：/蒸馏 对象 <群号>")
                    return
                users = await self.store.list_users(argv[0], limit=30, min_count=5)
                if not users:
                    yield event.plain_result("该群还没有足够数据，先采集。")
                    return
                lines = [
                    f"· {u['user_id']} {u.get('card') or u.get('nickname') or ''} "
                    f"{u['msg_count']}条 画像v{u.get('distiller_ver') or 0}"
                    for u in users
                ]
                yield event.plain_result(f"群 {argv[0]} 活跃群友：\n" + "\n".join(lines))
                return

            if sub in ("蒸馏", "run"):
                if len(argv) < 2:
                    yield event.plain_result("用法：/蒸馏 蒸馏 <群号> <QQ号>")
                    return
                gid, uid = argv[0], argv[1]
                await event.send(MessageChain().message(f"开始蒸馏 {uid}…（可能要几十秒）"))
                job_id = await self.store.create_job(gid, uid)
                try:
                    res = await self.distiller.distill_user(gid, uid, job_id=job_id)
                except Exception as exc:
                    await self.store.update_job(job_id, status="failed", stage="失败", error=str(exc))
                    yield event.plain_result(f"蒸馏失败：{exc}")
                    return
                p = res["persona"]
                yield event.plain_result(
                    f"人设 v{res['version']} 生成完成\n"
                    f"对象：{res['nickname']}({uid})\n"
                    f"素材：{res['sample_count']} 条 / {res['batch_ok']} 批\n"
                    f"置信度：{res['confidence']}\n\n"
                    f"{p.get('summary') or ''}"
                )
                return

            if sub in ("批量", "batch"):
                if not argv:
                    yield event.plain_result("用法：/蒸馏 批量 <群号> [人数]")
                    return
                gid = argv[0]
                top_n = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else 3
                await event.send(MessageChain().message(f"开始批量蒸馏 {gid} 的 Top {top_n}…"))
                results = await self.distiller.distill_batch(
                    gid, top_n, int(_cfg(self.config, "auto_distill_min_messages", 30) or 0)
                )
                ok = [r for r in results if "error" not in r]
                fail = [r for r in results if "error" in r]
                text = f"批量完成：成功 {len(ok)}，失败 {len(fail)}"
                if ok:
                    text += "\n" + "\n".join(
                        f"· {r['nickname']}({r['user_id']}) v{r['version']} 置信度 {r['confidence']}"
                        for r in ok
                    )
                if fail:
                    text += "\n失败：" + "；".join(f"{r['user_id']}: {r['error'][:60]}" for r in fail)
                yield event.plain_result(text)
                return

            if sub in ("追踪", "track", "全群", "global"):
                if not argv:
                    yield event.plain_result(
                        "用法：/蒸馏 追踪 <QQ号> [--no-collect] [--full] [--count N]\n"
                        "例：/蒸馏 追踪 10001\n"
                        "它会自动扫描机器人所在的所有群，把这个号在每群能拿到的消息全部拉下来，\n"
                        "跨群合并后分批喂给 LLM，产出一份「跨群综合人设」。"
                    )
                    return
                uid = argv[0].strip()
                flags = argv[1:]
                do_collect = "--no-collect" not in flags
                do_full = "--full" in flags
                fetch_count = 0
                for i, f in enumerate(flags):
                    if f == "--count" and i + 1 < len(flags) and flags[i + 1].isdigit():
                        fetch_count = int(flags[i + 1])

                await event.send(
                    MessageChain().message(
                        f"开始追踪 {uid}"
                        + ("（先跨群采集再蒸馏）" if do_collect else "（只蒸馏本地数据）")
                        + "…网络慢的话要几分钟"
                    )
                )
                job_id = await self.store.create_job("*global*", uid)
                try:
                    res = await self.distiller.distill_user_global(
                        uid,
                        collector=self.collector if do_collect else None,
                        collect=do_collect,
                        fetch_count=fetch_count,
                        full=do_full,
                        job_id=job_id,
                    )
                except Exception as exc:
                    await self.store.update_job(job_id, status="failed", stage="失败", error=str(exc))
                    yield event.plain_result(f"追踪失败：{exc}")
                    return

                p = res["persona"]
                cov = "\n".join(
                    f"  · 群 {g['group_id']}  {g['messages']} 条"
                    for g in (p.get("source_groups") or [])
                )
                yield event.plain_result(
                    f"跨群人设 v{res['version']} 生成完成\n"
                    f"对象：{res['nickname']}({uid})\n"
                    f"覆盖 {res['groups_hit']} 个群，素材 {res['sample_count']} 条 / {res['batch_ok']} 批\n"
                    f"置信度：{res['confidence']}\n"
                    + (f"群覆盖率：\n{cov}\n" if cov else "")
                    + f"\n{p.get('summary') or ''}\n\n"
                    f"取完整人设：/蒸馏 投放 {uid}"
                )
                return

            if sub in ("搜索蒸馏", "搜qq", "qq"):
                if not argv:
                    yield event.plain_result("用法：/蒸馏 搜索蒸馏 <QQ号>")
                    return
                uid = argv[0].strip()
                await event.send(MessageChain().message(f"正在全群搜索并采集 {uid} 的聊天记录…"))
                info = await self.distiller.collect_user_everywhere(uid, collector=self.collector)
                if info["total_messages"] <= 0:
                    yield event.plain_result(
                        f"在 {info['groups_scanned']} 个群里都没找到 {uid} 的消息。\n"
                        f"机器人需要在该用户所在的群里，且该号发过言。"
                    )
                    return
                lines = [
                    f"  · 群 {d['group_id']}  {d['messages']} 条（新增 {d.get('inserted', 0)}）"
                    for d in info["detail"]
                    if d["messages"] > 0
                ]
                yield event.plain_result(
                    f"{uid} 采集完成：\n"
                    f"扫描 {info['groups_scanned']} 群，命中 {info['groups_hit']} 群，"
                    f"共 {info['total_messages']} 条\n" + "\n".join(lines) + "\n\n"
                    f"现在可以蒸馏：/蒸馏 追踪 {uid} --no-collect"
                )
                return

            if sub in ("画像", "persona"):
                if argv:
                    rows = await self.store.list_personas(user_id=argv[0])
                else:
                    rows = await self.store.list_personas(limit=20)
                if not rows:
                    yield event.plain_result("还没有生成任何画像。")
                    return
                lines = [
                    f"· {r['nickname']}({r['user_id']}) v{r['version']} "
                    f"{'跨群' if r['group_id'] == '*global*' else '群' + str(r['group_id'])} "
                    f"置信度 {r['confidence']}"
                    for r in rows
                ]
                yield event.plain_result("\n".join(lines))
                return

            if sub in ("投放", "prompt"):
                if not argv:
                    yield event.plain_result("用法：/蒸馏 投放 <QQ号> [群号]")
                    return
                uid = argv[0]
                gid = argv[1] if len(argv) > 1 else ""
                row = await self.store.get_persona(gid, uid) if gid else None
                if row is None:
                    rows = await self.store.list_personas(user_id=uid, limit=1)
                    row = rows[0] if rows else None
                if row is None:
                    yield event.plain_result("找不到该群友的画像。")
                    return
                prompt = row.get("system_prompt") or render_system_prompt(
                    row.get("persona") or {}, row.get("nickname") or uid
                )
                yield event.plain_result(prompt[:3500])
                return

            if sub in ("状态", "status"):
                ov = await self.store.overview()
                yield event.plain_result(
                    "主动蒸馏器状态\n"
                    f"群：{ov.get('groups', 0)}  消息：{ov.get('messages', 0)}  "
                    f"群友：{ov.get('users', 0)}  画像：{ov.get('personas', 0)}\n"
                    f"采集任务：{'进行中' if self._busy['collect'] else '空闲'}  "
                    f"蒸馏任务：{'进行中' if self._busy['distill'] else '空闲'}\n"
                    f"后台：{self._page_url()}"
                )
                return

            if sub in ("后台", "panel"):
                yield event.plain_result(f"可视化蒸馏台：{self._page_url()}")
                return

            yield event.plain_result(self._help_text())
        except (CollectorError, DistillError) as exc:
            yield event.plain_result(f"执行失败：{exc}")
        except Exception as exc:
            logger.error("[主动蒸馏] 命令异常: %s", exc, exc_info=True)
            yield event.plain_result(f"出错了：{exc}")

    @staticmethod
    def _help_text() -> str:
        return (
            "群友主动蒸馏器\n"
            "★ 核心用法：直接喂 QQ 号\n"
            "/蒸馏 追踪 <QQ号>           扫全部群→拉该号所有记录→跨群分批蒸馏（一步到位）\n"
            "/蒸馏 追踪 <QQ号> --no-collect   只蒸馏本地已有数据，不联网采集\n"
            "/蒸馏 追踪 <QQ号> --full --count 800   强制全量重新拉，每群拉 800 条\n"
            "/蒸馏 搜索蒸馏 <QQ号>       只采集不蒸馏，看他在哪些群、各有多少条\n"
            "\n按群操作（旧方式）\n"
            "/蒸馏 搜群 [关键词]        搜索并登记机器人所在的群\n"
            "/蒸馏 采集 <群号> [数量]    主动拉群历史入库\n"
            "/蒸馏 群列表               查看已登记群\n"
            "/蒸馏 对象 <群号>          查看活跃群友排行\n"
            "/蒸馏 蒸馏 <群号> <QQ号>    只蒸某个群里的表现\n"
            "/蒸馏 批量 <群号> [N]      批量蒸馏 Top N\n"
            "\n结果\n"
            "/蒸馏 画像 [QQ号]          查看已生成画像\n"
            "/蒸馏 投放 <QQ号>          导出 system prompt\n"
            "/蒸馏 状态                 运行状态\n"
            "/蒸馏 后台                 可视化蒸馏台地址"
        )

    def _page_url(self) -> str:
        base = "http://127.0.0.1:6185"
        try:
            for attr in ("base_url", "webui_url"):
                val = getattr(self.context, attr, None)
                if isinstance(val, str) and val.startswith("http"):
                    base = val.rstrip("/")
        except Exception:
            pass
        return f"{base}/plugin-page/{PLUGIN_NAME}"

    # ------------------------------------------------------------------ #
    #  Web API 注册
    # ------------------------------------------------------------------ #
    def _register_pages(self) -> None:
        """注册可视化后台接口（AstrBot 插件拓展页）。"""
        if not bool(_cfg(self.config, "webui_enabled", True)):
            return
        register_web_api = getattr(self.context, "register_web_api", None)
        if not callable(register_web_api):
            logger.warning("[主动蒸馏] 当前 AstrBot 版本不支持 register_web_api，跳过可视化后台")
            return

        routes = [
            ("/overview", self.api_overview, ["GET"], "总览"),
            ("/groups", self.api_groups, ["GET"], "群列表"),
            ("/groups/update", self.api_group_update, ["POST"], "更新单个群标记"),
            ("/groups/bulk", self.api_group_bulk, ["POST"], "批量开关自动采集/蒸馏"),
            ("/groups/discover", self.api_discover, ["POST"], "搜索群"),
            ("/groups/distill", self.api_groups_distill, ["POST"], "勾选的群批量蒸馏"),
            ("/collect", self.api_collect, ["POST"], "触发采集"),
            ("/users", self.api_users, ["GET"], "群友排行"),
            ("/personas", self.api_personas, ["GET"], "画像索引"),
            ("/persona", self.api_persona, ["GET"], "画像详情"),
            ("/persona/versions", self.api_persona_versions, ["GET"], "画像版本"),
            ("/distill", self.api_distill, ["POST"], "触发蒸馏"),
            ("/track", self.api_track, ["POST"], "按 QQ 号跨群搜索并蒸馏"),
            ("/user/lookup", self.api_user_lookup, ["GET"], "按 QQ 号查所在群"),
            ("/jobs", self.api_jobs, ["GET"], "任务列表"),
            ("/jobs/detail", self.api_job_detail, ["GET"], "任务实时进度与阶段"),
            ("/jobs/cancel", self.api_job_cancel, ["POST"], "取消任务"),
            ("/logs", self.api_logs, ["GET"], "运行日志"),
            ("/config", self.api_config, ["GET"], "读取配置"),
            ("/config/save", self.api_config_save, ["POST"], "保存配置"),
            ("/db/stats", self.api_db_stats, ["GET"], "数据库占用"),
            ("/db/prune", self.api_db_prune, ["POST"], "清理数据库"),
            ("/db/vacuum", self.api_db_vacuum, ["POST"], "压缩数据库"),
            ("/stats", self.api_stats, ["GET"], "统计"),
        ]
        for path, handler, methods, desc in routes:
            try:
                register_web_api(f"{PLUGIN_NAME}/page{path}", handler, methods, desc)
            except Exception as exc:
                logger.warning("[主动蒸馏] 注册接口 %s 失败: %s", path, exc)

    # -------------------- Web API 工具 -------------------- #
    @staticmethod
    async def _body() -> dict[str, Any]:
        if quart_request is None:
            return {}
        try:
            payload = await quart_request.get_json(silent=True)
            if isinstance(payload, dict):
                return payload
        except Exception:
            pass
        try:
            args = quart_request.args
            return {k: args.get(k) for k in args}
        except Exception:
            return {}

    @staticmethod
    def _ok(data: Any = None) -> dict[str, Any]:
        return {"success": True, "data": data}

    @staticmethod
    def _err(message: str) -> dict[str, Any]:
        return {"success": False, "error": message}

    def _check_token(self, token: str) -> bool:
        expect = str(_cfg(self.config, "webui_access_token", "") or "").strip()
        if not expect:
            return True
        return token == expect

    # -------------------- Web API 实现 -------------------- #
    async def api_overview(self):
        try:
            ov = await self.store.overview()
            jobs = await self.store.list_jobs(limit=8)
            ov["busy"] = dict(self._busy)
            ov["jobs"] = jobs
            ov["uptime_hint"] = "定时采集间隔 %s 分钟" % _cfg(self.config, "collect_interval_minutes", 30)
            return self._ok(ov)
        except Exception as exc:
            return self._err(str(exc))

    async def api_groups(self):
        try:
            groups = await self.store.list_groups()
            return self._ok(groups)
        except Exception as exc:
            return self._err(str(exc))

    async def api_group_update(self):
        try:
            body = await self._body()
            gid = str(body.get("group_id") or "")
            field = str(body.get("field") or "")
            value = body.get("value")
            if not gid or field not in {"auto_collect", "auto_distill", "note"}:
                return self._err("参数不合法")
            await self.store.set_group_flag(gid, field, value)
            return self._ok({"group_id": gid, "field": field, "value": value})
        except Exception as exc:
            return self._err(str(exc))

    async def api_discover(self):
        try:
            body = await self._body()
            keyword = str(body.get("keyword") or "")
            groups = await self.collector.search_groups(keyword)
            await self.collector.register_groups(groups)
            return self._ok(groups)
        except Exception as exc:
            return self._err(str(exc))

    async def api_collect(self):
        try:
            body = await self._body()
            gid = str(body.get("group_id") or "")
            count = int(body.get("count") or 0)
            full = bool(body.get("full"))
            if gid:
                res = await self.collector.collect_group(gid, count=count, full=full)
                return self._ok(res)
            res = await self._run_round()
            return self._ok(res)
        except Exception as exc:
            return self._err(str(exc))

    async def api_users(self):
        try:
            args = quart_request.args if quart_request is not None else {}
            gid = str(args.get("group_id") or "")
            limit = int(args.get("limit") or 100)
            min_count = int(args.get("min_count") or 1)
            if not gid:
                return self._err("缺少 group_id")
            users = await self.store.list_users(gid, limit=limit, min_count=min_count)
            return self._ok(users)
        except Exception as exc:
            return self._err(str(exc))

    async def api_personas(self):
        """画像索引（供按 QQ 号页面的历史下拉使用，不再是独立页签）。"""
        try:
            args = quart_request.args if quart_request is not None else {}
            gid = str(args.get("group_id") or "")
            uid = str(args.get("user_id") or "")
            rows = await self.store.list_personas(gid, uid, limit=200)
            return self._ok(rows)
        except Exception as exc:
            return self._err(str(exc))

    async def api_persona(self):
        try:
            args = quart_request.args if quart_request is not None else {}
            gid = str(args.get("group_id") or "")
            uid = str(args.get("user_id") or "")
            version = int(args.get("version") or 0)
            row = await self.store.get_persona(gid, uid, version)
            if row is None:
                return self._err("画像不存在")
            stickers = await self.store.stickers(gid, uid, limit=30)
            row["stickers"] = stickers
            return self._ok(row)
        except Exception as exc:
            return self._err(str(exc))

    async def api_persona_versions(self):
        try:
            args = quart_request.args if quart_request is not None else {}
            rows = await self.store.persona_versions(
                str(args.get("group_id") or ""), str(args.get("user_id") or "")
            )
            return self._ok(rows)
        except Exception as exc:
            return self._err(str(exc))

    async def api_distill(self):
        try:
            body = await self._body()
            gid = str(body.get("group_id") or "")
            uid = str(body.get("user_id") or "")
            limit = int(body.get("limit") or 0)
            if not gid:
                return self._err("缺少 group_id")
            if not uid:
                top_n = int(body.get("top_n") or 3)
                results = await self.distiller.distill_batch(gid, top_n)
                return self._ok(results)
            job_id = await self.store.create_job(gid, uid)
            asyncio.create_task(self._bg_distill(gid, uid, limit, job_id))
            return self._ok({"job_id": job_id, "status": "queued"})
        except Exception as exc:
            return self._err(str(exc))

    async def _bg_distill(self, gid: str, uid: str, limit: int, job_id: int) -> None:
        try:
            await self.distiller.distill_user(gid, uid, limit=limit, job_id=job_id)
        except Exception as exc:
            await self.store.update_job(job_id, status="failed", stage="失败", error=str(exc))
            await self._log("蒸馏", f"{uid} 失败: {exc}", "error")

    # -------------------- 以 QQ 号为中心 -------------------- #
    async def api_track(self):
        """输入 QQ 号 → 跨群搜索采集 → 跨群蒸馏。"""
        try:
            body = await self._body()
            uid = str(body.get("user_id") or "").strip()
            if not uid:
                return self._err("缺少 user_id（QQ 号）")
            do_collect = bool(body.get("collect", True))
            do_distill = bool(body.get("distill", True))
            do_full = bool(body.get("full", False))
            fetch_count = int(body.get("count") or 0)
            limit = int(body.get("limit") or 0)

            job_id = await self.store.create_job("*global*", uid)
            gids = [str(g).strip() for g in (body.get("group_ids") or []) if str(g).strip()]
            if do_distill:
                asyncio.create_task(
                    self._bg_track(uid, do_collect, do_full, fetch_count, limit, job_id, gids or None)
                )
                return self._ok({"job_id": job_id, "status": "queued", "mode": "track"})

            info = await self.distiller.collect_user_everywhere(
                uid, collector=self.collector if do_collect else None,
                fetch_count=fetch_count, full=do_full,
                group_ids=gids or None,
            )
            await self.store.update_job(job_id, status="done", stage="仅采集", progress=100)
            return self._ok({"job_id": job_id, "mode": "collect", **info})
        except Exception as exc:
            return self._err(str(exc))

    async def _bg_track(
        self, uid: str, do_collect: bool, do_full: bool,
        fetch_count: int, limit: int, job_id: int,
        group_ids: Optional[list[str]] = None,
    ) -> None:
        """后台跑跨群蒸馏，全程把进度写进 job + job_steps，前端才能看到实时进度。"""
        step_ids: dict[str, int] = {}
        started = time.time()

        async def on_progress(**kw: Any) -> None:
            phase = str(kw.get("phase") or "")
            index = int(kw.get("index") or 0)
            total = int(kw.get("total") or 0)
            note = str(kw.get("note") or "")
            gid = str(kw.get("group_id") or "")
            msgs = int(kw.get("messages") or 0)

            # 采集阶段：每扫一个群就更新主任务进度（这一步原来缺失导致进度条不动）
            if phase in {"listing", "scanning", "local"}:
                if total > 0:
                    pct = int(index * 40 / max(1, total))  # 采集占总进度 40%
                else:
                    pct = 2
                await self.store.update_job(
                    job_id, status="running",
                    stage=f"跨群采集 {index}/{total}" if total else "跨群采集",
                    progress=max(0, min(40, pct)),
                )
                if "collect" not in step_ids:
                    step_ids["collect"] = await self.store.add_step(
                        job_id, "跨群采集", total=total, detail="扫描机器人所在的所有群"
                    )
                await self.store.update_step(
                    step_ids["collect"], done=index, total=total or 0,
                    detail=(f"{note}｜{gid} 命中 {msgs} 条" if gid else note)[:500],
                )
                return

            if phase in {"context", "fetch"}:
                await self.store.update_job(
                    job_id, status="running", stage="打包语料", progress=45
                )
                if "context" not in step_ids:
                    step_ids["context"] = await self.store.add_step(
                        job_id, "打包跨群语料", detail=note
                    )
                return

            if phase == "batches":
                # 批次分析占总进度 45% → 90%
                pct = 45 + int(index * 45 / max(1, total)) if total else 50
                await self.store.update_job(
                    job_id, status="running",
                    stage=f"分批分析 {index}/{total}" if total else "分批分析",
                    progress=max(45, min(90, pct)),
                    batch_done=index, batch_total=total,
                )
                if "batches" not in step_ids:
                    step_ids["batches"] = await self.store.add_step(
                        job_id, "分批喂 LLM", total=total, detail="每批独立分析该号发言"
                    )
                await self.store.update_step(
                    step_ids["batches"], done=index, total=total, detail=note[:500]
                )
                return

            if phase == "merge":
                await self.store.update_job(
                    job_id, status="running", stage="合并画像", progress=92
                )
                if "merge" not in step_ids:
                    step_ids["merge"] = await self.store.add_step(
                        job_id, "合并画像", detail=note or "合并各批结果"
                    )
                return

            if phase == "done":
                await self.store.update_job(job_id, progress=100)

        try:
            await self.store.update_job(
                job_id, status="running", stage="启动中", progress=1
            )
            result = await self.distiller.distill_user_global(
                uid,
                collector=self.collector if do_collect else None,
                collect=do_collect,
                fetch_count=fetch_count,
                full=do_full,
                limit=limit,
                job_id=job_id,
                group_ids=group_ids,
                on_progress=on_progress,
            )
            cost = int(time.time() - started)
            for sid in step_ids.values():
                try:
                    await self.store.finish_step(sid, detail="完成")
                except Exception:
                    pass
            await self.store.update_job(
                job_id, status="done", stage=f"完成（{cost}s）", progress=100,
                sample_count=int(result.get("sample_count") or 0),
            )
            await self._log(
                "跨群蒸馏",
                f"{uid} 完成：v{result.get('version')} 样本 {result.get('sample_count')} 条 "
                f"{result.get('batch_total')} 批，耗时 {cost}s",
            )
        except Exception as exc:
            await self.store.update_job(
                job_id, status="failed", stage="失败", error=str(exc), progress=100
            )
            await self._log("跨群蒸馏", f"{uid} 失败: {exc}", "error")

    async def _bg_groups_distill(
        self, group_ids: list[str], top_n: int, min_messages: int, job_id: int,
    ) -> None:
        """勾选若干群 → 逐群蒸馏其中的人。"""
        step_id = 0

        async def on_progress(**kw: Any) -> None:
            nonlocal step_id
            index = int(kw.get("index") or 0)
            total = int(kw.get("total") or 0)
            note = str(kw.get("note") or "")
            if total:
                await self.store.update_job(
                    job_id, status="running",
                    stage=f"群蒸馏 {index}/{total}",
                    progress=max(0, min(99, int(index * 100 / max(1, total)))),
                )
            if step_id == 0:
                step_id = await self.store.add_step(job_id, "逐群蒸馏", total=total)
            await self.store.update_step(step_id, done=index, total=total, detail=note[:500])

        try:
            await self.store.update_job(job_id, status="running", stage="启动中", progress=1)
            res = await self.distiller.distill_selected_groups(
                group_ids, top_n=top_n, min_messages=min_messages,
                on_progress=on_progress, job_id=job_id,
            )
            if step_id:
                await self.store.finish_step(step_id, detail="完成")
            await self.store.update_job(
                job_id, status="done", progress=100,
                stage=f"完成：成功 {res.get('distilled', 0)} 人 / 失败 {res.get('failed', 0)} 人",
            )
        except Exception as exc:
            await self.store.update_job(
                job_id, status="failed", stage="失败", error=str(exc), progress=100
            )
            await self._log("批量蒸馏", f"失败: {exc}", "error")

    async def api_user_lookup(self):
        """查询某个 QQ 号在哪些群、各有多少条消息（不采集）。"""
        try:
            args = quart_request.args if quart_request is not None else {}
            uid = str(args.get("user_id") or "").strip()
            if not uid:
                return self._err("缺少 user_id")
            rows = await self.store.user_groups(uid, min_count=1)
            total = sum(int(r.get("msg_count") or 0) for r in rows)
            return self._ok({"user_id": uid, "total_messages": total, "groups": rows})
        except Exception as exc:
            return self._err(str(exc))

    async def api_jobs(self):
        try:
            args = quart_request.args if quart_request is not None else {}
            limit = int(args.get("limit") or 40)
            status = str(args.get("status") or "")
            rows = await self.store.list_jobs(limit=limit, status=status)
            return self._ok(rows)
        except Exception as exc:
            return self._err(str(exc))

    async def api_job_detail(self):
        """单个任务的实时明细：进度、阶段、每个群的采集结果、预计剩余时间。"""
        try:
            args = quart_request.args if quart_request is not None else {}
            job_id = int(args.get("job_id") or 0)
            if not job_id:
                return self._err("缺少 job_id")
            job = await self.store.get_job(job_id)
            if not job:
                return self._err("任务不存在")
            steps = await self.store.list_steps(job_id)

            progress = float(job.get("progress") or 0)
            eta = None
            created = int(job.get("created_at") or 0)
            updated = int(job.get("updated_at") or 0)
            if job.get("status") in {"running", "queued"} and progress > 3 and created:
                elapsed = max(1, updated - created)
                eta = int(elapsed * (100 - progress) / progress)

            # 这个 QQ 号在各群的命中情况（跨群任务才有意义）
            groups_hit: list[dict[str, Any]] = []
            uid = str(job.get("user_id") or "")
            if job.get("group_id") == "*global*" and uid:
                try:
                    for row in await self.store.user_groups(uid, min_count=1):
                        groups_hit.append({
                            "group_id": row.get("group_id"),
                            "group_name": row.get("group_name") or "",
                            "messages": int(row.get("msg_count") or 0),
                        })
                except Exception:
                    pass

            return self._ok({
                **job,
                "steps": steps,
                "eta_seconds": eta,
                "elapsed_seconds": max(0, updated - created),
                "groups_hit": groups_hit,
            })
        except Exception as exc:
            return self._err(str(exc))

    async def api_job_cancel(self):
        try:
            body = await self._body()
            job_id = int(body.get("job_id") or 0)
            if not job_id:
                return self._err("缺少 job_id")
            await self.store.cancel_job(job_id)
            return self._ok({"job_id": job_id, "status": "canceled"})
        except Exception as exc:
            return self._err(str(exc))

    async def api_group_bulk(self):
        """一键全选：批量把某些群的自动采集 / 自动蒸馏打开或关掉。"""
        try:
            body = await self._body()
            field = str(body.get("field") or "")
            value = 1 if body.get("value") else 0
            group_ids = body.get("group_ids") or []
            if field not in {"auto_collect", "auto_distill"}:
                return self._err("field 只能是 auto_collect 或 auto_distill")
            gids = [str(g) for g in group_ids if str(g).strip()] or None
            n = await self.store.set_all_group_flags(field, value, gids)
            state = "开启" if value else "关闭"
            await self._log("群管理", f"批量{state}{field}：{n} 个群")
            return self._ok({"updated": n, "field": field, "value": value})
        except Exception as exc:
            return self._err(str(exc))

    async def api_groups_distill(self):
        """把勾选的群全部加入蒸馏队列（问题8：群覆盖表勾选后直接蒸）。"""
        try:
            body = await self._body()
            group_ids = [str(g).strip() for g in (body.get("group_ids") or []) if str(g).strip()]
            if not group_ids:
                return self._err("请至少勾选一个群")
            top_n = int(body.get("top_n") or 0)
            min_messages = int(body.get("min_messages") or 0)
            job_id = await self.store.create_job(",".join(group_ids[:3]), f"groups:{len(group_ids)}")
            asyncio.create_task(
                self._bg_groups_distill(group_ids, top_n, min_messages, job_id)
            )
            return self._ok({"job_id": job_id, "groups": len(group_ids), "status": "queued"})
        except Exception as exc:
            return self._err(str(exc))

    async def api_db_stats(self):
        try:
            stats = await self.store.db_stats()
            ov = await self.store.overview()
            return self._ok({"db": stats, "overview": ov})
        except Exception as exc:
            return self._err(str(exc))

    async def api_db_prune(self):
        """清理数据库。scope: messages / logs / jobs / personas / all_data / everything"""
        try:
            body = await self._body()
            scope = str(body.get("scope") or "messages")
            keep_days = int(body.get("keep_days") or 0)
            group_id = str(body.get("group_id") or "")
            removed = await self.store.prune(scope, keep_days=keep_days, group_id=group_id)
            total = sum(int(v) for v in removed.values())
            await self._log("数据库", f"清理 {scope}：共删除 {total} 行 {removed}")
            return self._ok({"scope": scope, "removed": removed, "total": total})
        except Exception as exc:
            return self._err(str(exc))

    async def api_db_vacuum(self):
        try:
            info = await self.store.vacuum()
            await self._log(
                "数据库",
                f"VACUUM 完成：{info.get('before', 0)} → {info.get('after', 0)} 字节，"
                f"释放 {info.get('freed', 0)}",
            )
            return self._ok(info)
        except Exception as exc:
            return self._err(str(exc))

    async def api_logs(self):
        try:
            args = quart_request.args if quart_request is not None else {}
            limit = int(args.get("limit") or 80)
            rows = await self.store.recent_logs(limit)
            return self._ok(rows)
        except Exception as exc:
            return self._err(str(exc))

    async def api_config(self):
        try:
            schema_path = Path(__file__).parent / "_conf_schema.json"
            schema: dict[str, Any] = {}
            if schema_path.exists():
                schema = json.loads(schema_path.read_text(encoding="utf-8"))
            values = {k: _cfg(self.config, k) for k in schema}
            return self._ok({"schema": schema, "values": values})
        except Exception as exc:
            return self._err(str(exc))

    async def api_config_save(self):
        try:
            body = await self._body()
            updates = body.get("values") or body
            if not isinstance(updates, dict):
                return self._err("参数不合法")
            schema_path = Path(__file__).parent / "_conf_schema.json"
            schema = {}
            if schema_path.exists():
                schema = json.loads(schema_path.read_text(encoding="utf-8"))

            applied: dict[str, Any] = {}
            for key, raw in updates.items():
                if key not in schema:
                    continue
                meta = schema[key] or {}
                value = self._coerce(raw, meta)
                try:
                    self.config[key] = value
                except Exception:
                    try:
                        setattr(self.config, key, value)
                    except Exception:
                        pass
                applied[key] = value
            self._persist_config()
            await self._log("配置", f"更新 {len(applied)} 项")
            return self._ok(applied)
        except Exception as exc:
            return self._err(str(exc))

    @staticmethod
    def _coerce(raw: Any, meta: dict[str, Any]) -> Any:
        typ = str(meta.get("type") or "string")
        try:
            if typ == "bool":
                if isinstance(raw, str):
                    return raw.strip().lower() in {"1", "true", "yes", "on", "是"}
                return bool(raw)
            if typ == "int":
                val = int(float(raw))
                slider = meta.get("slider") or {}
                if "min" in slider:
                    val = max(int(slider["min"]), val)
                if "max" in slider:
                    val = min(int(slider["max"]), val)
                return val
            if typ == "float":
                val = float(raw)
                slider = meta.get("slider") or {}
                if "min" in slider:
                    val = max(float(slider["min"]), val)
                if "max" in slider:
                    val = min(float(slider["max"]), val)
                return val
            if typ == "list":
                return _split_list(raw)
            return str(raw)
        except Exception:
            return meta.get("default")

    def _persist_config(self) -> None:
        for method in ("save_config", "save", "dump", "flush"):
            fn = getattr(self.config, method, None)
            if callable(fn):
                try:
                    fn()
                    return
                except Exception:
                    continue
        try:
            path = Path(__file__).parent / "config.json"
            path.write_text(
                json.dumps(
                    {k: v for k, v in dict(self.config).items() if not k.startswith("_")},
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
        except Exception as exc:
            logger.warning("[主动蒸馏] 配置持久化失败: %s", exc)

    async def api_stats(self):
        """全局统计。不传 group_id 时返回总览，前端顶栏与数据库页都用它。"""
        try:
            args = quart_request.args if quart_request is not None else {}
            gid = str(args.get("group_id") or "")
            overview = await self.store.overview()
            stats: dict[str, Any] = {"overview": overview}
            if gid:
                stats["group_id"] = gid
                stats["messages"] = await self.store.count_messages(gid)
                stats["stickers"] = await self.store.stickers(gid, "", 20)
                stats["top_users"] = await self.store.list_users(gid, limit=10, min_count=1)
            return self._ok(stats)
        except Exception as exc:
            return self._err(str(exc))
