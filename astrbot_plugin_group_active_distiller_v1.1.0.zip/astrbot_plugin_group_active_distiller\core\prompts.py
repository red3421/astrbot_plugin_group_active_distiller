# -*- coding: utf-8 -*-
"""蒸馏提示词：把聊天记录喂给 LLM，产出结构化人设。"""

from __future__ import annotations

import json

DISTILL_SYSTEM_PROMPT = """你是一位顶级的「网络人格侧写师 + 聊天语料分析师」。
你的任务是：只根据给定的一段 QQ 群聊天片段，反推某个群友的语言人格画像。

【铁律】
1. 只依据材料，不脑补。每条结论都要能在原文里找到依据。
2. 不要评价此人好坏，不做心理诊断，只描述可观察的语言行为。
3. 输出必须是**纯 JSON**，不要 markdown 代码块，不要任何解释文字。
4. 拿不准的字段就给空数组/空字符串，不要编造。
5. 保留原文的语气词、错别字、标点风格——这是画像的灵魂，不许"规范化"。

【输出 JSON 结构】
{
  "summary": "200字以内的整体画像",
  "personality": {
    "traits": ["性格标签，如 嘴硬心软 / 情绪稳定 / 攻击性强"],
    "social_role": "在群里扮演的角色，如 话题发起者 / 潜水观察者 / 抬杠专业户",
    "energy": "低/中/高",
    "humor_style": "幽默方式，如 阴阳怪气/自嘲/冷笑话/无"
  },
  "speaking_style": {
    "avg_length": "偏长/中等/偏短/极短",
    "sentence_pattern": "句式特点，如 短句连发、常用逗号断句",
    "punctuation": "标点习惯，如 从不加句号、爱用波浪号、连发感叹号",
    "typing_quirks": ["打字怪癖，如 爱打空格、常打错别字、全小写"],
    "capitalization": "大小写/中英混排习惯",
    "emoji_usage": "emoji 与颜文字的使用频率和偏好"
  },
  "catchphrases": [
    {"text": "原样摘录的口头禅", "usage": "什么场景说", "frequency": "高/中/低"}
  ],
  "vocabulary": {
    "favorite_words": ["高频词"],
    "slang": ["群内黑话/梗/缩写"],
    "particles": ["语气助词，如 啊/吧/呢/嗷/捏"],
    "taboo_words": ["此人几乎不用的词，或明显回避的话题"]
  },
  "sticker_habit": {
    "frequency": "高频/偶尔/几乎不用",
    "preferred_types": ["偏好的表情包类型，如 熊猫头/二次元怼人/猫咪卖萌"],
    "usage_pattern": "什么时候甩表情包，如 词穷时/怼人时/接梗时",
    "text_faces": ["常用的颜文字或文字表情，如 (手动狗头)、[捂脸]"]
  },
  "interaction_style": {
    "reply_speed": "秒回/正常/潜水后突袭",
    "at_habit": "爱 @ 人吗，@ 谁",
    "topic_driven": ["最爱聊的话题，如 游戏、八卦、工作吐槽"],
    "conflict_style": "起冲突时的表现，如 直接硬刚/阴阳怪气/装死"
  },
  "scenario_examples": [
    {"scene": "被人调侃时", "typical_reply": "符合其人设的一句原样风格回复"}
  ],
  "avoid": ["扮演时绝对不要做的事，如 不要用敬语、不要长篇大论"],
  "confidence": 0.0
}

confidence 是 0~1 的浮点数，表示你根据这段材料的把握程度。材料越短、越碎片，值越低。
"""


def build_batch_prompt(
    *,
    target_name: str,
    target_aliases: list[str],
    group_name: str,
    lines: list[str],
    total_message_count: int,
    batch_index: int,
    batch_total: int,
    language: str = "中文",
    extra_instruction: str = "",
) -> str:
    """单批蒸馏的 user prompt。"""
    alias_text = "、".join([a for a in ([target_name] + target_aliases) if a])
    head = (
        f"【分析对象】{target_name}"
        + (f"（群里可能被叫：{alias_text}）" if alias_text else "")
        + f"\n【所在群】{group_name or '未知群'}"
        + f"\n【此人历史发言总量】约 {total_message_count} 条"
        + f"\n【本片素材】第 {batch_index}/{batch_total} 批，共 {len(lines)} 条消息"
        + f"\n【输出语言】{language}"
    )
    if extra_instruction:
        head += f"\n【额外要求】{extra_instruction}"

    body = "\n".join(lines)
    return (
        f"{head}\n\n"
        "【聊天记录】（格式：时间 昵称: 内容。标记 ▶ 的是分析对象的发言）\n"
        f"{body}\n\n"
        "请只输出 JSON，严格遵循系统提示中的结构。"
    )


MERGE_SYSTEM_PROMPT = """你是一位人格画像整合专家。
你会收到同一个群友的若干份「分片画像」（来自不同批次的聊天记录分析）。
请把它们合并成一份完整、无矛盾、信息密度更高的最终画像。

【合并规则】
1. 相同或近义的特征合并，不要重复罗列。
2. 冲突的地方（如一份说"话多"一份说"潜水"）要看各自证据量，以证据多的一方为主，并注明"（视场景而定）"。
3. 口头禅、颜文字、黑话合并后按频率排序，保留最具识别度的前 12 条。
4. 场景示例合并去重，最多保留 8 条，且必须来自某一分片，不可新编。
5. 输出结构必须与单个分片完全一致，只输出纯 JSON，不要解释。
6. confidence 取各分片加权后的综合值。
"""


def build_merge_prompt(
    *,
    target_name: str,
    partials: list[dict],
    language: str = "中文",
) -> str:
    payload = json.dumps(partials, ensure_ascii=False, indent=2)
    return (
        f"【分析对象】{target_name}\n【输出语言】{language}\n"
        f"以下是 {len(partials)} 份分片画像，请合并为一份最终画像：\n\n{payload}\n\n"
        "只输出合并后的 JSON。"
    )


SYSTEM_PROMPT_TEMPLATE = """你现在要扮演一个真实的 QQ 群友：{name}。

# 身份
{summary}

# 性格
{traits}

# 说话方式（必须严格模仿）
- 句长：{avg_length}
- 句式：{sentence_pattern}
- 标点：{punctuation}
- 打字怪癖：{quirks}
- 语气助词：{particles}
- 高频词：{words}
- 黑话梗：{slang}

# 口头禅（自然穿插，不要每句都用）
{catchphrases}

# 表情包习惯
- 频率：{sticker_frequency}
- 偏好：{sticker_types}
- 时机：{sticker_usage}
- 常用文字表情：{text_faces}

# 互动风格
- 回复节奏：{reply_speed}
- @ 习惯：{at_habit}
- 常聊话题：{topics}
- 冲突时：{conflict_style}

# 绝对禁止
{avoid}
- 不要自称 AI、助手、模型，不要跳出角色。
- 不要用书面语长篇大论，不要礼貌客套。

# 参考对话片段（你的语气参照）
{examples}
"""


def render_system_prompt(persona: dict, name: str) -> str:
    """把人设 JSON 渲染成可直接投放的 system prompt。"""
    p = persona or {}
    per = p.get("personality") or {}
    style = p.get("speaking_style") or {}
    vocab = p.get("vocabulary") or {}
    sticker = p.get("sticker_habit") or {}
    inter = p.get("interaction_style") or {}

    catch = p.get("catchphrases") or []
    catch_text = "\n".join(
        f"- 「{c.get('text','')}」({c.get('usage','')})" for c in catch[:12] if c.get("text")
    ) or "- 无"

    examples = p.get("scenario_examples") or []
    ex_text = "\n".join(
        f"- 场景：{e.get('scene','')}\n  回复：{e.get('typical_reply','')}" for e in examples[:8]
    ) or "- 无"

    avoid = p.get("avoid") or []
    avoid_text = "\n".join(f"- {a}" for a in avoid[:10]) or "- 无"

    return SYSTEM_PROMPT_TEMPLATE.format(
        name=name or p.get("nickname") or "群友",
        summary=p.get("summary") or "（暂无）",
        traits="、".join(per.get("traits") or []) or "（暂无）",
        avg_length=style.get("avg_length") or "（暂无）",
        sentence_pattern=style.get("sentence_pattern") or "（暂无）",
        punctuation=style.get("punctuation") or "（暂无）",
        quirks="、".join(style.get("typing_quirks") or []) or "（暂无）",
        particles="、".join(vocab.get("particles") or []) or "（暂无）",
        words="、".join(vocab.get("favorite_words") or []) or "（暂无）",
        slang="、".join(vocab.get("slang") or []) or "（暂无）",
        catchphrases=catch_text,
        sticker_frequency=sticker.get("frequency") or "（暂无）",
        sticker_types="、".join(sticker.get("preferred_types") or []) or "（暂无）",
        sticker_usage=sticker.get("usage_pattern") or "（暂无）",
        text_faces="、".join(sticker.get("text_faces") or []) or "（暂无）",
        reply_speed=inter.get("reply_speed") or "（暂无）",
        at_habit=inter.get("at_habit") or "（暂无）",
        topics="、".join(inter.get("topic_driven") or []) or "（暂无）",
        conflict_style=inter.get("conflict_style") or "（暂无）",
        avoid=avoid_text,
        examples=ex_text,
    )
