# -*- coding: utf-8 -*-
"""消息解析层：把 OneBot v11 事件里五花八门的 message 段拆成结构化记录。

要点：
- 兼容 array / string(CQ码) 两种消息格式；
- 保留图片（表情包）、at、reply 段信息，后续蒸馏「表情包习惯」要用；
- 文本清洗只做保守处理（去 CQ 码残留、压缩空白），不删语气词——
  语气词正是要蒸馏的东西。
"""

from __future__ import annotations

import hashlib
import re
from typing import Any

CQ_RE = re.compile(r"\[CQ:([a-zA-Z_]+)((?:,[^\]]*)?)\]")
CQ_KV_RE = re.compile(r",\s*([a-zA-Z_]+)=([^,\]]*)")
URL_HINT_RE = re.compile(r"([a-zA-Z0-9_\-.]{2,32})\.(?:png|jpg|jpeg|gif|webp|bmp)", re.I)

# 纯符号/纯空白判定
PURE_SYMBOL_RE = re.compile(r"^[\s\.\,\!\?\~\-_=+*/\\|@#\$%\^&\*\(\)\[\]\{\}<>:;'\"`～。，！？、…—·【】《》（）]+$")
EMOJI_ONLY_RE = re.compile(r"^[\U0001F300-\U0001FAFF\u2600-\u27BF\s]+$")

# 常见的“无信息量”灌水短句，可用于降低权重
FILLER_WORDS = {"1", "11", "111", "h", "hh", "hhhh", "233", "2333", "23333", "+1", "？", "?", "6", "666", "…"}


def _kv_to_dict(seg_body: str) -> dict[str, str]:
    data: dict[str, str] = {}
    if not seg_body:
        return data
    for k, v in CQ_KV_RE.findall(seg_body):
        data[k] = v
    return data


def parse_cq_string(raw: str) -> list[dict[str, Any]]:
    """把 CQ 码字符串解析成 segment 列表。"""
    segments: list[dict[str, Any]] = []
    pos = 0
    for m in CQ_RE.finditer(raw):
        if m.start() > pos:
            plain = raw[pos: m.start()]
            if plain:
                segments.append({"type": "text", "data": _unescape(plain)})
        segments.append({"type": m.group(1), "data": _kv_to_dict(m.group(2))})
        pos = m.end()
    if pos < len(raw):
        tail = raw[pos:]
        if tail:
            segments.append({"type": "text", "data": _unescape(tail)})
    return segments


def _unescape(text: str) -> str:
    return (
        text.replace("&#91;", "[").replace("&#93;", "]")
        .replace("&#44;", ",").replace("&amp;", "&")
    )


def normalize_segments(msg: Any) -> list[dict[str, Any]]:
    """统一 array / string / dict 三种 message 结构。"""
    if msg is None:
        return []
    if isinstance(msg, str):
        return parse_cq_string(msg)
    if isinstance(msg, dict):
        if "type" in msg:
            return [{"type": msg.get("type", "text"), "data": msg.get("data") or {}}]
        return []
    if isinstance(msg, list):
        out: list[dict[str, Any]] = []
        for seg in msg:
            if isinstance(seg, dict):
                out.append({"type": seg.get("type", "text"), "data": seg.get("data") or {}})
            elif isinstance(seg, str):
                out.append({"type": "text", "data": {"text": seg}})
        return out
    return []


def _image_hint(data: dict[str, Any]) -> str:
    """从图片段的 file/summary/url 里抽语义线索（不下载图片）。"""
    for key in ("summary", "file", "file_name", "url"):
        value = str(data.get(key) or "")
        if not value:
            continue
        m = URL_HINT_RE.search(value)
        if m:
            token = m.group(1)
            token = re.sub(r"^[0-9a-f]{16,}$", "", token, flags=re.I)
            if token and len(token) >= 2:
                return token[:32]
    tag = str(data.get("sub_type") or data.get("type") or "")
    return tag or "图片"


def clean_text(text: str) -> str:
    text = CQ_RE.sub("", text or "")
    text = text.replace("\u200b", "").replace("\ufeff", "")
    text = re.sub(r"[ \t\u3000]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def is_noise(text: str, min_length: int = 1) -> bool:
    body = text.strip()
    if len(body) < max(0, min_length):
        return True
    if not body:
        return True
    if PURE_SYMBOL_RE.match(body):
        return True
    if EMOJI_ONLY_RE.match(body):
        return True
    return False


def is_filler(text: str) -> bool:
    return text.strip().lower() in FILLER_WORDS


def build_record(
    *,
    platform: str,
    group_id: str,
    raw: dict[str, Any],
    collect_stickers: bool = True,
    sticker_hint: bool = True,
    noise_filter: bool = True,
    min_length: int = 1,
) -> dict[str, Any] | None:
    """把 OneBot 原始消息 dict 转成入库记录；返回 None 表示丢弃。"""
    if not isinstance(raw, dict):
        return None
    sender = raw.get("sender") or {}
    user_id = str(sender.get("user_id") or raw.get("user_id") or "")
    if not user_id:
        return None
    message_id = str(raw.get("message_id") or raw.get("real_id") or raw.get("seq") or "")
    if not message_id:
        # 用内容 + 时间兜底去重
        message_id = "h" + hashlib.md5(
            f"{group_id}|{user_id}|{raw.get('time')}|{raw.get('raw_message') or raw.get('message')}".encode()
        ).hexdigest()[:16]

    segments = normalize_segments(raw.get("message") if raw.get("message") is not None else raw.get("raw_message"))

    texts: list[str] = []
    has_image = False
    has_at = False
    has_reply = False
    reply_to = ""
    image_hints: list[str] = []
    raw_types: list[str] = []

    for seg in segments:
        stype = str(seg.get("type") or "text")
        data = seg.get("data") or {}
        raw_types.append(stype)
        if stype == "text":
            texts.append(str(data.get("text") or ""))
        elif stype in {"image", "mface"}:
            has_image = True
            if collect_stickers:
                hint = _image_hint(data) if sticker_hint else "图片"
                image_hints.append(hint)
                sub = "表情包" if (data.get("sub_type") == 1 or stype == "mface") else "图片"
                texts.append(f"[{sub}:{hint}]")
        elif stype == "face":
            # 小黄脸表情：id 就是语义，蒸馏很有用
            fid = str(data.get("id") or "")
            if fid and fid.isdigit():
                texts.append(f"[表情:{fid}]")
            else:
                texts.append("[表情]")
        elif stype == "at":
            has_at = True
            qq = str(data.get("qq") or "")
            name = str(data.get("name") or "")
            if qq and qq.isdigit():
                texts.append(f"@{name or qq}")
        elif stype == "reply":
            has_reply = True
            reply_to = str(data.get("id") or "")
        elif stype in {"record", "video"}:
            raw_types.append(stype)
            texts.append(f"[{'语音' if stype == 'record' else '视频'}]")
        elif stype in {"forward", "json", "xml", "share", "music", "file"}:
            texts.append(f"[{stype}消息]")
        elif stype in {"poke", "shake"}:
            texts.append("[戳一戳]")

    text = clean_text("".join(texts))
    if noise_filter and is_noise(text, min_length):
        return None
    if not text:
        return None

    return {
        "uid": f"{platform}:{group_id}:{message_id}",
        "platform": platform,
        "group_id": str(group_id),
        "message_id": message_id,
        "user_id": user_id,
        "nickname": str(sender.get("nickname") or ""),
        "card": str(sender.get("card") or ""),
        "time": int(raw.get("time") or 0),
        "text": text,
        "raw_type": raw_types[0] if raw_types else "text",
        "segments": segments,
        "has_image": has_image,
        "has_at": has_at,
        "has_reply": has_reply,
        "reply_to": reply_to,
        "image_hints": image_hints,
    }


def dedupe(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for r in rows:
        uid = r["uid"]
        if uid in seen:
            continue
        seen.add(uid)
        out.append(r)
    out.sort(key=lambda x: x.get("time", 0))
    return out
