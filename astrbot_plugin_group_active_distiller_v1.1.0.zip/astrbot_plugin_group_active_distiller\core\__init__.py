# -*- coding: utf-8 -*-
"""core 包：存储 / 采集 / 蒸馏 / 提示词。"""

from .store import DistillerStore
from .message_parser import build_record, dedupe, normalize_segments, parse_cq_string
from .collector import GroupCollector, CollectorError
from .distiller import PersonaDistiller, DistillError, extract_json, normalize_persona
from .prompts import render_system_prompt

__all__ = [
    "DistillerStore",
    "build_record",
    "dedupe",
    "normalize_segments",
    "parse_cq_string",
    "GroupCollector",
    "CollectorError",
    "PersonaDistiller",
    "DistillError",
    "extract_json",
    "normalize_persona",
    "render_system_prompt",
]
