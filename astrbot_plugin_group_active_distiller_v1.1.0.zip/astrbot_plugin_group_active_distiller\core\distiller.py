# -*- coding: utf-8 -*-
"""蒸馏引擎：抽样 → 分批 → 调 LLM → 合并 → 落库。

设计取舍：
- **分批而不是一次性喂**：一次喂太多会被截断、被模型忽略中段。
  每批 ``llm_batch_size`` 条，批间重叠 ``llm_batch_overlap`` 条保证上下文连续。
- **并发可控**：``llm_concurrency`` 决定同时几批在飞，默认 1 保守防限流。
- **JSON 兜底**：LLM 常加 ```json 围栏或前后废话，这里做三级解析：
  直解 → 剥围栏 → 截取首个 {...} 配对块。
- **失败不阻塞**：单批失败降级为"跳过该批"，最后用成功的批次合并；
  全失败则任务标记 failed 并写清错误。
"""

from __future__ import annotations

import asyncio
import json
import random
import re
import time
from typing import Any, Callable, Iterable, Optional

from .message_parser import is_filler
from .prompts import (
    DISTILL_SYSTEM_PROMPT,
    MERGE_SYSTEM_PROMPT,
    build_batch_prompt,
    build_merge_prompt,
    render_system_prompt,
)

try:
    from astrbot.api import logger
except Exception:
    import logging

    logger = logging.getLogger("group_active_distiller")

FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.S)


class DistillError(RuntimeError):
    pass


# ---------------------------------------------------------------------- #
#  JSON 解析兜底
# ---------------------------------------------------------------------- #
def extract_json(text: str) -> Optional[dict]:
    """从 LLM 输出里尽最大努力抠出 JSON 对象。"""
    if not text:
        return None
    text = text.strip()

    # 1) 直解
    for candidate in (text,):
        try:
            obj = json.loads(candidate)
            if isinstance(obj, dict):
                return obj
            if isinstance(obj, list) and obj and isinstance(obj[0], dict):
                return obj[0]
        except Exception:
            pass

    # 2) 去 markdown 围栏
    m = FENCE_RE.search(text)
    if m:
        try:
            obj = json.loads(m.group(1).strip())
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass

    # 3) 括号配对截取（从第一个 { 开始找平衡点）
    start = text.find("{")
    while start != -1:
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    chunk = text[start: i + 1]
                    try:
                        obj = json.loads(chunk)
                        if isinstance(obj, dict):
                            return obj
                    except Exception:
                        break
        start = text.find("{", start + 1)
    return None


def normalize_persona(raw: dict, *, nickname: str = "") -> dict:
    """补齐缺失字段，保证前端/投放侧拿到稳定结构。"""
    raw = raw if isinstance(raw, dict) else {}

    def _d(key: str) -> dict:
        val = raw.get(key)
        return val if isinstance(val, dict) else {}

    def _l(key: str, src: Optional[dict] = None) -> list:
        holder = src if src is not None else raw
        val = holder.get(key)
        if isinstance(val, list):
            return val
        if isinstance(val, str) and val.strip():
            return [val.strip()]
        return []

    personality = _d("personality")
    style = _d("speaking_style")
    vocab = _d("vocabulary")
    sticker = _d("sticker_habit")
    inter = _d("interaction_style")

    catchphrases = []
    for c in raw.get("catchphrases") or []:
        if isinstance(c, dict) and c.get("text"):
            catchphrases.append(
                {
                    "text": str(c.get("text"))[:40],
                    "usage": str(c.get("usage") or ""),
                    "frequency": str(c.get("frequency") or "中"),
                }
            )
        elif isinstance(c, str) and c.strip():
            catchphrases.append({"text": c.strip()[:40], "usage": "", "frequency": "中"})

    examples = []
    for e in raw.get("scenario_examples") or []:
        if isinstance(e, dict) and (e.get("typical_reply") or e.get("scene")):
            examples.append(
                {
                    "scene": str(e.get("scene") or ""),
                    "typical_reply": str(e.get("typical_reply") or ""),
                }
            )

    try:
        confidence = float(raw.get("confidence") or 0.0)
    except Exception:
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))

    return {
        "nickname": nickname or str(raw.get("nickname") or ""),
        "summary": str(raw.get("summary") or ""),
        "personality": {
            "traits": [str(x) for x in _l("traits", personality)][:12],
            "social_role": str(personality.get("social_role") or ""),
            "energy": str(personality.get("energy") or ""),
            "humor_style": str(personality.get("humor_style") or ""),
        },
        "speaking_style": {
            "avg_length": str(style.get("avg_length") or ""),
            "sentence_pattern": str(style.get("sentence_pattern") or ""),
            "punctuation": str(style.get("punctuation") or ""),
            "typing_quirks": [str(x) for x in _l("typing_quirks", style)][:10],
            "capitalization": str(style.get("capitalization") or ""),
            "emoji_usage": str(style.get("emoji_usage") or ""),
        },
        "catchphrases": catchphrases[:16],
        "vocabulary": {
            "favorite_words": [str(x) for x in _l("favorite_words", vocab)][:20],
            "slang": [str(x) for x in _l("slang", vocab)][:20],
            "particles": [str(x) for x in _l("particles", vocab)][:15],
            "taboo_words": [str(x) for x in _l("taboo_words", vocab)][:12],
        },
        "sticker_habit": {
            "frequency": str(sticker.get("frequency") or ""),
            "preferred_types": [str(x) for x in _l("preferred_types", sticker)][:10],
            "usage_pattern": str(sticker.get("usage_pattern") or ""),
            "text_faces": [str(x) for x in _l("text_faces", sticker)][:15],
        },
        "interaction_style": {
            "reply_speed": str(inter.get("reply_speed") or ""),
            "at_habit": str(inter.get("at_habit") or ""),
            "topic_driven": [str(x) for x in _l("topic_driven", inter)][:12],
            "conflict_style": str(inter.get("conflict_style") or ""),
        },
        "scenario_examples": examples[:8],
        "avoid": [str(x) for x in _l("avoid")][:12],
        "confidence": confidence,
    }


# ---------------------------------------------------------------------- #
#  蒸馏引擎
# ---------------------------------------------------------------------- #
class PersonaDistiller:
    def __init__(
        self,
        context: Any,
        config: Any,
        store: Any,
        *,
        log: Optional[Callable[[str, str, str], Any]] = None,
    ) -> None:
        self.context = context
        self.config = config
        self.store = store
        self._log = log

    # ---------------------------- 工具 ---------------------------- #
    def _cfg(self, key: str, default: Any = None) -> Any:
        try:
            value = self.config.get(key, default)
        except Exception:
            value = default
        return default if value is None else value

    async def _say(self, scope: str, message: str, level: str = "info") -> None:
        try:
            logger.info(f"[主动蒸馏][{scope}] {message}")
        except Exception:
            pass
        if self._log:
            try:
                await self._log(scope, message, level)
            except Exception:
                pass

    # ---------------------------- 抽样 ---------------------------- #
    def sample_lines(
        self,
        messages: list[dict[str, Any]],
        target_id: str,
        batch_size: int,
        overlap: int,
        *,
        max_batches: int = 0,
        char_limit: int = 0,
    ) -> tuple[list[list[str]], int]:
        """把消息序列切成若干批，批内标记分析对象。

        关键语义（对应「不能全部分批喂 LLM」的修复）：
        - ``max_batches <= 0`` 表示**不限批数，覆盖全部素材**（默认行为）。
        - ``char_limit <= 0``  表示**不按字符截断**（默认行为）。
        - 只有用户显式配置了正数上限才截断，并在日志里说明被截断。

        返回 ``(batches, 采样总字符数)``。
        """
        if not messages:
            return [], 0

        rendered: list[str] = []
        for m in messages:
            text = (m.get("text") or "").strip()
            if not text:
                continue
            if is_filler(text):
                continue
            ts = int(m.get("time") or 0)
            stamp = time.strftime("%m-%d %H:%M", time.localtime(ts)) if ts else "--"
            name = m.get("card") or m.get("nickname") or m.get("user_id") or "?"
            marker = "▶" if str(m.get("user_id")) == str(target_id) else " "
            rendered.append(f"{marker}{stamp} {name}: {text}")

        if not rendered:
            return [], 0

        batch_size = max(20, int(batch_size or 120))
        overlap = max(0, min(batch_size // 2, int(overlap or 0)))
        step = max(1, batch_size - overlap)

        # 全部起点 → 完整覆盖；不打散、不随机抽，保证每条素材都进某一批
        starts = list(range(0, max(1, len(rendered) - batch_size + 1), step))
        if len(rendered) <= batch_size:
            starts = [0]
        # 末尾不足一批的也要带上，否则最后一段永远喂不到
        tail_start = max(0, len(rendered) - batch_size)
        if starts[-1] != tail_start and len(rendered) > batch_size:
            starts.append(tail_start)
        starts = sorted(set(starts))

        if max_batches and max_batches > 0 and len(starts) > max_batches:
            # 用户显式限流时才抽样，但保留首尾，尽量分散
            keep = [starts[0]]
            inner = starts[1:-1]
            need = max(0, max_batches - 2)
            if need and inner:
                pick = random.sample(range(len(inner)), min(need, len(inner)))
                keep.extend(sorted(inner[i] for i in pick))
            if len(starts) > 1:
                keep.append(starts[-1])
            starts = sorted(set(keep))[:max_batches]

        chunks: list[list[str]] = []
        total_chars = 0
        for s in starts:
            chunk = rendered[s: s + batch_size]
            if not chunk:
                continue
            if char_limit and char_limit > 0:
                buf: list[str] = []
                used = 0
                for line in chunk:
                    if used + len(line) > char_limit and buf:
                        break
                    buf.append(line)
                    used += len(line) + 1
                chunk = buf
            if chunk:
                chunks.append(chunk)
                total_chars += sum(len(x) + 1 for x in chunk)
        return chunks, total_chars

    # ---------------------------- LLM ---------------------------- #
    def _resolve_provider(self) -> tuple[Any, str]:
        provider_id = str(self._cfg("llm_provider_id", "") or "").strip()
        if provider_id:
            get_by_id = getattr(self.context, "get_provider_by_id", None)
            if callable(get_by_id):
                try:
                    provider = get_by_id(provider_id=provider_id)
                    if provider is not None:
                        return provider, provider_id
                except Exception:
                    try:
                        provider = get_by_id(provider_id)
                        if provider is not None:
                            return provider, provider_id
                    except Exception:
                        pass
        get_using = getattr(self.context, "get_using_provider", None)
        if callable(get_using):
            try:
                provider = get_using()
                if provider is not None:
                    return provider, ""
            except Exception:
                try:
                    provider = get_using("")
                    if provider is not None:
                        return provider, ""
                except Exception:
                    pass
        return None, provider_id

    async def _llm(self, prompt: str, system_prompt: str) -> str:
        """调用 LLM，带重试与超时。"""
        provider, provider_id = self._resolve_provider()
        if provider is None:
            raise DistillError(
                "没有可用的 LLM 提供商。请在 AstrBot 里配置服务提供商，或在插件配置里指定 llm_provider_id。"
            )

        timeout = max(10, int(self._cfg("llm_timeout_seconds", 180) or 180))
        retries = max(0, int(self._cfg("llm_retry_times", 2) or 0))
        temperature = float(self._cfg("llm_temperature", 0.5) or 0.5)

        last_err: Optional[Exception] = None
        for attempt in range(retries + 1):
            try:
                if hasattr(provider, "text_chat"):
                    result = provider.text_chat(
                        prompt=prompt,
                        system_prompt=system_prompt,
                        session_id=None,
                        persist=False,
                        temperature=temperature,
                    )
                    if asyncio.iscoroutine(result):
                        result = await asyncio.wait_for(result, timeout=timeout)
                    text = self._extract_text(result)
                else:
                    llm_generate = getattr(self.context, "llm_generate", None)
                    if not callable(llm_generate):
                        raise DistillError("当前上下文不支持 LLM 调用（缺 text_chat / llm_generate）")
                    kwargs: dict[str, Any] = {
                        "prompt": prompt,
                        "system_prompt": system_prompt,
                    }
                    if provider_id:
                        kwargs["chat_provider_id"] = provider_id
                    result = await asyncio.wait_for(llm_generate(**kwargs), timeout=timeout)
                    text = self._extract_text(result)
                if text and text.strip():
                    return text
                raise DistillError("LLM 返回空内容")
            except asyncio.TimeoutError:
                last_err = DistillError(f"LLM 调用超时（>{timeout}s）")
            except Exception as exc:
                last_err = exc
            if attempt < retries:
                await asyncio.sleep(min(8, 1.5 * (attempt + 1)))
        raise DistillError(f"LLM 调用失败：{last_err}")

    @staticmethod
    def _extract_text(result: Any) -> str:
        if result is None:
            return ""
        if isinstance(result, str):
            return result
        for attr in ("completion_text", "text", "content"):
            val = getattr(result, attr, None)
            if isinstance(val, str) and val.strip():
                return val
        if isinstance(result, dict):
            for key in ("completion_text", "text", "content", "response", "data"):
                val = result.get(key)
                if isinstance(val, str) and val.strip():
                    return val
                if isinstance(val, dict):
                    inner = val.get("content") or val.get("text")
                    if isinstance(inner, str) and inner.strip():
                        return inner
        return str(result)

    # ---------------------------- 表情包统计 ---------------------------- #
    async def _collect_sticker_stats(
        self,
        group_id: str,
        user_id: str,
        messages: list[dict[str, Any]],
        persona: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """从原始消息与画像里汇总该用户的表情包使用统计。"""
        from collections import Counter

        counter: Counter[tuple[str, str]] = Counter()

        for m in messages:
            text = m.get("text") or ""
            # [表情包:xxx] / [图片:xxx]
            for hit in re.findall(r"\[表情包:([^\]]{1,32})\]", text):
                counter[(hit.strip(), "image")] += 1
            for hit in re.findall(r"\[图片:([^\]]{1,32})\]", text):
                counter[(hit.strip(), "image")] += 1
            # [表情:123]
            for hit in re.findall(r"\[表情:([0-9]{1,6})\]", text):
                counter[(f"小黄脸#{hit}", "face")] += 1

        sticker = (persona or {}).get("sticker_habit") or {}
        for face in sticker.get("text_faces") or []:
            key = str(face).strip()
            if key:
                counter[(key, "text_face")] += 1
        for typ in sticker.get("preferred_types") or []:
            key = str(typ).strip()
            if key:
                counter[(key, "preferred")] += 1

        return [
            {"key": key, "kind": kind, "count": count}
            for (key, kind), count in counter.most_common(40)
            if key
        ]

    # ---------------------------- 主流程 ---------------------------- #
    async def distill_user(
        self,
        group_id: str,
        user_id: str,
        *,
        limit: int = 0,
        job_id: Optional[int] = None,
        on_progress: Optional[Callable[..., Any]] = None,
    ) -> dict[str, Any]:
        async def emit(**kw: Any) -> None:
            if on_progress is None:
                return
            try:
                res = on_progress(**kw)
                if asyncio.iscoroutine(res):
                    await res
            except Exception:
                pass

        group = await self.store.get_group(group_id) or {}
        user = await self.store.get_user(group_id, user_id) or {}
        nickname = user.get("card") or user.get("nickname") or user_id
        group_name = group.get("group_name") or group_id

        since_days = int(self._cfg("recent_sample_window_days", 45) or 0)
        sample_limit = int(limit or self._cfg("default_fetch_count", 800) or 800)
        batch_size = int(self._cfg("llm_batch_size", 120) or 120)
        overlap = int(self._cfg("llm_batch_overlap", 8) or 0)
        concurrency = max(1, int(self._cfg("llm_concurrency", 1) or 1))
        language = str(self._cfg("distill_language", "中文") or "中文")
        extra = str(self._cfg("distill_extra_instruction", "") or "")

        await emit(phase="fetch", index=0, total=0, note="读取消息")
        # 1) 取该用户的消息 + 同群上下文
        target_msgs = await self.store.fetch_messages(
            group_id, user_id, limit=sample_limit, since_days=since_days, newest_first=False
        )
        if not target_msgs:
            raise DistillError(f"群 {group_id} 用户 {user_id} 没有可用消息，先采集。")

        min_msgs = int(self._cfg("auto_distill_min_messages", 60) or 0)
        if len(target_msgs) < min_msgs:
            raise DistillError(
                f"该用户有效消息仅 {len(target_msgs)} 条，低于最低线 {min_msgs}。"
            )

        context_msgs = await self.store.fetch_context(
            group_id,
            limit=min(max(sample_limit * 3, 600), 4000),
            since_days=since_days,
        )
        if not context_msgs:
            context_msgs = target_msgs

        # 默认全量：max_batches / char_limit 为 0 表示不限，把能拿到的全喂进去
        max_batches = int(self._cfg("llm_max_batches", 0) or 0)
        char_limit = int(self._cfg("llm_sample_char_limit", 0) or 0)
        batches, total_chars = self.sample_lines(
            context_msgs, user_id, batch_size, overlap,
            max_batches=max_batches, char_limit=char_limit,
        )
        if not batches:
            raise DistillError("抽样后没有有效素材（可能全被噪声过滤）。")

        await self._say(
            "蒸馏",
            f"{nickname}({user_id}) 目标消息 {len(target_msgs)} 条，上下文 {len(context_msgs)} 条，"
            f"分成 {len(batches)} 批，约 {total_chars} 字"
            + (f"（已按上限截断到 {max_batches} 批）" if max_batches else "（全量覆盖）"),
        )
        await emit(phase="batches", index=0, total=len(batches),
                   note=f"共 {len(batches)} 批，开始逐批分析")

        if job_id:
            await self.store.update_job(
                job_id,
                status="running",
                stage="逐批分析",
                batch_total=len(batches),
                sample_count=len(target_msgs),
                progress=0,
            )

        # 2) 并发跑各批
        sem = asyncio.Semaphore(concurrency)
        done = {"n": 0}
        partials: list[dict] = []

        async def run_batch(idx: int, lines: list[str]) -> Optional[dict]:
            async with sem:
                prompt = build_batch_prompt(
                    target_name=nickname,
                    target_aliases=[],
                    group_name=group_name,
                    lines=lines,
                    total_message_count=len(target_msgs),
                    batch_index=idx + 1,
                    batch_total=len(batches),
                    language=language,
                    extra_instruction=extra,
                )
                try:
                    text = await self._llm(prompt, DISTILL_SYSTEM_PROMPT)
                    obj = extract_json(text)
                    if not obj:
                        raise DistillError("输出里找不到合法 JSON")
                    await self._say("蒸馏", f"第 {idx + 1}/{len(batches)} 批解析成功")
                    return obj
                except Exception as exc:
                    await self._say("蒸馏", f"第 {idx + 1}/{len(batches)} 批失败：{exc}", "warning")
                    return None
                finally:
                    done["n"] += 1
                    if job_id:
                        await self.store.update_job(
                            job_id,
                            batch_done=done["n"],
                            progress=int(done["n"] * 100 / max(1, len(batches))),
                        )
                    await emit(phase="batches", index=done["n"], total=len(batches),
                               note=f"已分析 {done['n']}/{len(batches)} 批")

        results = await asyncio.gather(*[run_batch(i, b) for i, b in enumerate(batches)])
        partials = [r for r in results if r]
        if not partials:
            raise DistillError("所有批次都失败了，检查 LLM 提供商与超时设置。")

        # 3) 合并
        await self._say("蒸馏", f"开始合并 {len(partials)} 份分片画像")
        if job_id:
            await self.store.update_job(job_id, stage="合并画像", progress=90)

        if len(partials) == 1:
            merged = partials[0]
        else:
            try:
                merge_text = await self._llm(
                    build_merge_prompt(
                        target_name=nickname, partials=partials, language=language
                    ),
                    MERGE_SYSTEM_PROMPT,
                )
                merged = extract_json(merge_text) or partials[0]
            except Exception as exc:
                await self._say("蒸馏", f"合并失败，回退首个分片：{exc}", "warning")
                merged = partials[0]

        persona = normalize_persona(merged, nickname=nickname)
        # 融合各分片置信度
        confs = [float(normalize_persona(p).get("confidence") or 0) for p in partials]
        if confs:
            persona["confidence"] = round(
                max(persona.get("confidence") or 0, sum(confs) / len(confs)), 3
            )
        system_prompt = render_system_prompt(persona, nickname)

        # 4) 表情包统计：从该用户原始消息里数 image_hints / face / 文字表情
        sticker_rows = await self._collect_sticker_stats(
            group_id, user_id, target_msgs, persona
        )

        # 5) 落库
        version = await self.store.save_persona(
            group_id=group_id,
            user_id=user_id,
            nickname=nickname,
            persona=persona,
            system_prompt=system_prompt,
            sample_count=len(target_msgs),
            confidence=float(persona.get("confidence") or 0),
            stickers=sticker_rows,
        )

        if job_id:
            await self.store.update_job(
                job_id,
                status="done",
                stage="完成",
                progress=100,
                batch_done=len(batches),
                error="",
            )
        await self._say("蒸馏", f"{nickname} 人设 v{version} 生成完成（置信度 {persona.get('confidence')}）")

        return {
            "group_id": group_id,
            "user_id": user_id,
            "nickname": nickname,
            "version": version,
            "confidence": persona.get("confidence"),
            "batch_total": len(batches),
            "batch_ok": len(partials),
            "sample_count": len(target_msgs),
            "persona": persona,
            "system_prompt": system_prompt,
        }

    async def distill_batch(
        self, group_id: str, top_n: int = 3, min_messages: int = 0
    ) -> list[dict[str, Any]]:
        """对群内发言最多的 N 个人做蒸馏。"""
        users = await self.store.list_users(group_id, limit=max(1, top_n), min_count=min_messages)
        results = []
        for u in users:
            job_id = await self.store.create_job(group_id, u["user_id"])
            try:
                results.append(await self.distill_user(group_id, u["user_id"], job_id=job_id))
            except Exception as exc:
                await self.store.update_job(job_id, status="failed", stage="失败", error=str(exc))
                await self._say("蒸馏", f"{u.get('user_id')} 蒸馏失败：{exc}", "error")
                results.append({"group_id": group_id, "user_id": u.get("user_id"), "error": str(exc)})
        return results

    async def distill_selected_groups(
        self,
        group_ids: Iterable[str],
        *,
        top_n: int = 0,
        min_messages: int = 0,
        on_progress: Optional[Callable[..., Any]] = None,
        job_id: Optional[int] = None,
    ) -> dict[str, Any]:
        """对勾选的一组群，逐群蒸馏其中发言最多的人（问题8：选完直接进蒸馏）。

        top_n=0 表示该群所有达标用户都蒸。
        """
        gids = [str(g) for g in group_ids if str(g).strip()]
        result: dict[str, Any] = {"groups": len(gids), "distilled": 0, "failed": 0, "detail": []}
        if not gids:
            return result

        for idx, gid in enumerate(gids, start=1):
            if on_progress is not None:
                try:
                    res = on_progress(phase="groups", index=idx - 1, total=len(gids),
                                      group_id=gid, note=f"群 {gid}")
                    if asyncio.iscoroutine(res):
                        await res
                except Exception:
                    pass
            group = await self.store.get_group(gid) or {}
            gname = group.get("group_name") or gid
            users = await self.store.list_users(
                gid, limit=(top_n if top_n and top_n > 0 else 500), min_count=min_messages
            )
            await self._say("批量蒸馏", f"群 {gname}({gid}) 待蒸馏 {len(users)} 人")
            for u in users:
                uid = u["user_id"]
                sub_job = await self.store.create_job(gid, uid)
                try:
                    await self.distill_user(gid, uid, job_id=sub_job)
                    result["distilled"] += 1
                    result["detail"].append({"group_id": gid, "user_id": uid, "ok": True})
                except Exception as exc:
                    result["failed"] += 1
                    await self.store.update_job(
                        sub_job, status="failed", stage="失败", error=str(exc)
                    )
                    result["detail"].append(
                        {"group_id": gid, "user_id": uid, "ok": False, "error": str(exc)}
                    )
            if job_id:
                await self.store.update_job(
                    job_id, status="running", stage="批量蒸馏",
                    progress=int(idx * 100 / max(1, len(gids))),
                )
        return result

    # ================================================================== #
    #  以 QQ 号为中心：跨全部群采集 + 跨群蒸馏
    # ================================================================== #
    async def collect_user_everywhere(
        self,
        user_id: str,
        *,
        collector: Any = None,
        fetch_count: int = 0,
        full: bool = False,
        group_ids: Optional[Iterable[str]] = None,
        on_progress: Optional[Callable[..., Any]] = None,
        job_id: Optional[int] = None,
    ) -> dict[str, Any]:
        """先扫出这个 QQ 号出现过的所有群，再对每个群主动拉历史。

        collector 传 GroupCollector；不传则只做本地已有数据的统计。

        ``on_progress`` 是一个回调，形如
        ``async def cb(*, phase, index, total, group_id="", messages=0, note="")``，
        每个群开始时和结束时都会调用一次——这是进度条能动的关键。
        """
        uid = str(user_id).strip()
        if not uid:
            raise DistillError("QQ 号不能为空")

        async def emit(**kw: Any) -> None:
            if on_progress is None:
                return
            try:
                res = on_progress(**kw)
                if asyncio.iscoroutine(res):
                    await res
            except Exception:
                pass

        # 1) 已知出现在哪些群（本地库）
        known = await self.store.user_groups(uid, min_count=1)
        known_ids = [k["group_id"] for k in known]

        scanned: list[dict[str, Any]] = []
        if collector is not None:
            # 2) 主动扫：机器人所在的所有群，逐个拉历史，看这个号在不在
            await self._say("跨群采集", f"开始扫描机器人所在的所有群，查找 {uid}")
            await emit(phase="listing", index=0, total=0, note="正在获取群列表…")
            try:
                groups = await collector.fetch_group_list()
            except Exception as exc:
                await self._say("跨群采集", f"取群列表失败：{exc}", "warning")
                groups = []

            target_ids = [str(g) for g in group_ids] if group_ids else [
                str(g.get("group_id")) for g in groups if g.get("group_id")
            ]
            # 本地已知但机器人列表里没有的，也尝试一次
            for gid in known_ids:
                if gid not in target_ids:
                    target_ids.append(gid)

            name_map: dict[str, str] = {}
            for g in groups:
                gid = str(g.get("group_id") or "")
                if gid:
                    name_map[gid] = str(g.get("group_name") or "")

            await emit(
                phase="scanning", index=0, total=len(target_ids),
                note=f"共 {len(target_ids)} 个群待扫描",
            )

            hit = 0
            for idx, gid in enumerate(target_ids, start=1):
                gname = name_map.get(gid) or gid
                await emit(
                    phase="scanning", index=idx - 1, total=len(target_ids),
                    group_id=gid, note=f"正在读取 {gname}",
                )
                if job_id:
                    await self.store.update_job(
                        job_id, status="running", stage="跨群采集",
                        progress=int((idx - 1) * 100 / max(1, len(target_ids))),
                    )
                try:
                    res = await collector.collect_group(
                        gid, count=fetch_count, full=full
                    )
                    n = await self.store.count_messages(gid, uid)
                    if n > 0:
                        hit += 1
                        scanned.append(
                            {
                                "group_id": gid,
                                "group_name": gname,
                                "messages": n,
                                "fetched": res.get("fetched", 0),
                                "inserted": res.get("inserted", 0),
                            }
                        )
                        await self._say(
                            "跨群采集", f"群 {gname}({gid}) 命中 {uid}：{n} 条（新增 {res.get('inserted', 0)}）"
                        )
                    else:
                        await self._say("跨群采集", f"群 {gname}({gid}) 无该用户消息，跳过")
                except Exception as exc:
                    await self._say("跨群采集", f"群 {gname}({gid}) 采集失败：{exc}", "warning")
                await emit(
                    phase="scanning", index=idx, total=len(target_ids),
                    group_id=gid, messages=n if "n" in dir() else 0,
                    note=f"{gname} 完成（{idx}/{len(target_ids)}）",
                )
            await self._say("跨群采集", f"扫描完成，{hit}/{len(target_ids)} 个群有该用户消息")
        else:
            await emit(phase="local", index=0, total=len(known), note="读取本地已有数据…")
            for idx, k in enumerate(known, start=1):
                n = await self.store.count_messages(k["group_id"], uid)
                scanned.append(
                    {"group_id": k["group_id"], "group_name": k.get("group_name") or "", "messages": n}
                )
                await emit(phase="local", index=idx, total=len(known),
                           group_id=k["group_id"], messages=n, note="本地数据")

        total = sum(s["messages"] for s in scanned)
        await emit(phase="done", index=len(scanned), total=len(scanned),
                   messages=total, note="采集结束")
        return {
            "user_id": uid,
            "groups_scanned": len(scanned),
            "groups_hit": len([s for s in scanned if s["messages"] > 0]),
            "total_messages": total,
            "detail": scanned,
        }

    async def distill_user_global(
        self,
        user_id: str,
        *,
        collector: Any = None,
        collect: bool = True,
        fetch_count: int = 0,
        full: bool = False,
        limit: int = 0,
        job_id: Optional[int] = None,
        group_ids: Optional[Iterable[str]] = None,
        on_progress: Optional[Callable[..., Any]] = None,
    ) -> dict[str, Any]:
        """只给一个 QQ 号：跨群采集 → 全部语料合并 → 分批喂 LLM → 合并人设。"""

        async def emit(**kw: Any) -> None:
            if on_progress is None:
                return
            try:
                res = on_progress(**kw)
                if asyncio.iscoroutine(res):
                    await res
            except Exception:
                pass

        uid = str(user_id).strip()
        if not uid:
            raise DistillError("QQ 号不能为空")

        collect_info: dict[str, Any] = {}
        if collect and collector is not None:
            await emit(phase="collect", index=0, total=0, note="开始跨群采集")
            collect_info = await self.collect_user_everywhere(
                uid, collector=collector, fetch_count=fetch_count, full=full,
                group_ids=group_ids, on_progress=on_progress, job_id=job_id,
            )
            if collect_info["total_messages"] <= 0:
                raise DistillError(
                    f"在机器人所在的 {collect_info.get('groups_scanned', 0)} 个群里"
                    f"都找不到 {uid} 的消息。机器人需要在目标群里，且该号得发过言。"
                )

        # 1) 跨群取该用户全部消息
        await emit(phase="context", index=0, total=0, note="正在打包跨群语料")
        since_days = int(self._cfg("recent_sample_window_days", 45) or 0)
        hard_limit = int(limit or 0) or 200000
        target_msgs = await self.store.fetch_user_messages_global(
            uid, limit=hard_limit, since_days=since_days, group_ids=group_ids
        )
        if not target_msgs:
            raise DistillError(f"库里没有 {uid} 的消息。先执行 /蒸馏 追踪 {uid}")

        min_msgs = int(self._cfg("auto_distill_min_messages", 60) or 0)
        if len(target_msgs) < min_msgs:
            raise DistillError(
                f"{uid} 有效消息仅 {len(target_msgs)} 条，低于最低线 {min_msgs}。"
            )

        # 2) 昵称 / 各群覆盖情况
        gset = []
        for m in target_msgs:
            if m["group_id"] not in gset:
                gset.append(m["group_id"])
        nickname = ""
        for m in reversed(target_msgs):
            if m.get("card") or m.get("nickname"):
                nickname = m.get("card") or m.get("nickname")
                break
        nickname = nickname or uid

        # 3) 上下文：跨群
        context_msgs = await self.store.fetch_context_global(
            uid,
            limit=min(max(len(target_msgs) * 2, 1200), 6000),
            since_days=since_days,
            group_ids=gset,
        )
        if not context_msgs:
            context_msgs = target_msgs

        batch_size = int(self._cfg("llm_batch_size", 120) or 120)
        overlap = int(self._cfg("llm_batch_overlap", 8) or 0)
        concurrency = max(1, int(self._cfg("llm_concurrency", 1) or 1))
        language = str(self._cfg("distill_language", "中文") or "中文")
        extra = str(self._cfg("distill_extra_instruction", "") or "")

        gm_max_batches = int(self._cfg("llm_max_batches", 0) or 0)
        gm_char_limit = int(self._cfg("llm_sample_char_limit", 0) or 0)
        batches, total_chars = self.sample_lines(
            context_msgs, uid, batch_size, overlap,
            max_batches=gm_max_batches, char_limit=gm_char_limit,
        )
        if not batches:
            raise DistillError("抽样后没有有效素材（可能全被噪声过滤）。")

        await self._say(
            "跨群蒸馏",
            f"{nickname}({uid}) 覆盖 {len(gset)} 个群，消息 {len(target_msgs)} 条，"
            f"上下文 {len(context_msgs)} 条，分 {len(batches)} 批，约 {total_chars} 字"
            + (f"（已按上限截断到 {gm_max_batches} 批）" if gm_max_batches else "（全量覆盖）"),
        )

        if job_id:
            await self.store.update_job(
                job_id,
                status="running",
                stage="逐批分析（跨群）",
                batch_total=len(batches),
                sample_count=len(target_msgs),
                progress=0,
            )

        sem = asyncio.Semaphore(concurrency)
        done = {"n": 0}

        async def run_batch(idx: int, lines: list[str]) -> Optional[dict]:
            async with sem:
                prompt = build_batch_prompt(
                    target_name=nickname,
                    target_aliases=[],
                    group_name=f"{len(gset)} 个群（跨群合并样本）",
                    lines=lines,
                    total_message_count=len(target_msgs),
                    batch_index=idx + 1,
                    batch_total=len(batches),
                    language=language,
                    extra_instruction=extra,
                )
                try:
                    text = await self._llm(prompt, DISTILL_SYSTEM_PROMPT)
                    obj = extract_json(text)
                    if not obj:
                        raise DistillError("输出里找不到合法 JSON")
                    await self._say("跨群蒸馏", f"第 {idx + 1}/{len(batches)} 批解析成功")
                    return obj
                except Exception as exc:
                    await self._say(
                        "跨群蒸馏", f"第 {idx + 1}/{len(batches)} 批失败：{exc}", "warning"
                    )
                    return None
                finally:
                    done["n"] += 1
                    if job_id:
                        await self.store.update_job(
                            job_id,
                            batch_done=done["n"],
                            progress=int(done["n"] * 100 / max(1, len(batches))),
                        )
                    await emit(phase="batches", index=done["n"], total=len(batches),
                               note=f"已分析 {done['n']}/{len(batches)} 批")

        results = await asyncio.gather(*[run_batch(i, b) for i, b in enumerate(batches)])
        partials = [r for r in results if r]
        if not partials:
            raise DistillError("所有批次都失败了，检查 LLM 提供商与超时设置。")

        if job_id:
            await self.store.update_job(job_id, stage="合并画像", progress=90)

        if len(partials) == 1:
            merged = partials[0]
        else:
            await self._say("跨群蒸馏", f"合并 {len(partials)} 份分片画像")
            try:
                merged = extract_json(
                    await self._llm(
                        build_merge_prompt(
                            target_name=nickname, partials=partials, language=language
                        ),
                        MERGE_SYSTEM_PROMPT,
                    )
                ) or partials[0]
            except Exception as exc:
                await self._say("跨群蒸馏", f"合并失败，回退首个分片：{exc}", "warning")
                merged = partials[0]

        persona = normalize_persona(merged, nickname=nickname)
        confs = [float(normalize_persona(p).get("confidence") or 0) for p in partials]
        if confs:
            persona["confidence"] = round(
                max(persona.get("confidence") or 0, sum(confs) / len(confs)), 3
            )
        # 记录跨群来源
        persona["source_groups"] = [
            {"group_id": g, "messages": sum(1 for m in target_msgs if m["group_id"] == g)}
            for g in gset
        ]
        system_prompt = render_system_prompt(persona, nickname)

        sticker_rows = await self._collect_sticker_stats(uid, uid, target_msgs, persona)

        version = await self.store.save_persona(
            group_id="*global*",
            user_id=uid,
            nickname=nickname,
            persona=persona,
            system_prompt=system_prompt,
            sample_count=len(target_msgs),
            confidence=float(persona.get("confidence") or 0),
            stickers=sticker_rows,
        )

        if job_id:
            await self.store.update_job(
                job_id, status="done", stage="完成", progress=100,
                batch_done=len(batches), error="",
            )
        await self._say(
            "跨群蒸馏",
            f"{nickname}({uid}) 跨群人设 v{version} 完成，覆盖 {len(gset)} 群 "
            f"{len(target_msgs)} 条（置信度 {persona.get('confidence')}）",
        )

        return {
            "group_id": "*global*",
            "user_id": uid,
            "nickname": nickname,
            "version": version,
            "confidence": persona.get("confidence"),
            "batch_total": len(batches),
            "batch_ok": len(partials),
            "sample_count": len(target_msgs),
            "groups": gset,
            "groups_hit": len(gset),
            "collect": collect_info,
            "persona": persona,
            "system_prompt": system_prompt,
        }
