# -*- coding: utf-8 -*-
"""SQLite 存储层：消息、群登记、蒸馏对象、画像版本、任务日志、表情包统计。

设计要点：
- 单文件 SQLite，WAL 模式，插件重载不掉数据。
- 所有写操作走 ``asyncio.to_thread``，避免阻塞事件循环。
- 表结构带 version 迁移表，后续加字段不会炸掉老库。
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import time
from pathlib import Path
from typing import Any, Iterable, Optional

SCHEMA_VERSION = 4

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- 群登记表
CREATE TABLE IF NOT EXISTS groups (
    group_id      TEXT PRIMARY KEY,
    group_name    TEXT DEFAULT '',
    member_count  INTEGER DEFAULT 0,
    auto_collect  INTEGER DEFAULT 1,
    auto_distill  INTEGER DEFAULT 1,
    note          TEXT DEFAULT '',
    msg_count     INTEGER DEFAULT 0,
    last_msg_time INTEGER DEFAULT 0,
    last_fetch_ts INTEGER DEFAULT 0,
    cursor_seq    TEXT DEFAULT '',
    created_at    INTEGER DEFAULT 0,
    updated_at    INTEGER DEFAULT 0
);

-- 原始消息（去重主键：platform:group:message_id）
CREATE TABLE IF NOT EXISTS messages (
    uid        TEXT PRIMARY KEY,
    platform   TEXT DEFAULT 'qq',
    group_id   TEXT NOT NULL,
    message_id TEXT DEFAULT '',
    user_id    TEXT NOT NULL,
    nickname   TEXT DEFAULT '',
    card       TEXT DEFAULT '',
    time       INTEGER DEFAULT 0,
    text       TEXT DEFAULT '',
    raw_type   TEXT DEFAULT 'text',
    segments   TEXT DEFAULT '[]',
    has_image  INTEGER DEFAULT 0,
    has_at     INTEGER DEFAULT 0,
    has_reply  INTEGER DEFAULT 0,
    reply_to   TEXT DEFAULT '',
    length     INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_messages_group_time ON messages(group_id, time);
CREATE INDEX IF NOT EXISTS idx_messages_group_user_time ON messages(group_id, user_id, time);

-- 群友画像聚合统计（增量维护）
CREATE TABLE IF NOT EXISTS users (
    group_id    TEXT NOT NULL,
    user_id     TEXT NOT NULL,
    nickname    TEXT DEFAULT '',
    card        TEXT DEFAULT '',
    msg_count   INTEGER DEFAULT 0,
    char_count  INTEGER DEFAULT 0,
    image_count INTEGER DEFAULT 0,
    at_count    INTEGER DEFAULT 0,
    reply_count INTEGER DEFAULT 0,
    first_time  INTEGER DEFAULT 0,
    last_time   INTEGER DEFAULT 0,
    distiller_ver INTEGER DEFAULT 0,
    last_distill_ts INTEGER DEFAULT 0,
    PRIMARY KEY (group_id, user_id)
);

-- 蒸馏任务
CREATE TABLE IF NOT EXISTS distill_jobs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id    TEXT NOT NULL,
    user_id     TEXT NOT NULL,
    status      TEXT DEFAULT 'queued',
    stage       TEXT DEFAULT '',
    progress    REAL DEFAULT 0,
    sample_count INTEGER DEFAULT 0,
    batch_total INTEGER DEFAULT 0,
    batch_done  INTEGER DEFAULT 0,
    prompt_tokens INTEGER DEFAULT 0,
    completion_tokens INTEGER DEFAULT 0,
    error       TEXT DEFAULT '',
    created_at  INTEGER DEFAULT 0,
    updated_at  INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON distill_jobs(status, created_at);

-- 任务阶段明细（实时进度 + 预计耗时）
CREATE TABLE IF NOT EXISTS job_steps (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id      INTEGER NOT NULL,
    seq         INTEGER DEFAULT 0,
    name        TEXT DEFAULT '',
    status      TEXT DEFAULT 'pending',
    detail      TEXT DEFAULT '',
    total       INTEGER DEFAULT 0,
    done        INTEGER DEFAULT 0,
    started_at  INTEGER DEFAULT 0,
    finished_at INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_job_steps_job ON job_steps(job_id, seq);

-- 数据库维护：记录已删除的历史任务里的采集明细不用单独建表，
-- 直接复用 job_steps（name='collect:GROUP_ID'）。


-- 画像版本
CREATE TABLE IF NOT EXISTS personas (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id    TEXT NOT NULL,
    user_id     TEXT NOT NULL,
    nickname    TEXT DEFAULT '',
    version     INTEGER DEFAULT 1,
    persona     TEXT DEFAULT '{}',
    system_prompt TEXT DEFAULT '',
    sample_count INTEGER DEFAULT 0,
    confidence  REAL DEFAULT 0,
    created_at  INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_personas_target ON personas(group_id, user_id, version);

-- 表情包/口癖统计（对 LLM 输出做留档，可视化按此排行）
CREATE TABLE IF NOT EXISTS sticker_stats (
    group_id TEXT NOT NULL,
    user_id  TEXT NOT NULL,
    key      TEXT NOT NULL,
    kind     TEXT DEFAULT 'sticker',
    count    INTEGER DEFAULT 0,
    updated_at INTEGER DEFAULT 0,
    PRIMARY KEY (group_id, user_id, key)
);

-- 运行日志（可视化任务流）
CREATE TABLE IF NOT EXISTS logs (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    level   TEXT DEFAULT 'info',
    scope   TEXT DEFAULT '',
    message TEXT DEFAULT '',
    ts      INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_logs_ts ON logs(ts);
"""


def _now() -> int:
    return int(time.time())


class DistillerStore:
    """轻量异步 SQLite 封装。"""

    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()
        self._conn: Optional[sqlite3.Connection] = None

    # ------------------------------------------------------------------ #
    #  基础连接
    # ------------------------------------------------------------------ #
    def _connect(self) -> sqlite3.Connection:
        if self._conn is None:
            conn = sqlite3.connect(str(self.db_path), check_same_thread=False, timeout=30)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA foreign_keys=ON")
            self._conn = conn
        return self._conn

    def init_sync(self) -> None:
        conn = self._connect()
        conn.executescript(SCHEMA_SQL)
        conn.execute(
            "INSERT INTO meta(key, value) VALUES('schema_version', ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (str(SCHEMA_VERSION),),
        )
        conn.commit()

    async def init(self) -> None:
        async with self._lock:
            await asyncio.to_thread(self.init_sync)

    async def close(self) -> None:
        async with self._lock:
            if self._conn is not None:
                await asyncio.to_thread(self._conn.close)
                self._conn = None

    # ------------------------------------------------------------------ #
    #  内部执行器
    # ------------------------------------------------------------------ #
    async def _run(self, fn, *args):
        async with self._lock:
            def _wrapper():
                conn = self._connect()
                try:
                    result = fn(conn, *args)
                    conn.commit()
                    return result
                finally:
                    pass

            return await asyncio.to_thread(_wrapper)

    # ------------------------------------------------------------------ #
    #  群
    # ------------------------------------------------------------------ #
    def _upsert_group_sync(self, conn, group_id: str, name: str = "", member_count: int = 0) -> None:
        conn.execute(
            """
            INSERT INTO groups(group_id, group_name, member_count, created_at, updated_at)
            VALUES(?, ?, ?, ?, ?)
            ON CONFLICT(group_id) DO UPDATE SET
                group_name = CASE WHEN excluded.group_name <> '' THEN excluded.group_name ELSE groups.group_name END,
                member_count = CASE WHEN excluded.member_count > 0 THEN excluded.member_count ELSE groups.member_count END,
                updated_at = excluded.updated_at
            """,
            (group_id, name, member_count, _now(), _now()),
        )

    async def upsert_group(self, group_id: str, name: str = "", member_count: int = 0) -> None:
        await self._run(self._upsert_group_sync, group_id, name, member_count)

    async def list_groups(self) -> list[dict[str, Any]]:
        def _fn(conn):
            rows = conn.execute(
                "SELECT * FROM groups ORDER BY msg_count DESC, updated_at DESC"
            ).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    async def get_group(self, group_id: str) -> Optional[dict[str, Any]]:
        def _fn(conn):
            row = conn.execute("SELECT * FROM groups WHERE group_id=?", (group_id,)).fetchone()
            return dict(row) if row else None

        return await self._run(_fn)

    async def set_group_flag(self, group_id: str, field: str, value: Any) -> None:
        if field not in {"auto_collect", "auto_distill", "note"}:
            return

        def _fn(conn):
            conn.execute(
                f"UPDATE groups SET {field}=?, updated_at=? WHERE group_id=?",
                (value, _now(), group_id),
            )

        await self._run(_fn)

    async def delete_group(self, group_id: str, purge_messages: bool = False) -> None:
        def _fn(conn):
            if purge_messages:
                conn.execute("DELETE FROM messages WHERE group_id=?", (group_id,))
            conn.execute("DELETE FROM groups WHERE group_id=?", (group_id,))

        await self._run(_fn)

    # ------------------------------------------------------------------ #
    #  消息
    # ------------------------------------------------------------------ #
    def _insert_messages_sync(self, conn, rows: list[dict[str, Any]]) -> int:
        if not rows:
            return 0
        payload = [
            (
                r["uid"], r.get("platform", "qq"), r["group_id"], r.get("message_id", ""),
                r["user_id"], r.get("nickname", ""), r.get("card", ""), int(r.get("time", 0)),
                r.get("text", ""), r.get("raw_type", "text"),
                json.dumps(r.get("segments", []), ensure_ascii=False),
                int(bool(r.get("has_image"))), int(bool(r.get("has_at"))),
                int(bool(r.get("has_reply"))), r.get("reply_to", ""), len(r.get("text", "")),
            )
            for r in rows
        ]
        before = conn.total_changes
        conn.executemany(
            """
            INSERT OR IGNORE INTO messages(
                uid, platform, group_id, message_id, user_id, nickname, card, time,
                text, raw_type, segments, has_image, has_at, has_reply, reply_to, length
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            payload,
        )
        inserted = conn.total_changes - before
        for r in rows:
            conn.execute(
                """
                INSERT INTO users(group_id, user_id, nickname, card, msg_count, char_count,
                                  image_count, at_count, reply_count, first_time, last_time)
                VALUES(?,?,?,?,1,?,?,?,?,?,?)
                ON CONFLICT(group_id, user_id) DO UPDATE SET
                    nickname = CASE WHEN excluded.nickname <> '' THEN excluded.nickname ELSE users.nickname END,
                    card = CASE WHEN excluded.card <> '' THEN excluded.card ELSE users.card END,
                    msg_count = users.msg_count + 1,
                    char_count = users.char_count + excluded.char_count,
                    image_count = users.image_count + excluded.image_count,
                    at_count = users.at_count + excluded.at_count,
                    reply_count = users.reply_count + excluded.reply_count,
                    first_time = CASE WHEN users.first_time = 0 THEN excluded.first_time
                                      ELSE MIN(users.first_time, excluded.first_time) END,
                    last_time = MAX(users.last_time, excluded.last_time)
                """,
                (
                    r["group_id"], r["user_id"], r.get("nickname", ""), r.get("card", ""),
                    len(r.get("text", "")), int(bool(r.get("has_image"))),
                    int(bool(r.get("has_at"))), int(bool(r.get("has_reply"))),
                    int(r.get("time", 0)), int(r.get("time", 0)),
                ),
            )
        # 只有真正新增的消息才计入群统计
        touched = sorted({r["group_id"] for r in rows})
        for gid in touched:
            stat = conn.execute(
                "SELECT COUNT(*) AS c, MAX(time) AS t FROM messages WHERE group_id=?", (gid,)
            ).fetchone()
            conn.execute(
                "UPDATE groups SET msg_count=?, last_msg_time=?, updated_at=? WHERE group_id=?",
                (stat["c"] or 0, stat["t"] or 0, _now(), gid),
            )
        return inserted

    async def insert_messages(self, rows: list[dict[str, Any]]) -> int:
        if not rows:
            return 0
        # SQLite 一次太多参数会失败，切片写入
        total = 0
        for i in range(0, len(rows), 200):
            chunk = rows[i: i + 200]
            total += await self._run(self._insert_messages_sync, chunk) or 0
        return total

    async def count_messages(self, group_id: str, user_id: str = "") -> int:
        def _fn(conn):
            if user_id:
                row = conn.execute(
                    "SELECT COUNT(*) AS c FROM messages WHERE group_id=? AND user_id=?",
                    (group_id, user_id),
                ).fetchone()
            else:
                row = conn.execute(
                    "SELECT COUNT(*) AS c FROM messages WHERE group_id=?", (group_id,)
                ).fetchone()
            return int(row["c"] if row else 0)

        return await self._run(_fn) or 0

    async def fetch_messages(
        self,
        group_id: str,
        user_id: str = "",
        limit: int = 500,
        since_days: int = 0,
        min_length: int = 0,
        newest_first: bool = True,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        def _fn(conn):
            sql = "SELECT * FROM messages WHERE group_id=?"
            args: list[Any] = [group_id]
            if user_id:
                sql += " AND user_id=?"
                args.append(user_id)
            if min_length:
                sql += " AND length >= ?"
                args.append(min_length)
            if since_days and since_days > 0:
                sql += " AND time >= ?"
                args.append(_now() - since_days * 86400)
            sql += " ORDER BY time " + ("DESC" if newest_first else "ASC")
            sql += " LIMIT ? OFFSET ?"
            args.extend([int(limit), int(offset)])
            rows = conn.execute(sql, tuple(args)).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    async def fetch_context(
        self, group_id: str, limit: int = 200, since_days: int = 0
    ) -> list[dict[str, Any]]:
        """取整群最近消息（用于蒸馏时还原对话上下文）。"""
        rows = await self.fetch_messages(
            group_id, limit=limit, since_days=since_days, newest_first=True
        )
        rows.reverse()
        return rows

    async def list_users(self, group_id: str, limit: int = 100, min_count: int = 1) -> list[dict[str, Any]]:
        def _fn(conn):
            rows = conn.execute(
                """
                SELECT u.*,
                       (SELECT COUNT(*) FROM personas p
                          WHERE p.group_id=u.group_id AND p.user_id=u.user_id) AS persona_versions
                FROM users u
                WHERE u.group_id=? AND u.msg_count>=?
                ORDER BY u.msg_count DESC
                LIMIT ?
                """,
                (group_id, min_count, limit),
            ).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    # ------------------------------------------------------------------ #
    #  跨群：以 QQ 号为中心
    # ------------------------------------------------------------------ #
    async def user_groups(self, user_id: str, min_count: int = 1) -> list[dict[str, Any]]:
        """该 QQ 号出现过的所有群，带每群消息量。"""
        def _fn(conn):
            rows = conn.execute(
                """
                SELECT u.group_id, u.user_id, u.nickname, u.card, u.msg_count,
                       u.char_count, u.image_count, u.at_count, u.reply_count,
                       u.first_time, u.last_time, u.distiller_ver, u.last_distill_ts,
                       g.group_name, g.member_count
                FROM users u
                LEFT JOIN groups g ON g.group_id = u.group_id
                WHERE u.user_id=? AND u.msg_count>=?
                ORDER BY u.msg_count DESC
                """,
                (user_id, min_count),
            ).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    async def fetch_user_messages_global(
        self,
        user_id: str,
        *,
        limit: int = 5000,
        since_days: int = 0,
        min_length: int = 0,
        group_ids: Optional[Iterable[str]] = None,
    ) -> list[dict[str, Any]]:
        """跨全部群拉某个 QQ 号的消息，按时间正序。"""
        gids = [str(g) for g in group_ids] if group_ids else []

        def _fn(conn):
            sql = "SELECT * FROM messages WHERE user_id=?"
            args: list[Any] = [user_id]
            if gids:
                sql += " AND group_id IN (%s)" % ",".join("?" * len(gids))
                args.extend(gids)
            if min_length:
                sql += " AND length >= ?"
                args.append(int(min_length))
            if since_days and since_days > 0:
                sql += " AND time >= ?"
                args.append(_now() - int(since_days) * 86400)
            sql += " ORDER BY time ASC LIMIT ?"
            args.append(int(limit))
            rows = conn.execute(sql, tuple(args)).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    async def fetch_context_global(
        self,
        user_id: str,
        *,
        limit: int = 3000,
        since_days: int = 0,
        group_ids: Optional[Iterable[str]] = None,
    ) -> list[dict[str, Any]]:
        """跨群取「该用户消息 + 所在群上下文」，按 (群, 时间) 聚合成对话片段。

        为了给 LLM 还原对话，不能只喂目标用户自己的话，还得带上别人的回应。
        """
        gids = [str(g) for g in group_ids] if group_ids else []
        target_rows = await self.fetch_user_messages_global(
            user_id, limit=limit, since_days=since_days, group_ids=gids
        )
        if not target_rows:
            return []

        # 每个群取一段上下文窗口
        per_group: dict[str, int] = {}
        for r in target_rows:
            per_group[r["group_id"]] = per_group.get(r["group_id"], 0) + 1

        windows: list[dict[str, Any]] = []
        share = max(200, int(limit / max(1, len(per_group))))
        for gid in per_group:
            ctx = await self.fetch_context(gid, limit=share, since_days=since_days)
            windows.extend(ctx)

        windows.sort(key=lambda x: (x.get("time") or 0, x.get("uid") or ""))
        # 去重（同一 uid 只留一次）
        seen: set[str] = set()
        out: list[dict[str, Any]] = []
        for r in windows:
            uid = r.get("uid") or f"{r.get('group_id')}:{r.get('message_id')}"
            if uid in seen:
                continue
            seen.add(uid)
            out.append(r)
        return out

    async def count_user_messages(self, user_id: str, group_ids: Optional[Iterable[str]] = None) -> int:
        gids = [str(g) for g in group_ids] if group_ids else []

        def _fn(conn):
            sql = "SELECT COUNT(*) AS c FROM messages WHERE user_id=?"
            args: list[Any] = [user_id]
            if gids:
                sql += " AND group_id IN (%s)" % ",".join("?" * len(gids))
                args.extend(gids)
            row = conn.execute(sql, tuple(args)).fetchone()
            return int(row["c"] if row else 0)

        return await self._run(_fn) or 0

    async def get_user(self, group_id: str, user_id: str) -> Optional[dict[str, Any]]:
        def _fn(conn):
            row = conn.execute(
                "SELECT * FROM users WHERE group_id=? AND user_id=?", (group_id, user_id)
            ).fetchone()
            return dict(row) if row else None

        return await self._run(_fn)

    # ------------------------------------------------------------------ #
    #  蒸馏任务
    # ------------------------------------------------------------------ #
    async def create_job(self, group_id: str, user_id: str) -> int:
        def _fn(conn):
            cur = conn.execute(
                "INSERT INTO distill_jobs(group_id, user_id, status, stage, created_at, updated_at)"
                " VALUES(?,?, 'queued', '排队中', ?, ?)",
                (group_id, user_id, _now(), _now()),
            )
            return int(cur.lastrowid)

        return await self._run(_fn) or 0

    async def update_job(self, job_id: int, **fields: Any) -> None:
        if not fields:
            return
        allowed = {
            "status", "stage", "progress", "sample_count", "batch_total", "batch_done",
            "prompt_tokens", "completion_tokens", "error",
        }
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return
        sets = ", ".join(f"{k}=?" for k in updates)
        args = list(updates.values())

        def _fn(conn):
            conn.execute(
                f"UPDATE distill_jobs SET {sets}, updated_at=? WHERE id=?",
                (*args, _now(), job_id),
            )

        await self._run(_fn)

    async def get_job(self, job_id: int) -> Optional[dict[str, Any]]:
        def _fn(conn):
            row = conn.execute("SELECT * FROM distill_jobs WHERE id=?", (int(job_id),)).fetchone()
            return dict(row) if row else None

        return await self._run(_fn)

    async def cancel_job(self, job_id: int) -> None:
        def _fn(conn):
            conn.execute(
                "UPDATE distill_jobs SET status='canceled', stage='已取消', updated_at=?"
                " WHERE id=? AND status IN ('queued','running')",
                (_now(), int(job_id)),
            )

        await self._run(_fn)

    async def is_job_canceled(self, job_id: int) -> bool:
        row = await self.get_job(job_id)
        return bool(row and row.get("status") == "canceled")

    # -------------------- 任务阶段明细 -------------------- #
    async def add_step(self, job_id: int, name: str, *, total: int = 0, detail: str = "",
                       status: str = "running") -> int:
        def _fn(conn):
            seq = conn.execute(
                "SELECT COALESCE(MAX(seq), 0) + 1 FROM job_steps WHERE job_id=?", (int(job_id),)
            ).fetchone()[0]
            cur = conn.execute(
                "INSERT INTO job_steps(job_id, seq, name, status, detail, total, done,"
                " started_at, finished_at) VALUES(?,?,?,?,?,?,0,?,0)",
                (int(job_id), int(seq), name[:80], status, detail[:500], int(total), _now()),
            )
            return int(cur.lastrowid)

        return await self._run(_fn) or 0

    async def update_step(self, step_id: int, **fields: Any) -> None:
        allowed = {"status", "detail", "total", "done", "finished_at"}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return
        sets = ", ".join(f"{k}=?" for k in updates)
        args = list(updates.values())

        def _fn(conn):
            conn.execute(f"UPDATE job_steps SET {sets} WHERE id=?", (*args, int(step_id)))

        await self._run(_fn)

    async def finish_step(self, step_id: int, *, done: int = 0, detail: str = "",
                          status: str = "done") -> None:
        await self.update_step(
            step_id, status=status, done=int(done), detail=detail[:500], finished_at=_now()
        )

    async def list_steps(self, job_id: int) -> list[dict[str, Any]]:
        def _fn(conn):
            rows = conn.execute(
                "SELECT * FROM job_steps WHERE job_id=? ORDER BY seq ASC", (int(job_id),)
            ).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    async def list_jobs(self, limit: int = 40, status: str = "") -> list[dict[str, Any]]:
        def _fn(conn):
            if status:
                rows = conn.execute(
                    "SELECT * FROM distill_jobs WHERE status=? ORDER BY id DESC LIMIT ?",
                    (status, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM distill_jobs ORDER BY id DESC LIMIT ?", (limit,)
                ).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    async def mark_stale_jobs(self) -> None:
        def _fn(conn):
            conn.execute(
                "UPDATE distill_jobs SET status='failed', stage='中断',"
                " error='插件重启导致任务中断', updated_at=? WHERE status IN ('queued','running')",
                (_now(),),
            )

        await self._run(_fn)

    # ------------------------------------------------------------------ #
    #  画像
    # ------------------------------------------------------------------ #
    async def save_persona(
        self,
        group_id: str,
        user_id: str,
        nickname: str,
        persona: dict[str, Any],
        system_prompt: str,
        sample_count: int,
        confidence: float,
        stickers: Iterable[dict[str, Any]] = (),
    ) -> int:
        def _fn(conn):
            row = conn.execute(
                "SELECT MAX(version) AS v FROM personas WHERE group_id=? AND user_id=?",
                (group_id, user_id),
            ).fetchone()
            version = int((row["v"] or 0)) + 1
            conn.execute(
                "INSERT INTO personas(group_id, user_id, nickname, version, persona,"
                " system_prompt, sample_count, confidence, created_at)"
                " VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    group_id, user_id, nickname, version,
                    json.dumps(persona, ensure_ascii=False), system_prompt,
                    sample_count, confidence, _now(),
                ),
            )
            for item in stickers:
                key = str(item.get("key") or "").strip()
                if not key:
                    continue
                conn.execute(
                    """
                    INSERT INTO sticker_stats(group_id, user_id, key, kind, count, updated_at)
                    VALUES(?,?,?,?,?,?)
                    ON CONFLICT(group_id, user_id, key) DO UPDATE SET
                        count = excluded.count, kind = excluded.kind, updated_at = excluded.updated_at
                    """,
                    (group_id, user_id, key, item.get("kind", "sticker"),
                     int(item.get("count", 1) or 1), _now()),
                )
            conn.execute(
                "UPDATE users SET distiller_ver=?, last_distill_ts=? WHERE group_id=? AND user_id=?",
                (version, _now(), group_id, user_id),
            )
            return version

        return await self._run(_fn) or 0

    async def list_personas(
        self, group_id: str = "", user_id: str = "", limit: int = 200
    ) -> list[dict[str, Any]]:
        def _fn(conn):
            sql = """
            SELECT p.* FROM personas p
            JOIN (SELECT group_id, user_id, MAX(version) AS mv FROM personas
                  GROUP BY group_id, user_id) m
              ON p.group_id=m.group_id AND p.user_id=m.user_id AND p.version=m.mv
            WHERE 1=1
            """
            args: list[Any] = []
            if group_id:
                sql += " AND p.group_id=?"
                args.append(group_id)
            if user_id:
                sql += " AND p.user_id=?"
                args.append(user_id)
            sql += " ORDER BY p.created_at DESC LIMIT ?"
            args.append(limit)
            rows = conn.execute(sql, tuple(args)).fetchall()
            out = []
            for r in rows:
                d = dict(r)
                try:
                    d["persona"] = json.loads(d.get("persona") or "{}")
                except Exception:
                    d["persona"] = {}
                out.append(d)
            return out

        return await self._run(_fn) or []

    async def get_persona(self, group_id: str, user_id: str, version: int = 0) -> Optional[dict[str, Any]]:
        if version:
            def _fn(conn):
                row = conn.execute(
                    "SELECT * FROM personas WHERE group_id=? AND user_id=? AND version=?"
                    " ORDER BY id DESC LIMIT 1",
                    (group_id, user_id, int(version)),
                ).fetchone()
                if not row:
                    return None
                d = dict(row)
                try:
                    d["persona"] = json.loads(d.get("persona") or "{}")
                except Exception:
                    d["persona"] = {}
                return d

            return await self._run(_fn)

        rows = await self.list_personas(group_id, user_id, limit=200)
        if not rows:
            return None
        return max(rows, key=lambda r: int(r["version"]))

    async def persona_versions(self, group_id: str, user_id: str) -> list[dict[str, Any]]:
        def _fn(conn):
            rows = conn.execute(
                "SELECT id, version, sample_count, confidence, created_at FROM personas"
                " WHERE group_id=? AND user_id=? ORDER BY version DESC",
                (group_id, user_id),
            ).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    async def stickers(self, group_id: str, user_id: str = "", limit: int = 60) -> list[dict[str, Any]]:
        def _fn(conn):
            if user_id:
                rows = conn.execute(
                    "SELECT * FROM sticker_stats WHERE group_id=? AND user_id=?"
                    " ORDER BY count DESC LIMIT ?",
                    (group_id, user_id, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM sticker_stats WHERE group_id=? ORDER BY count DESC LIMIT ?",
                    (group_id, limit),
                ).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    # ------------------------------------------------------------------ #
    #  批量操作（一键全选 / 一键开关）
    # ------------------------------------------------------------------ #
    async def set_all_group_flags(self, field: str, value: Any,
                                  group_ids: Optional[Iterable[str]] = None) -> int:
        """批量设置 auto_collect / auto_distill。传 group_ids 则只改这些群。"""
        if field not in {"auto_collect", "auto_distill"}:
            return 0
        gids = [str(g) for g in group_ids] if group_ids else []

        def _fn(conn):
            if gids:
                ph = ",".join("?" * len(gids))
                cur = conn.execute(
                    f"UPDATE groups SET {field}=?, updated_at=? WHERE group_id IN ({ph})",
                    (value, _now(), *gids),
                )
            else:
                cur = conn.execute(
                    f"UPDATE groups SET {field}=?, updated_at=?",
                    (value, _now()),
                )
            return int(cur.rowcount or 0)

        return await self._run(_fn) or 0

    # ------------------------------------------------------------------ #
    #  数据库维护
    # ------------------------------------------------------------------ #
    def _db_stats_sync(self, conn) -> dict[str, Any]:
        def one(sql: str, *args):
            row = conn.execute(sql, args).fetchone()
            return int(row[0] or 0) if row else 0

        # 表行数与占用页数
        tables = [
            "groups", "messages", "users", "personas", "sticker_stats",
            "distill_jobs", "job_steps", "logs",
        ]
        rows: list[dict[str, Any]] = []
        for t in tables:
            try:
                cnt = one(f"SELECT COUNT(*) FROM {t}")
            except Exception:
                cnt = 0
            rows.append({"table": t, "rows": cnt})
        wal_path = self.db_path.with_name(self.db_path.name + "-wal")
        page_size = one("PRAGMA page_size")
        page_count = one("PRAGMA page_count")
        free_pages = one("PRAGMA freelist_count")
        return {
            "path": str(self.db_path),
            "file_size": self.db_path.stat().st_size if self.db_path.exists() else 0,
            "wal": wal_path.stat().st_size if wal_path.exists() else 0,
            "page_size": page_size,
            "page_count": page_count,
            "free_pages": free_pages,
            "reclaimable": free_pages * page_size,
            "tables": rows,
        }

    async def db_stats(self) -> dict[str, Any]:
        return await self._run(self._db_stats_sync) or {}

    async def vacuum(self) -> dict[str, Any]:
        """SQLite VACUUM：重写文件，回收空间。不能在事务里跑。"""
        def _fn(conn):
            # 先 checkpoint，把 -wal 里的数据合并回主文件，否则 file_size 是假的
            try:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except Exception:
                pass
            before = self.db_path.stat().st_size if self.db_path.exists() else 0
            old_iso = conn.isolation_level
            try:
                conn.isolation_level = None
                conn.execute("VACUUM")
            finally:
                conn.isolation_level = old_iso
            try:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except Exception:
                pass
            after = self.db_path.stat().st_size if self.db_path.exists() else 0
            wal_path = self.db_path.with_name(self.db_path.name + "-wal")
            wal_size = wal_path.stat().st_size if wal_path.exists() else 0
            return {
                "before": before,
                "after": after,
                "freed": max(0, before - after),
                "wal": wal_size,
            }

        return await self._run(_fn) or {}

    async def prune(self, scope: str, *, keep_days: int = 0,
                    group_id: str = "") -> dict[str, Any]:
        """按范围清理数据。

        scope 取值：
        - ``messages``     清消息（可带 group_id / keep_days）
        - ``logs``         清运行日志
        - ``jobs``         清已完成/失败/取消的任务及其阶段
        - ``personas``     清全部画像
        - ``stickers``     清表情包统计
        - ``all_data``     清 messages + users + personas + sticker_stats + jobs(已结束)
        - ``everything``   以上全部 + groups + logs
        """
        scope = (scope or "").strip()

        def _fn(conn):
            def cnt(sql: str, *a) -> int:
                row = conn.execute(sql, a).fetchone()
                return int(row[0] or 0) if row else 0

            removed: dict[str, int] = {}
            cutoff = _now() - int(keep_days) * 86400 if keep_days else 0
            gid = (group_id or "").strip()

            def del_messages() -> None:
                if gid and cutoff:
                    removed["messages"] = cnt(
                        "SELECT COUNT(*) FROM messages WHERE group_id=? AND time<?", gid, cutoff
                    )
                    conn.execute("DELETE FROM messages WHERE group_id=? AND time<?", (gid, cutoff))
                elif gid:
                    removed["messages"] = cnt("SELECT COUNT(*) FROM messages WHERE group_id=?", gid)
                    conn.execute("DELETE FROM messages WHERE group_id=?", (gid,))
                elif cutoff:
                    removed["messages"] = cnt("SELECT COUNT(*) FROM messages WHERE time<?", cutoff)
                    conn.execute("DELETE FROM messages WHERE time<?", (cutoff,))
                else:
                    removed["messages"] = cnt("SELECT COUNT(*) FROM messages")
                    conn.execute("DELETE FROM messages")

            def del_users() -> None:
                if gid:
                    removed["users"] = cnt("SELECT COUNT(*) FROM users WHERE group_id=?", gid)
                    conn.execute("DELETE FROM users WHERE group_id=?", (gid,))
                else:
                    removed["users"] = cnt("SELECT COUNT(*) FROM users")
                    conn.execute("DELETE FROM users")

            def del_personas() -> None:
                if gid:
                    removed["personas"] = cnt("SELECT COUNT(*) FROM personas WHERE group_id=?", gid)
                    conn.execute("DELETE FROM personas WHERE group_id=?", (gid,))
                else:
                    removed["personas"] = cnt("SELECT COUNT(*) FROM personas")
                    conn.execute("DELETE FROM personas")

            def del_stickers() -> None:
                if gid:
                    removed["stickers"] = cnt(
                        "SELECT COUNT(*) FROM sticker_stats WHERE group_id=?", gid
                    )
                    conn.execute("DELETE FROM sticker_stats WHERE group_id=?", (gid,))
                else:
                    removed["stickers"] = cnt("SELECT COUNT(*) FROM sticker_stats")
                    conn.execute("DELETE FROM sticker_stats")

            def del_jobs() -> None:
                removed["jobs"] = cnt(
                    "SELECT COUNT(*) FROM distill_jobs WHERE status NOT IN ('queued','running')"
                )
                conn.execute(
                    "DELETE FROM job_steps WHERE job_id IN"
                    " (SELECT id FROM distill_jobs WHERE status NOT IN ('queued','running'))"
                )
                conn.execute(
                    "DELETE FROM distill_jobs WHERE status NOT IN ('queued','running')"
                )

            def del_logs() -> None:
                removed["logs"] = cnt("SELECT COUNT(*) FROM logs")
                conn.execute("DELETE FROM logs")

            if scope == "messages":
                del_messages()
                del_users()
            elif scope == "logs":
                del_logs()
            elif scope == "jobs":
                del_jobs()
            elif scope == "personas":
                del_personas()
                del_stickers()
            elif scope == "stickers":
                del_stickers()
            elif scope == "all_data":
                del_messages()
                del_users()
                del_personas()
                del_stickers()
                del_jobs()
            elif scope == "everything":
                del_messages()
                del_users()
                del_personas()
                del_stickers()
                del_jobs()
                del_logs()
                if gid:
                    conn.execute("DELETE FROM groups WHERE group_id=?", (gid,))
                else:
                    removed["groups"] = cnt("SELECT COUNT(*) FROM groups")
                    conn.execute("DELETE FROM groups")
            else:
                raise ValueError(f"未知清理范围: {scope}")

            # 群统计回写
            if scope in {"messages", "all_data", "everything"}:
                if gid:
                    conn.execute(
                        "UPDATE groups SET msg_count=0, last_msg_time=0 WHERE group_id=?", (gid,)
                    )
                else:
                    conn.execute("UPDATE groups SET msg_count=0, last_msg_time=0")
            return removed

        return await self._run(_fn) or {}

    async def optimize(self) -> dict[str, Any]:
        """ANALYZE + 重建索引，查询更快。"""
        def _fn(conn):
            conn.execute("ANALYZE")
            conn.execute("PRAGMA optimize")
            return {"ok": True}

        return await self._run(_fn) or {}

    # ------------------------------------------------------------------ #
    #  日志
    # ------------------------------------------------------------------ #
    async def log(self, scope: str, message: str, level: str = "info") -> None:
        def _fn(conn):
            conn.execute(
                "INSERT INTO logs(level, scope, message, ts) VALUES(?,?,?,?)",
                (level, scope, message[:2000], _now()),
            )
            # 只保留最近 3000 条
            conn.execute(
                "DELETE FROM logs WHERE id < (SELECT MAX(id) - 3000 FROM logs)"
            )

        try:
            await self._run(_fn)
        except Exception:
            pass

    async def recent_logs(self, limit: int = 80) -> list[dict[str, Any]]:
        def _fn(conn):
            rows = conn.execute(
                "SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

        return await self._run(_fn) or []

    # ------------------------------------------------------------------ #
    #  统计总览
    # ------------------------------------------------------------------ #
    async def overview(self) -> dict[str, Any]:
        def _fn(conn):
            def one(sql: str, *args):
                row = conn.execute(sql, args).fetchone()
                return row[0] if row else 0

            return {
                "groups": one("SELECT COUNT(*) FROM groups"),
                "messages": one("SELECT COUNT(*) FROM messages"),
                "users": one("SELECT COUNT(*) FROM users"),
                "personas": one("SELECT COUNT(DISTINCT group_id || ':' || user_id) FROM personas"),
                "persona_versions": one("SELECT COUNT(*) FROM personas"),
                "stickers": one("SELECT COUNT(*) FROM sticker_stats"),
                "jobs_today": one(
                    "SELECT COUNT(*) FROM distill_jobs WHERE created_at >= ?",
                    _now() - 86400,
                ),
                "last_message_time": one("SELECT MAX(time) FROM messages"),
                "last_collect": one("SELECT MAX(last_fetch_ts) FROM groups"),
            }

        return await self._run(_fn) or {}
