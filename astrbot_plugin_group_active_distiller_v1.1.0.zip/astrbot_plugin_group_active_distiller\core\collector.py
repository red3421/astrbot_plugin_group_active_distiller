# -*- coding: utf-8 -*-
"""主动采集器：主动搜群 + 分页拉历史 + 增量入库。

与被动蒸馏插件的区别：不等群里有人说话，自己去找群、往回翻历史。

平台接入策略（按优先级）：
1. AstrBot ``context.platform_manager.get_insts()`` → 平台实例 → ``get_client()/bot``
   → OneBot v11 ``call_action``（NapCat / LLOneBot / Lagrange / go-cqhttp 通用）
2. 事件自带 ``event.bot``（收到消息时顺带采集）
所有 OneBot 调用都做了参数兼容与失败降级，避免某个后端不认某个字段就整轮挂掉。
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Callable, Optional

try:  # AstrBot 运行时
    from astrbot.api import logger
except Exception:  # 本地自测
    import logging

    logger = logging.getLogger("group_active_distiller")


class CollectorError(RuntimeError):
    pass


class GroupCollector:
    """封装所有 QQ/OneBot 侧的数据获取动作。"""

    def __init__(
        self,
        context: Any,
        config: Any,
        store: Any,
        *,
        platform_name: str = "qq",
        log: Optional[Callable[[str, str, str], Any]] = None,
    ) -> None:
        self.context = context
        self.config = config
        self.store = store
        self.platform_name = platform_name
        self._log = log
        self._bot_cache: dict[str, Any] = {}

    # ------------------------------------------------------------------ #
    #  工具
    # ------------------------------------------------------------------ #
    def _cfg(self, key: str, default: Any = None) -> Any:
        try:
            value = self.config.get(key, default)
        except Exception:
            value = default
        return default if value is None else value

    async def _say(self, scope: str, message: str, level: str = "info") -> None:
        try:
            logger.info(f"[主动蒸馏][{scope}] {message}")
        except Exception:
            pass
        if self._log:
            try:
                await self._log(scope, message, level)
            except Exception:
                pass

    # ------------------------------------------------------------------ #
    #  平台实例解析
    # ------------------------------------------------------------------ #
    def resolve_platforms(self) -> list[Any]:
        """返回所有 AstrBot 平台实例（含 onebot 等）。"""
        pm = getattr(self.context, "platform_manager", None)
        get_insts = getattr(pm, "get_insts", None)
        if callable(get_insts):
            try:
                raw = get_insts()
                return list(raw) if isinstance(raw, (list, tuple)) else []
            except Exception as exc:
                logger.debug(f"[主动蒸馏] get_insts 失败: {exc}")
        return []

    @staticmethod
    def _extract_client(platform: Any) -> Any:
        for attr in ("lark_api",):
            client = getattr(platform, attr, None)
            if client is not None:
                return client
        get_client = getattr(platform, "get_client", None)
        if callable(get_client):
            try:
                client = get_client()
                if client is not None:
                    return client
            except Exception:
                pass
        for attr in ("bot", "client", "api"):
            client = getattr(platform, attr, None)
            if client is not None:
                return client
        return None

    @staticmethod
    def _platform_id(platform: Any) -> str:
        meta = getattr(platform, "metadata", None)
        if meta is not None:
            pid = getattr(meta, "id", None)
            if pid is not None:
                return str(pid)
        meta_fn = getattr(platform, "meta", None)
        if callable(meta_fn):
            try:
                m = meta_fn()
                pid = getattr(m, "id", None)
                if pid is not None:
                    return str(pid)
            except Exception:
                pass
        for attr in ("self_id", "id", "bot_id"):
            val = getattr(platform, attr, None)
            if isinstance(val, (str, int)):
                return str(val)
        return ""

    def get_bots(self) -> list[tuple[str, Any]]:
        """返回 [(platform_id, client)]，只保留支持 call_action 的。"""
        bots: list[tuple[str, Any]] = []
        for platform in self.resolve_platforms():
            client = self._extract_client(platform)
            if client is None or not hasattr(client, "call_action"):
                continue
            pid = self._platform_id(platform)
            bots.append((pid, client))
            if pid:
                self._bot_cache[pid] = client
        # 补上事件里见过的 bot
        for pid, client in list(self._bot_cache.items()):
            if all(client is not c for _, c in bots):
                bots.append((pid, client))
        return bots

    def remember_bot(self, event: Any) -> None:
        """收到消息时把 event.bot / event 的 client 记下来，作为采集通道。"""
        try:
            client = getattr(event, "bot", None)
            if client is not None and hasattr(client, "call_action"):
                pid = ""
                getter = getattr(event, "get_platform_name", None)
                if callable(getter):
                    try:
                        pid = str(getter())
                    except Exception:
                        pid = ""
                self._bot_cache[pid or f"event_{len(self._bot_cache)}"] = client
        except Exception:
            pass

    def pick_bot(self) -> tuple[Optional[str], Any]:
        bots = self.get_bots()
        if not bots:
            return None, None
        return bots[0]

    # ------------------------------------------------------------------ #
    #  OneBot 调用封装
    # ------------------------------------------------------------------ #
    async def call_action(self, action: str, **params: Any) -> Any:
        pid, bot = self.pick_bot()
        if bot is None:
            raise CollectorError(
                "找不到可用的 OneBot 连接。请确认已配置 aiocqhttp/NapCat 适配器并在线。"
            )
        try:
            result = bot.call_action(action, **params)
            if asyncio.iscoroutine(result):
                result = await result
            return result
        except Exception as exc:
            raise CollectorError(f"调用 OneBot API `{action}` 失败: {exc}") from exc

    async def call_action_compat(
        self, actions: list[tuple[str, dict[str, Any]]]
    ) -> Any:
        """按顺序尝试多个 action/参数组合，任一成功即返回。"""
        last_err: Optional[Exception] = None
        for action, params in actions:
            try:
                return await self.call_action(action, **params)
            except Exception as exc:
                last_err = exc
                continue
        raise CollectorError(f"全部接口调用失败: {last_err}")

    # ------------------------------------------------------------------ #
    #  主动搜群
    # ------------------------------------------------------------------ #
    async def fetch_group_list(self) -> list[dict[str, Any]]:
        """拿到机器人所在的所有群。"""
        data = await self.call_action_compat(
            [
                ("get_group_list", {"no_cache": False}),
                ("get_group_list", {}),
            ]
        )
        groups = data if isinstance(data, list) else (data or {}).get("data") or []
        out: list[dict[str, Any]] = []
        for g in groups:
            if not isinstance(g, dict):
                continue
            gid = str(g.get("group_id") or g.get("group") or g.get("id") or "")
            if not gid:
                continue
            out.append(
                {
                    "group_id": gid,
                    "group_name": str(g.get("group_name") or g.get("name") or ""),
                    "member_count": int(g.get("member_count") or g.get("memberCount") or 0),
                }
            )
        return out

    async def search_groups(self, keyword: str = "") -> list[dict[str, Any]]:
        """主动搜群。

        优先用 ``get_group_list`` 本地过滤（不依赖群搜索权限）；
        若后端支持 ``search_group``/``get_group_info`` 则进一步补全详情。
        """
        groups = await self.fetch_group_list()
        keyword = (keyword or "").strip()
        if keyword:
            kw = keyword.lower()
            groups = [
                g for g in groups
                if kw in g["group_name"].lower() or kw in g["group_id"]
            ]
        # 尝试补全群名（部分后端 get_group_list 不返回名称）
        need_detail = [g for g in groups if not g["group_name"]]
        for g in need_detail[:20]:
            try:
                info = await self.call_action("get_group_info", group_id=int(g["group_id"]))
                if isinstance(info, dict):
                    data = info.get("data") if isinstance(info.get("data"), dict) else info
                    g["group_name"] = str(data.get("group_name") or data.get("name") or "")
                    g["member_count"] = int(
                        data.get("member_count") or data.get("memberCount") or g["member_count"]
                    )
            except Exception:
                pass
        return groups

    async def register_groups(self, groups: list[dict[str, Any]]) -> int:
        count = 0
        for g in groups:
            await self.store.upsert_group(
                g["group_id"], g.get("group_name", ""), int(g.get("member_count") or 0)
            )
            count += 1
        return count

    # ------------------------------------------------------------------ #
    #  主动拉历史
    # ------------------------------------------------------------------ #
    async def fetch_group_history(
        self,
        group_id: str,
        count: int = 300,
        since_ts: int = 0,
        anchor: str = "",
    ) -> tuple[list[dict[str, Any]], str]:
        """分页往回拉群历史。

        返回 (按时间正序的原始消息列表, 最新锚点)。
        """
        page_size = max(20, min(200, int(self._cfg("fetch_page_size", 100) or 100)))
        interval = max(0, int(self._cfg("fetch_page_interval_ms", 260) or 0)) / 1000.0
        collected: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        current_anchor = anchor
        newest_anchor = ""
        loops = 0
        max_loops = max(1, (count // page_size) + 3)

        while len(collected) < count and loops < max_loops:
            loops += 1
            params: dict[str, Any] = {
                "group_id": int(group_id),
                "count": min(page_size, count - len(collected) + page_size),
                "reverseOrder": True,
            }
            if current_anchor:
                # NapCat / LLOneBot 用 message_seq，go-cqhttp 用 message_id
                params["message_seq"] = current_anchor
            try:
                result = await self.call_action_compat(
                    [
                        ("get_group_msg_history", dict(params)),
                        ("get_group_msg_history", {k: v for k, v in params.items() if k != "reverseOrder"}),
                        ("get_group_msg_history", {"group_id": int(group_id), "count": params["count"]}),
                    ]
                )
            except CollectorError as exc:
                await self._say("采集", f"群 {group_id} 历史拉取失败: {exc}", "warning")
                break

            if isinstance(result, dict) and "data" in result and isinstance(result["data"], dict):
                result = result["data"]
            messages = (result or {}).get("messages") if isinstance(result, dict) else result
            if not messages:
                break

            if not newest_anchor:
                newest_anchor = self._anchor_of(messages[0])

            added = 0
            for raw in messages:
                mid = str(raw.get("message_id") or raw.get("real_id") or raw.get("seq") or "")
                key = mid or f"{raw.get('time')}|{raw.get('user_id')}"
                if key in seen_ids:
                    continue
                seen_ids.add(key)
                msg_time = int(raw.get("time") or 0)
                if since_ts and msg_time and msg_time < since_ts:
                    continue
                collected.append(raw)
                added += 1

            if added == 0:
                break

            # 最早的一条作为下一轮锚点
            earliest = min(messages, key=lambda m: int(m.get("time") or 0))
            new_anchor = self._anchor_of(earliest)
            if not new_anchor or new_anchor == current_anchor:
                break
            current_anchor = new_anchor

            if since_ts:
                earliest_time = int(earliest.get("time") or 0)
                if earliest_time and earliest_time < since_ts:
                    break
            if interval:
                await asyncio.sleep(interval)

        collected.sort(key=lambda m: int(m.get("time") or 0))
        return collected, newest_anchor

    @staticmethod
    def _anchor_of(raw: dict[str, Any]) -> str:
        for key in ("message_seq", "real_id", "seq", "message_id"):
            val = raw.get(key)
            if val not in (None, "", 0):
                return str(val)
        return ""

    # ------------------------------------------------------------------ #
    #  采集一轮
    # ------------------------------------------------------------------ #
    async def collect_group(
        self,
        group_id: str,
        count: int = 0,
        full: bool = False,
        parser_opts: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        from .message_parser import build_record, dedupe

        opts = parser_opts or {}
        group = await self.store.get_group(group_id) or {}
        last_fetch = int(group.get("last_fetch_ts") or 0)
        cursor = str(group.get("cursor_seq") or "")

        if full or not last_fetch:
            count = count or int(self._cfg("default_fetch_count", 800) or 800)
            since_ts = 0
            anchor = ""
        else:
            count = count or int(self._cfg("incremental_fetch_count", 300) or 300)
            since_ts = 0  # 用游标翻页即可，时间过滤交给去重
            anchor = cursor

        await self._say("采集", f"开始采集群 {group_id}（{'全量' if not anchor else '增量'}，上限 {count} 条）")

        raw_messages, newest_anchor = await self.fetch_group_history(
            group_id, count=count, since_ts=since_ts, anchor=anchor
        )

        rows: list[dict[str, Any]] = []
        for raw in raw_messages:
            rec = build_record(
                platform=self.platform_name,
                group_id=group_id,
                raw=raw,
                collect_stickers=bool(self._cfg("collect_stickers", True)),
                sticker_hint=bool(self._cfg("sticker_ocr_enabled", True)),
                noise_filter=bool(self._cfg("noise_filter_enabled", True)),
                min_length=int(self._cfg("min_message_length", 1) or 0),
            )
            if rec:
                rows.append(rec)
        rows = dedupe(rows)

        inserted = await self.store.insert_messages(rows)

        def _update(conn):
            conn.execute(
                "UPDATE groups SET last_fetch_ts=?, cursor_seq=?, updated_at=? WHERE group_id=?",
                (int(time.time()), newest_anchor or cursor, int(time.time()), group_id),
            )

        await self.store._run(_update)

        result = {
            "group_id": group_id,
            "fetched": len(raw_messages),
            "parsed": len(rows),
            "inserted": inserted,
        }
        await self._say(
            "采集",
            f"群 {group_id} 完成：拉取 {result['fetched']}，入库新增 {inserted}，有效 {len(rows)}",
        )
        return result

    async def collect_all(self, only_auto: bool = True) -> list[dict[str, Any]]:
        """按配置对所有已登记群跑一轮增量采集。"""
        groups = await self.store.list_groups()
        if only_auto:
            groups = [g for g in groups if int(g.get("auto_collect") or 0) == 1]
        limit = int(self._cfg("max_groups_per_round", 8) or 8)
        results = []
        for g in groups[:limit]:
            try:
                results.append(await self.collect_group(g["group_id"]))
            except Exception as exc:
                await self._say("采集", f"群 {g['group_id']} 采集异常: {exc}", "error")
                results.append({"group_id": g["group_id"], "error": str(exc)})
        return results
