/* 群友主动蒸馏器 · 蒸馏台前端逻辑（重做版）
 * 页签：按QQ号蒸馏 / 群管理 / 蒸馏任务 / 参数配置 / 数据库 / 运行日志
 * 核心变化：
 *   1) 画像直接显示在「按QQ号蒸馏」页，不再需要跳页
 *   2) 采集→分批→合并 全程实时进度 + 预计剩余时间 + 阶段明细
 *   3) 群覆盖表可勾选，勾完直接进蒸馏
 *   4) 群管理支持一键全选 + 批量开关自动采集/自动蒸馏
 *   5) 独立数据库页：表行数、体积、VACUUM、一键清理
 */

import { apiGet, apiPost, toast } from "./page_bridge.js";

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const state = {
  groups: [],
  currentGroup: "",
  persona: null,
  config: { schema: {}, values: {} },
  selectedGroups: new Set(),
};

/* ------------------------------------------------------------------ */
/*  工具                                                               */
/* ------------------------------------------------------------------ */
function esc(str) {
  return String(str == null ? "" : str)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function tsFmt(ts) {
  if (!ts) return "-";
  const d = new Date(Number(ts) * 1000);
  if (Number.isNaN(d.getTime())) return "-";
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function num(n) {
  const v = Number(n || 0);
  if (v >= 1000000) return (v / 1000000).toFixed(1) + "M";
  if (v >= 10000) return (v / 10000).toFixed(1) + "w";
  return String(v);
}

function bytes(n) {
  const v = Number(n || 0);
  if (v >= 1073741824) return (v / 1073741824).toFixed(2) + " GB";
  if (v >= 1048576) return (v / 1048576).toFixed(2) + " MB";
  if (v >= 1024) return (v / 1024).toFixed(1) + " KB";
  return v + " B";
}

function dur(sec) {
  const s = Math.max(0, Math.round(Number(sec) || 0));
  if (s < 60) return s + " 秒";
  const m = Math.floor(s / 60);
  if (m < 60) return m + " 分 " + (s % 60) + " 秒";
  return Math.floor(m / 60) + " 时 " + (m % 60) + " 分";
}

function listOf(v) {
  if (Array.isArray(v)) return v.filter(Boolean);
  if (typeof v === "string" && v.trim()) return [v.trim()];
  return [];
}

function tags(items, cls = "") {
  const arr = listOf(items);
  if (!arr.length) return '<span class="hint">—</span>';
  return arr.map((t) => `<span class="tag ${cls}">${esc(t)}</span>`).join("");
}

function statusBadge(status) {
  const map = {
    queued: ["排队中", "warn"],
    running: ["进行中", "run"],
    done: ["已完成", "on"],
    failed: ["失败", "err"],
    canceled: ["已取消", ""],
  };
  const [text, cls] = map[status] || [status || "-", ""];
  return `<span class="badge ${cls}">${text}</span>`;
}

/* ------------------------------------------------------------------ */
/*  Tab                                                                */
/* ------------------------------------------------------------------ */
$$(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    $$(".tab").forEach((t) => t.classList.remove("active"));
    $$(".panel").forEach((p) => p.classList.remove("active"));
    tab.classList.add("active");
    const panel = $("#" + tab.dataset.panel);
    if (panel) panel.classList.add("active");
    loadPanel(tab.dataset.panel);
  });
});

function loadPanel(panelId) {
  switch (panelId) {
    case "panelTrack": loadTrack(); break;
    case "panelGroups": loadGroups(); break;
    case "panelJobs": loadJobs(); break;
    case "panelConfig": loadConfig(); break;
    case "panelDb": loadDb(); break;
    case "panelLogs": loadLogs(); break;
  }
}

/* ------------------------------------------------------------------ */
/*  顶部统计                                                           */
/* ------------------------------------------------------------------ */
async function loadStats() {
  try {
    const payload = await apiGet("/db/stats");
    const ov = payload.overview || {};
    const db = payload.db || {};
    $("#stGroups").textContent = num(ov.groups);
    $("#stMessages").textContent = num(ov.messages);
    $("#stUsers").textContent = num(ov.users);
    $("#stPersonas").textContent = num(ov.personas);
    $("#stDb").textContent = bytes(db.file_size);
  } catch (_) { /* 忽略 */ }
}

/* ================================================================== */
/*  一、按 QQ 号蒸馏（主入口，含画像结果）                              */
/* ================================================================== */
const trackState = { qq: "", timer: 0, jobId: 0, currentVersion: 0 };

function trackQQValue() {
  return ($("#trackQQ").value || "").trim();
}

function loadTrack() {
  if (trackState.qq) lookupQQ(trackState.qq);
  if (trackState.jobId) pollTrack(trackState.jobId);
}

/* ---------- 只查询：他在哪些群 ---------- */
async function lookupQQ(qq) {
  qq = (qq || "").trim();
  if (!/^\d{4,12}$/.test(qq)) {
    toast("请输入正确的 QQ 号", "warn");
    return;
  }
  trackState.qq = qq;
  const body = $("#trackGroups");
  body.innerHTML = '<tr><td colspan="9" class="empty">查询中…</td></tr>';
  try {
    const res = await apiGet("/user/lookup", { user_id: qq });
    const groups = res.groups || [];
    state.selectedGroups = new Set(groups.map((g) => String(g.group_id)));
    $("#trkAll").checked = groups.length > 0;
    body.innerHTML = groups.length
      ? groups.map((g) => `
        <tr>
          <td><input type="checkbox" class="trkChk" data-gid="${esc(g.group_id)}" checked></td>
          <td class="mono">${esc(g.group_id)}</td>
          <td>${esc(g.group_name || "(未登记)")}</td>
          <td class="num">${num(g.msg_count)}</td>
          <td class="num">${num(g.char_count)}</td>
          <td class="num">${num(g.image_count)}</td>
          <td class="num">${num(g.at_count)}</td>
          <td class="num">${num(g.reply_count)}</td>
          <td class="small">${g.last_time ? tsFmt(g.last_time) : "-"}</td>
        </tr>`).join("")
      : '<tr><td colspan="9" class="empty">库里还没有该 QQ 号的消息，勾选「先跨群采集」再点开始蒸馏</td></tr>';
    bindTrackChecks();
    if (res.total_messages) {
      $("#trackResult").innerHTML =
        `<div class="hint">本地已有 <b>${num(res.total_messages)}</b> 条消息，分布在 <b>${groups.length}</b> 个群。</div>`;
    }
  } catch (e) {
    body.innerHTML = `<tr><td colspan="9" class="empty">查询失败：${esc(String(e.message || e))}</td></tr>`;
  }
}

function bindTrackChecks() {
  $$(".trkChk").forEach((cb) => {
    cb.addEventListener("change", () => {
      if (cb.checked) state.selectedGroups.add(cb.dataset.gid);
      else state.selectedGroups.delete(cb.dataset.gid);
      updateTrackSelInfo();
    });
  });
  updateTrackSelInfo();
}

function updateTrackSelInfo() {
  const n = state.selectedGroups.size;
  const all = $$(".trkChk").length;
  $("#trkSelInfo").textContent = n
    ? `已选择 ${n}/${all} 个群 —— 点「蒸馏选中群」把它们的群友一起蒸`
    : "未选择任何群";
  $("#trkAll").checked = n > 0 && n === all;
}

/* ---------- 开始蒸馏（带全量采集） ---------- */
async function startTrack({ collect = true, full = false } = {}) {
  const qq = trackQQValue();
  if (!/^\d{4,12}$/.test(qq)) {
    toast("请输入正确的 QQ 号", "warn");
    return;
  }
  const count = parseInt($("#trackCount").value, 10) || 0;
  const gids = Array.from(state.selectedGroups);
  $("#trackResult").innerHTML =
    `<div class="hint">已提交${collect ? "（先跨群采集再蒸馏）" : "（直接蒸馏本地数据）"}，正在启动…</div>`;
  try {
    const res = await apiPost("/track", {
      user_id: qq, collect, distill: true, full, count,
      group_ids: gids.length ? gids : undefined,
    });
    if (res && res.job_id) {
      trackState.jobId = res.job_id;
      trackState.qq = qq;
      toast("任务已入队 #" + res.job_id);
      pollTrack(res.job_id);
      // 采集期间就先把覆盖表刷出来
      setTimeout(() => lookupQQ(qq), 2500);
    } else {
      toast("提交失败", "error");
    }
  } catch (e) {
    toast("提交失败：" + (e.message || e), "error");
  }
}

/* ---------- 实时进度（2s 轮询 /jobs/detail） ---------- */
function pollTrack(jobId) {
  clearInterval(trackState.timer);
  $("#trackProgressCard").style.display = "";
  let ticks = 0;

  const render = (d) => {
    const pct = Math.max(0, Math.min(100, Number(d.progress) || 0));
    $("#tpBar").style.width = pct + "%";
    $("#tpPct").textContent = pct.toFixed(0) + "%";
    $("#tpTitle").textContent = `任务 #${d.id} · ${d.user_id === trackState.qq ? trackState.qq : (d.user_id || "")}`;
    $("#tpStage").textContent = d.stage || "…";

    const stMap = {
      queued: ["排队中", "warn"], running: ["进行中", "run"],
      done: ["已完成", "on"], failed: ["失败", "err"], canceled: ["已取消", ""],
    };
    const [stText, stCls] = stMap[d.status] || [d.status, ""];
    $("#tpState").className = "pill " + stCls;
    $("#tpState").textContent = stText;

    if (d.status === "done") {
      $("#tpEta").textContent = `耗时 ${dur(d.elapsed_seconds)}`;
    } else if (d.status === "failed") {
      $("#tpEta").textContent = "已失败";
    } else if (d.eta_seconds != null) {
      $("#tpEta").textContent = `预计剩余 ${dur(d.eta_seconds)}`;
    } else {
      $("#tpEta").textContent = `已用 ${dur(d.elapsed_seconds)}`;
    }

    const steps = d.steps || [];
    $("#tpSteps").innerHTML = steps.length
      ? steps.map((s, i) => {
        const sp = s.total ? Math.min(100, Math.round((Number(s.done) || 0) * 100 / s.total)) : null;
        return `<tr>
          <td class="mono">${i + 1}</td>
          <td>${esc(s.name)}</td>
          <td>${statusBadge(s.status)}</td>
          <td class="mono">${s.total ? `${s.done || 0}/${s.total}` : "—"}
            ${sp != null ? `<div class="prog mt4"><div class="bar" style="width:${sp}%"></div></div>` : ""}</td>
          <td class="hint">${esc(s.detail || "")}</td>
        </tr>`;
      }).join("")
      : '<tr><td colspan="5" class="empty">等待启动…</td></tr>';

    if (d.error) {
      $("#trackResult").innerHTML = `<div class="hint" style="color:var(--err)">失败原因：${esc(d.error)}</div>`;
    }
  };

  const tick = async () => {
    ticks += 1;
    if (ticks > 900) { clearInterval(trackState.timer); return; }
    try {
      const d = await apiGet("/jobs/detail", { job_id: jobId });
      render(d);
      if (d.status === "done") {
        clearInterval(trackState.timer);
        trackState.jobId = 0;
        $("#trackResult").innerHTML =
          `<div class="hint">✅ 人设已生成：样本 <b>${num(d.sample_count)}</b> 条，
           共 <b>${d.batch_total || 0}</b> 批，耗时 ${dur(d.elapsed_seconds)}。结果在下方向像卡片。</div>`;
        await lookupQQ(trackState.qq);
        await showTrackPersona(trackState.qq);
        loadStats();
      } else if (d.status === "failed") {
        clearInterval(trackState.timer);
        trackState.jobId = 0;
      } else if (d.status === "canceled") {
        clearInterval(trackState.timer);
        trackState.jobId = 0;
        $("#trackResult").innerHTML = `<div class="hint">任务已取消。</div>`;
      }
    } catch (_) { /* 轮询失败忽略 */ }
  };
  tick();
  trackState.timer = setInterval(tick, 2000);
}

/* ---------- 画像直接显示在本页 ---------- */
async function showTrackPersona(qq, version = 0) {
  qq = (qq || trackState.qq || "").trim();
  if (!/^\d{4,12}$/.test(qq)) return;
  const card = $("#trackPersonaCard");
  const box = $("#trackPersonaBody");
  card.style.display = "";
  box.innerHTML = '<div class="empty">加载中…</div>';
  try {
    const row = await apiGet("/persona", {
      group_id: "*global*", user_id: qq, version: version || 0,
    });
    state.persona = row;
    trackState.currentVersion = Number(row.version) || 0;
    $("#tpPersonaTitle").textContent =
      `画像结果 · ${row.nickname || qq} v${row.version}（置信度 ${(Number(row.confidence) * 100).toFixed(0)}%）`;
    renderPersonaInto(box, row);

    // 版本下拉
    try {
      const versions = await apiGet("/persona/versions", { group_id: "*global*", user_id: qq });
      const sel = $("#tpVersionSel");
      sel.innerHTML = versions.length
        ? versions.map((v) => `<option value="${v.version}" ${Number(v.version) === trackState.currentVersion ? "selected" : ""}>
            v${v.version} · ${num(v.sample_count)} 条 · ${tsFmt(v.created_at)}</option>`).join("")
        : `<option value="${row.version}">v${row.version}</option>`;
      sel.onchange = () => showTrackPersona(qq, parseInt(sel.value, 10) || 0);
    } catch (_) { /* 忽略 */ }

    $("#btnTpCopy").onclick = async () => {
      try {
        await navigator.clipboard.writeText(row.system_prompt || "");
        toast("已复制 system prompt");
      } catch (_) { toast("复制失败，请手动选择文本", true); }
    };
    $("#btnTpPush").onclick = () => {
      $("#trackResult").innerHTML =
        `<div class="hint">投放指令（在机器人所在群发送）：</div>
         <pre class="prompt">/蒸馏 投放 ${esc(qq)}</pre>`;
    };
    card.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (err) {
    card.style.display = "none";
    if (String(err.message || err).includes("不存在")) {
      toast("还没有该号的画像", "warn");
    } else {
      box.innerHTML = `<div class="empty">加载失败：${esc(err.message)}</div>`;
    }
  }
}

/* ---------- 蒸馏勾选的群 ---------- */
async function distillSelectedGroups() {
  const gids = Array.from(state.selectedGroups);
  if (!gids.length) {
    toast("请先勾选至少一个群", "warn");
    return;
  }
  const topN = parseInt($("#trkTopN").value, 10) || 0;
  try {
    const res = await apiPost("/groups/distill", { group_ids: gids, top_n: topN });
    toast(`已提交 ${res.groups} 个群的蒸馏任务 #${res.job_id}`);
    trackState.jobId = res.job_id;
    pollTrack(res.job_id);
  } catch (e) {
    toast("提交失败：" + (e.message || e), "error");
  }
}

/* ---------- 事件绑定 ---------- */
$("#btnTrack").onclick = () => startTrack({
  collect: $("#trackCollect").checked,
  full: $("#trackFull").checked,
});
$("#btnTrackNoCollect").onclick = () => startTrack({ collect: false, full: false });
$("#btnLookup").onclick = () => lookupQQ(trackQQValue());
$("#trackQQ").addEventListener("keydown", (e) => {
  if (e.key === "Enter") startTrack({
    collect: $("#trackCollect").checked,
    full: $("#trackFull").checked,
  });
});
$("#trkAll").addEventListener("change", (e) => {
  $$(".trkChk").forEach((cb) => {
    cb.checked = e.target.checked;
    if (cb.checked) state.selectedGroups.add(cb.dataset.gid);
    else state.selectedGroups.delete(cb.dataset.gid);
  });
  updateTrackSelInfo();
});
$("#btnTrkDistill").onclick = distillSelectedGroups;
$("#btnTrackCancel").onclick = async () => {
  if (!trackState.jobId) { toast("当前没有运行中的任务", "warn"); return; }
  try {
    await apiPost("/jobs/cancel", { job_id: trackState.jobId });
    toast("已请求取消");
  } catch (e) { toast("取消失败：" + e.message, true); }
};

/* ================================================================== */
/*  二、群管理（一键全选 + 批量开关）                                   */
/* ================================================================== */
async function loadGroups() {
  const body = $("#groupRows");
  body.innerHTML = '<tr><td colspan="9" class="empty">加载中…</td></tr>';
  try {
    const groups = await apiGet("/groups");
    state.groups = groups || [];
    renderGroupRows();
  } catch (err) {
    body.innerHTML = `<tr><td colspan="9" class="empty">加载失败：${esc(err.message)}</td></tr>`;
  }
}

function visibleGroups() {
  const kw = ($("#grpKw").value || "").trim().toLowerCase();
  return state.groups.filter((g) =>
    !kw || String(g.group_id).includes(kw) ||
    String(g.group_name || "").toLowerCase().includes(kw));
}

function renderGroupRows() {
  const rows = visibleGroups();
  const body = $("#groupRows");
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="9" class="empty">没有群。在上方搜索框输入关键词登记群。</td></tr>';
    $("#groupSelInfo").textContent = "未选择任何群";
    return;
  }
  const sel = state.selectedGroups;
  body.innerHTML = rows.map((g) => `
    <tr>
      <td><input type="checkbox" class="grpChk" data-gid="${esc(g.group_id)}" ${sel.has(String(g.group_id)) ? "checked" : ""}></td>
      <td class="mono">${esc(g.group_id)}</td>
      <td>${esc(g.group_name || "(无名)")}</td>
      <td class="mono">${num(g.member_count)}</td>
      <td class="mono">${num(g.msg_count)}</td>
      <td class="nowrap">${tsFmt(g.last_msg_time)}</td>
      <td><label class="chk"><input type="checkbox" data-flag="auto_collect" data-gid="${esc(g.group_id)}" ${Number(g.auto_collect) ? "checked" : ""}> 开</label></td>
      <td><label class="chk"><input type="checkbox" data-flag="auto_distill" data-gid="${esc(g.group_id)}" ${Number(g.auto_distill) ? "checked" : ""}> 开</label></td>
      <td class="nowrap">
        <button class="ghost sm" data-collect="${esc(g.group_id)}">增量采集</button>
        <button class="ghost sm" data-collect-full="${esc(g.group_id)}">全量</button>
      </td>
    </tr>`).join("");

  body.querySelectorAll(".grpChk").forEach((cb) => {
    cb.addEventListener("change", () => {
      if (cb.checked) state.selectedGroups.add(cb.dataset.gid);
      else state.selectedGroups.delete(cb.dataset.gid);
      updateGroupSelInfo();
    });
  });

  body.querySelectorAll("[data-flag]").forEach((cb) => {
    cb.addEventListener("change", async () => {
      try {
        await apiPost("/groups/update", {
          group_id: cb.dataset.gid, field: cb.dataset.flag, value: cb.checked ? 1 : 0,
        });
        const g = state.groups.find((x) => x.group_id === cb.dataset.gid);
        if (g) g[cb.dataset.flag] = cb.checked ? 1 : 0;
      } catch (err) {
        toast("更新失败：" + err.message, true);
        cb.checked = !cb.checked;
      }
    });
  });

  body.querySelectorAll("[data-collect]").forEach((btn) => {
    btn.addEventListener("click", () => triggerCollect(btn.dataset.collect, false, btn));
  });
  body.querySelectorAll("[data-collect-full]").forEach((btn) => {
    btn.addEventListener("click", () => triggerCollect(btn.dataset.collectFull, true, btn));
  });
  updateGroupSelInfo();
}

function updateGroupSelInfo() {
  const vis = visibleGroups().map((g) => String(g.group_id));
  const n = state.selectedGroups.size;
  const hit = vis.filter((g) => state.selectedGroups.has(g)).length;
  $("#groupSelInfo").textContent = n
    ? `已选择 ${n} 个群${hit !== n ? `（当前列表内 ${hit} 个）` : ""}`
    : "未选择任何群";
  $("#groupAll").checked = vis.length > 0 && hit === vis.length;
}

async function bulkFlags(field, value) {
  const gids = Array.from(state.selectedGroups);
  const scope = gids.length ? gids : visibleGroups().map((g) => String(g.group_id));
  if (!scope.length) { toast("没有可操作的群", "warn"); return; }
  try {
    const res = await apiPost("/groups/bulk", { field, value, group_ids: scope });
    toast(`已${value ? "开启" : "关闭"} ${res.updated} 个群的 ${field === "auto_collect" ? "自动采集" : "自动蒸馏"}`);
    await loadGroups();
  } catch (e) {
    toast("操作失败：" + (e.message || e), "error");
  }
}

async function triggerCollect(gid, full, btn) {
  const label = btn.textContent;
  btn.disabled = true;
  btn.textContent = "采集中…";
  try {
    const res = await apiPost("/collect", { group_id: gid, full });
    toast(`群 ${gid} 采集完成：拉取 ${res.fetched}，新增 ${res.inserted}`);
    await loadGroups();
    loadStats();
  } catch (err) {
    toast("采集失败：" + err.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = label;
  }
}

$("#grpKw").addEventListener("input", renderGroupRows);
$("#btnGroupReload").addEventListener("click", loadGroups);
$("#groupAll").addEventListener("change", (e) => {
  visibleGroups().forEach((g) => {
    if (e.target.checked) state.selectedGroups.add(String(g.group_id));
    else state.selectedGroups.delete(String(g.group_id));
  });
  renderGroupRows();
});
$("#btnBulkCollectOn").addEventListener("click", () => bulkFlags("auto_collect", 1));
$("#btnBulkCollectOff").addEventListener("click", () => bulkFlags("auto_collect", 0));
$("#btnBulkDistillOn").addEventListener("click", () => bulkFlags("auto_distill", 1));
$("#btnBulkDistillOff").addEventListener("click", () => bulkFlags("auto_distill", 0));

$("#btnDiscover").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  const kw = ($("#grpKw2").value || "").trim();
  btn.disabled = true;
  btn.textContent = "搜索中…";
  try {
    const groups = await apiPost("/groups/discover", { keyword: kw });
    toast(`搜到并登记 ${groups.length} 个群`);
    await loadGroups();
    loadStats();
  } catch (err) {
    toast("搜索失败：" + err.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = "搜索并登记群";
  }
});

/* ================================================================== */
/*  三、蒸馏任务                                                        */
/* ================================================================== */
const jobState = { detailId: 0, timer: 0 };

async function loadJobs() {
  const status = $("#jobStatus").value || "";
  const body = $("#jobRows");
  try {
    const rows = await apiGet("/jobs", status ? { status, limit: 100 } : { limit: 100 });
    body.innerHTML = rows.length
      ? rows.map((j) => `
        <tr data-job="${j.id}" style="cursor:pointer">
          <td class="mono">${j.id}</td>
          <td class="mono">${esc(j.group_id)}</td>
          <td class="mono">${esc(j.user_id)}</td>
          <td>${statusBadge(j.status)}</td>
          <td class="hint">${esc(j.stage || "")}</td>
          <td style="width:130px"><div class="prog"><div class="bar" style="width:${Number(j.progress) || 0}%"></div></div></td>
          <td class="mono">${j.batch_done || 0}/${j.batch_total || 0}</td>
          <td class="mono">${num(j.sample_count)}</td>
          <td class="nowrap">${tsFmt(j.updated_at)}</td>
        </tr>`).join("")
      : '<tr><td colspan="9" class="empty">暂无任务</td></tr>';
    body.querySelectorAll("[data-job]").forEach((tr) => {
      tr.addEventListener("click", () => showJobDetail(parseInt(tr.dataset.job, 10)));
    });
  } catch (err) {
    body.innerHTML = `<tr><td colspan="9" class="empty">加载失败：${esc(err.message)}</td></tr>`;
  }
}

async function showJobDetail(jobId) {
  jobState.detailId = jobId;
  const box = $("#jobDetail");
  try {
    const d = await apiGet("/jobs/detail", { job_id: jobId });
    const steps = d.steps || [];
    box.innerHTML = `
      <div class="row between mb">
        <div><b>#${d.id}</b> ${statusBadge(d.status)}
          <span class="hint">${esc(d.stage || "")}</span></div>
        <div class="row">
          <span class="pill">已用 ${dur(d.elapsed_seconds)}</span>
          <span class="pill">${d.eta_seconds != null ? "预计剩余 " + dur(d.eta_seconds) : "无 ETA"}</span>
        </div>
      </div>
      <div class="prog big"><div class="bar" style="width:${Number(d.progress) || 0}%"></div></div>
      <div class="hint mt8">群 ${esc(d.group_id)} · 对象 ${esc(d.user_id)} · 素材 ${num(d.sample_count)} 条
        ${d.error ? " · <span style='color:var(--err)'>" + esc(d.error) + "</span>" : ""}</div>
      <table class="mt12">
        <thead><tr><th style="width:36px">#</th><th>阶段</th><th>状态</th><th>进度</th><th>明细</th></tr></thead>
        <tbody>${steps.length ? steps.map((s, i) => `<tr>
            <td class="mono">${i + 1}</td><td>${esc(s.name)}</td><td>${statusBadge(s.status)}</td>
            <td class="mono">${s.total ? (s.done || 0) + "/" + s.total : "—"}</td>
            <td class="hint">${esc(s.detail || "")}</td></tr>`).join("")
          : '<tr><td colspan="5" class="empty">该任务没有阶段记录</td></tr>'}</tbody>
      </table>
      ${(d.groups_hit || []).length ? `<div class="mt"><div class="hint mb">群覆盖：</div><div class="taglist">
        ${d.groups_hit.map((g) => `<span class="tag">${esc(g.group_name || g.group_id)} ${num(g.messages)} 条</span>`).join("")}
      </div></div>` : ""}`;
  } catch (err) {
    box.innerHTML = `<div class="empty">加载失败：${esc(err.message)}</div>`;
  }
}

$("#btnJobReload").addEventListener("click", loadJobs);
$("#jobStatus").addEventListener("change", loadJobs);

/* ================================================================== */
/*  四、参数配置                                                        */
/* ================================================================== */
const GROUP_LABELS = [
  [/^(llm_batch_size|llm_batch_overlap|llm_max_batches|llm_sample_char_limit|llm_max_merge_samples)$/, "★ 喂给 LLM 的数据量"],
  [/^(enable_auto_collect|collect_interval_minutes|discover_interval_minutes|discover_keywords|default_fetch_count|incremental_fetch_count|fetch_page_size|fetch_page_interval_ms|max_groups_per_round)$/, "采集与收录条数"],
  [/^(auto_distill_after_collect|auto_distill_top_n|auto_distill_min_messages|recent_sample_window_days)$/, "蒸馏调度"],
  [/^(llm_provider_id|llm_temperature|llm_timeout_seconds|llm_retry_times|llm_concurrency)$/, "LLM 调用"],
  [/^(distill_language|distill_extra_instruction)$/, "蒸馏输出"],
  [/^(collect_stickers|sticker_ocr_enabled|noise_filter_enabled|min_message_length|ignore_bot_self|ignore_user_ids)$/, "清洗与过滤"],
  [/^(webui_enabled|webui_access_token)$/, "可视化后台"],
];

function groupOf(key) {
  for (const [re, label] of GROUP_LABELS) if (re.test(key)) return label;
  return "其它";
}

async function loadConfig() {
  const box = $("#cfgForm");
  box.innerHTML = '<div class="empty">加载中…</div>';
  try {
    const payload = await apiGet("/config");
    state.config = payload;
    const { schema, values } = payload;
    const buckets = new Map();
    for (const key of Object.keys(schema)) {
      const g = groupOf(key);
      if (!buckets.has(g)) buckets.set(g, []);
      buckets.get(g).push(key);
    }
    const order = GROUP_LABELS.map(([, l]) => l).concat(["其它"]);
    let html = "";
    for (const gname of order) {
      const list = buckets.get(gname);
      if (!list) continue;
      html += `<div class="grp-title">${esc(gname)}</div>`;
      for (const key of list) html += fieldHtml(key, schema[key], values[key]);
    }
    box.innerHTML = html;
    bindConfigInputs(schema);
  } catch (err) {
    box.innerHTML = `<div class="empty">加载失败：${esc(err.message)}</div>`;
  }
}

function fieldHtml(key, meta, value) {
  const typ = meta.type || "string";
  const desc = meta.description || "";

  if (typ === "bool") {
    return `<div class="field">
      <div class="lbl">${esc(key)}</div>
      <label class="chk"><input type="checkbox" data-cfg="${esc(key)}" data-type="bool" ${value ? "checked" : ""}> 启用</label>
      <div class="desc">${esc(desc)}</div>
    </div>`;
  }
  if (typ === "int" || typ === "float") {
    const slider = meta.slider || {};
    const step = typ === "float" ? 0.05 : 1;
    const ctl = slider.min !== undefined
      ? `<input type="range" data-cfg="${esc(key)}" data-type="${typ}" data-from="range"
              min="${slider.min}" max="${slider.max}" step="${step}" value="${value}">
         <input type="number" class="num" data-cfg="${esc(key)}" data-type="${typ}" data-from="num"
              min="${slider.min ?? ""}" max="${slider.max ?? ""}" step="${step}" value="${value}">`
      : `<input type="number" class="num" style="width:120px;text-align:left" data-cfg="${esc(key)}" data-type="${typ}" value="${value}">`;
    return `<div class="field"><div class="lbl">${esc(key)}</div><div class="ctl">${ctl}</div>
      <div class="desc">${esc(desc)}</div></div>`;
  }
  if (typ === "text") {
    return `<div class="field" style="grid-column:1/-1">
      <div class="lbl">${esc(key)}</div>
      <textarea data-cfg="${esc(key)}" data-type="text">${esc(value || "")}</textarea>
      <div class="desc">${esc(desc)}</div></div>`;
  }
  if (typ === "list") {
    const v = Array.isArray(value) ? value.join(", ") : (value || "");
    return `<div class="field"><div class="lbl">${esc(key)}</div>
      <input type="text" data-cfg="${esc(key)}" data-type="list" value="${esc(v)}" placeholder="逗号分隔">
      <div class="desc">${esc(desc)}</div></div>`;
  }
  if (Array.isArray(meta.options) && meta.options.length) {
    const opts = meta.options.map((o) =>
      `<option value="${esc(o)}" ${String(o) === String(value) ? "selected" : ""}>${esc(o)}</option>`).join("");
    return `<div class="field"><div class="lbl">${esc(key)}</div>
      <select data-cfg="${esc(key)}" data-type="string">${opts}</select>
      <div class="desc">${esc(desc)}</div></div>`;
  }
  return `<div class="field"><div class="lbl">${esc(key)}</div>
    <input type="text" data-cfg="${esc(key)}" data-type="string" value="${esc(value ?? "")}">
    <div class="desc">${esc(desc)}</div></div>`;
}

function bindConfigInputs() {
  $$("#cfgForm [data-from=range]").forEach((el) => {
    el.addEventListener("input", () => {
      const twin = $$(`#cfgForm [data-from=num][data-cfg="${el.dataset.cfg}"]`)[0];
      if (twin) twin.value = el.value;
    });
  });
  $$("#cfgForm [data-from=num]").forEach((el) => {
    el.addEventListener("input", () => {
      const twin = $$(`#cfgForm [data-from=range][data-cfg="${el.dataset.cfg}"]`)[0];
      if (twin) twin.value = el.value;
    });
  });
}

async function saveConfig() {
  const values = {};
  $$("#cfgForm [data-cfg]").forEach((el) => {
    if (el.dataset.from === "range") return;
    const key = el.dataset.cfg;
    const type = el.dataset.type;
    if (type === "bool") values[key] = el.checked;
    else if (type === "int") values[key] = parseInt(el.value || "0", 10);
    else if (type === "float") values[key] = parseFloat(el.value || "0");
    else values[key] = el.value;
  });
  const btn = $("#btnCfgSave");
  btn.disabled = true;
  btn.textContent = "保存中…";
  try {
    const applied = await apiPost("/config/save", { values });
    toast(`已保存 ${Object.keys(applied || {}).length} 项配置`);
  } catch (err) {
    toast("保存失败：" + err.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = "保存全部";
  }
}

$("#btnCfgReload").addEventListener("click", loadConfig);
$("#btnCfgSave").addEventListener("click", saveConfig);

/* ================================================================== */
/*  五、数据库                                                          */
/* ================================================================== */
async function loadDb() {
  $("#dbTables").innerHTML = '<tr><td colspan="2" class="empty">加载中…</td></tr>';
  try {
    const payload = await apiGet("/db/stats");
    const db = payload.db || {};
    const ov = payload.overview || {};
    $("#dbSize").textContent = bytes(db.file_size);
    $("#dbFree").textContent = `${num(db.free_pages)} / ${num(db.page_count)} 页`;
    $("#dbPath").textContent = db.path || "-";
    $("#stGroups").textContent = num(ov.groups);
    $("#stMessages").textContent = num(ov.messages);
    $("#stUsers").textContent = num(ov.users);
    $("#stPersonas").textContent = num(ov.personas);
    $("#stDb").textContent = bytes(db.file_size);
    const tables = db.tables || [];
    $("#dbTables").innerHTML = tables.length
      ? tables.map((t) => `<tr>
          <td class="mono">${esc(t.table)}</td>
          <td class="mono">${num(t.rows)}</td></tr>`).join("")
      : '<tr><td colspan="2" class="empty">无表</td></tr>';
  } catch (err) {
    $("#dbTables").innerHTML = `<tr><td colspan="2" class="empty">加载失败：${esc(err.message)}</td></tr>`;
  }
}

$("#btnDbReload").addEventListener("click", loadDb);
$("#btnDbVacuum").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  btn.disabled = true; btn.textContent = "压缩中…";
  try {
    const info = await apiPost("/db/vacuum", {});
    toast(`VACUUM 完成：${bytes(info.before)} → ${bytes(info.after)}，释放 ${bytes(info.freed)}`);
    await loadDb();
  } catch (err) {
    toast("压缩失败：" + err.message, true);
  } finally {
    btn.disabled = false; btn.textContent = "VACUUM 压缩回收";
  }
});
$("#btnDbOptimize").addEventListener("click", async () => {
  try {
    const res = await apiPost("/db/prune", { scope: "__optimize__" });
    toast("已优化");
  } catch (_) { toast("已优化"); }
  await loadDb();
});

$("#btnPrune").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  const scope = $("#pruneScope").value;
  const keepDays = parseInt($("#pruneDays").value, 10) || 0;
  const gid = ($("#pruneGroup").value || "").trim();
  const label = $("#pruneScope").selectedOptions[0].textContent;
  if (!confirm(`确定清理「${label}」吗？此操作不可撤销。`)) return;
  btn.disabled = true; btn.textContent = "清理中…";
  try {
    const res = await apiPost("/db/prune", { scope, keep_days: keepDays, group_id: gid });
    const parts = Object.entries(res.removed || {}).map(([k, v]) => `${k} ${v} 行`);
    $("#pruneResult").innerHTML =
      `<div class="hint">✅ 已清理 <b>${label}</b>，共删除 <b>${res.total}</b> 行${parts.length ? "：" + esc(parts.join("，")) : ""}。
       建议再点一次「VACUUM 压缩回收」释放磁盘空间。</div>`;
    await loadDb();
  } catch (err) {
    $("#pruneResult").innerHTML = `<div class="hint" style="color:var(--err)">清理失败：${esc(err.message)}</div>`;
  } finally {
    btn.disabled = false; btn.textContent = "执行清理";
  }
});

/* ================================================================== */
/*  六、日志                                                            */
/* ================================================================== */
async function loadLogs() {
  try {
    const rows = await apiGet("/logs", { limit: 200 });
    const box = $("#logBox");
    if (!rows.length) { box.innerHTML = '<div class="empty">暂无日志</div>'; return; }
    box.innerHTML = rows.map((l) => `
      <div class="logline ${esc(l.level || "info")}">
        <span class="t">${tsFmt(l.ts)}</span>
        <span class="s">[${esc(l.scope || "-")}]</span>
        ${esc(l.message || "")}
      </div>`).join("");
  } catch (err) {
    $("#logBox").innerHTML = `<div class="empty">加载失败：${esc(err.message)}</div>`;
  }
}

$("#btnLogReload").addEventListener("click", loadLogs);

/* ================================================================== */
/*  全局刷新 / 启动                                                     */
/* ================================================================== */
$("#btnRefresh").addEventListener("click", () => {
  loadStats();
  const active = $$(".tab").find((t) => t.classList.contains("active"));
  if (active) loadPanel(active.dataset.panel);
});

setInterval(() => {
  if ($("#panelJobs").classList.contains("active")) loadJobs();
}, 5000);
setInterval(loadStats, 20000);

(async function boot() {
  await loadStats();
  await loadGroups();
})();
