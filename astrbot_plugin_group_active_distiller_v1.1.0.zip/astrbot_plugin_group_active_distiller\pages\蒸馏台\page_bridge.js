/* AstrBot 插件拓展页桥接层
 * ---------------------------------------------------------------
 * AstrBot 后台会把插件 pages/<名称>/index.html 放进一个 iframe，
 * 并通过 postMessage / window.AstrBotPluginPage 暴露 API 调用通道。
 * 这里做三件事：
 *   1. 自动发现桥接对象（自身 window 或 parent window）；
 *   2. 统一把 HTTP 状态和 {success, data} 信封拍平成 data / throw；
 *   3. 没桥接时回退到直连 fetch(`/<plugin>/page<path>`)，方便本地调试。
 */

const PLUGIN_NAME = "astrbot_plugin_group_active_distiller";

function findBridge() {
  const candidates = [];
  try { if (window.AstrBotPluginPage) candidates.push(window.AstrBotPluginPage); } catch (_) {}
  try { if (window.parent && window.parent !== window && window.parent.AstrBotPluginPage) candidates.push(window.parent.AstrBotPluginPage); } catch (_) {}
  try { if (window.top && window.top !== window && window.top.AstrBotPluginPage) candidates.push(window.top.AstrBotPluginPage); } catch (_) {}
  for (const c of candidates) {
    if (c && typeof c.apiGet === "function") return c;
  }
  return null;
}

function unwrap(payload) {
  if (payload == null) return null;
  if (typeof payload === "object" && "success" in payload) {
    if (payload.success === false) {
      throw new Error(payload.error || payload.message || "接口返回失败");
    }
    return payload.data !== undefined ? payload.data : payload;
  }
  return payload;
}

async function rawFetch(method, path, params, body) {
  let url = `/${PLUGIN_NAME}/page${path}`;
  if (params && Object.keys(params).length) {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== "") qs.append(k, v);
    }
    const s = qs.toString();
    if (s) url += `?${s}`;
  }
  const init = { method, headers: {} };
  if (method === "POST") {
    init.headers["Content-Type"] = "application/json";
    init.body = JSON.stringify(body || {});
  }
  const resp = await fetch(url, init);
  const text = await resp.text();
  let payload;
  try { payload = JSON.parse(text); } catch (_) { payload = { success: resp.ok, data: text }; }
  return unwrap(payload);
}

export async function apiGet(path, params) {
  const bridge = findBridge();
  if (bridge) {
    try {
      const res = await bridge.apiGet(`page${path}`, params || {});
      return unwrap(res);
    } catch (err) {
      // 桥接层内部异常时才回退，业务失败直接抛
      if (err && err.message && !/fetch|network|undefined/i.test(err.message)) throw err;
      return rawFetch("GET", path, params);
    }
  }
  return rawFetch("GET", path, params);
}

export async function apiPost(path, body) {
  const bridge = findBridge();
  if (bridge) {
    try {
      const res = await bridge.apiPost(`page${path}`, body || {});
      return unwrap(res);
    } catch (err) {
      if (err && err.message && !/fetch|network|undefined/i.test(err.message)) throw err;
      return rawFetch("POST", path, null, body);
    }
  }
  return rawFetch("POST", path, null, body);
}

export function toast(message, isError = false) {
  const el = document.createElement("div");
  el.className = "toast" + (isError ? " err" : "");
  el.textContent = message;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), isError ? 5000 : 2600);
}

export { unwrap, PLUGIN_NAME };
