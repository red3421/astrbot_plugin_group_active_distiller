# -*- coding: utf-8 -*-
"""本地端到端冒烟测试：不连真 QQ、不连真 LLM。

假的 OneBot client + 假的 AstrBot Context + 假的 provider，
跑通 采集 → 入库 → 抽样 → 分批 → 合并 → 画像落库 全链路。

用法：
    python selftest.py
"""

from __future__ import annotations

import asyncio
import json
import os
import random
import shutil
import sys
import time
from pathlib import Path

# 让 `from core.xxx import` 与 `from .core.xxx import` 都能跑：把插件目录塞进 sys.path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))


# ---------------------------------------------------------------------- #
#  伪造 AstrBot 运行环境
# ---------------------------------------------------------------------- #
class FakeLogger:
    def info(self, *a, **k): print("[log]", a[0] % a[1:] if len(a) > 1 else a[0])
    def debug(self, *a, **k): pass
    def warning(self, *a, **k): print("[warn]", a[0] % a[1:] if len(a) > 1 else a[0])
    def error(self, *a, **k): print("[err]", a[0] % a[1:] if len(a) > 1 else a[0])


NAMES = ["小明", "阿伟", "老王", "K酱", "夜猫子"]
STYLES = {
    "10001": {
        "msgs": ["草", "这也太离谱了吧", "我真的会谢", "哈哈哈民那", "？你再说一遍",
                 "绝了，纯纯的绝", "笑死 根本笑不死", "有点东西", "行吧行吧", "6"],
        "stickers": ["熊猫头", "doge", "滑稽"],
    },
    "10002": {
        "msgs": ["在的", "稍等我看看", "这个方案我这边还要跟一下", "嗯…有道理",
                 "我买了个新键盘", "手动狗头", "确实", "晚点聊", "我先撤了"],
        "stickers": ["猫咪", "哭"],
    },
    "10003": {
        "msgs": ["啊啊啊啊", "破防了", "救命", "怎么又是我", "不想上班",
                 "摆烂了属于是", "吃了吗", "在干嘛呀", "陪我聊天嘛"],
        "stickers": ["二次元", "卖萌", "哭"],
    },
}


def make_fake_history(group_id: str, count: int) -> list[dict]:
    """造一段连续群聊历史（含 at / reply / 表情包段）。"""
    now = int(time.time())
    out = []
    for i in range(count):
        uid = random.choice(["10001", "10002", "10003", "99999"])
        style = STYLES.get(uid, {"msgs": ["嗯", "哦", "好"], "stickers": ["图片"]})
        text = random.choice(style["msgs"])
        segs: list[dict] = []
        roll = random.random()
        if roll < 0.12:
            hint = random.choice(style["stickers"])
            segs.append({"type": "image", "data": {"file": f"{hint}.image", "sub_type": 1}})
            segs.append({"type": "text", "data": {"text": text}})
        elif roll < 0.20:
            segs.append({"type": "at", "data": {"qq": "10002", "name": "阿伟"}})
            segs.append({"type": "text", "data": {"text": " " + text}})
        elif roll < 0.26:
            segs.append({"type": "reply", "data": {"id": str(1000 + i - 1)}})
            segs.append({"type": "text", "data": {"text": text}})
        elif roll < 0.30:
            segs.append({"type": "face", "data": {"id": str(random.randint(1, 200))}})
            segs.append({"type": "text", "data": {"text": text}})
        else:
            segs.append({"type": "text", "data": {"text": text}})

        out.append({
            "time": now - (count - i) * 60,
            "message_id": str(900000 + i),
            "message_seq": str(900000 + i),
            "real_id": 900000 + i,
            "seq": 900000 + i,
            "sender": {
                "user_id": uid,
                "nickname": NAMES[hash(uid) % len(NAMES)],
                "card": "" if uid == "99999" else NAMES[hash(uid) % len(NAMES)],
            },
            "message": segs,
        })
    return out


class FakeOneBotClient:
    """模拟 OneBot v11 的 call_action。"""

    def __init__(self, groups: dict[str, int]):
        self.groups = groups
        self.calls: list[str] = []

    async def call_action(self, action: str, **params):
        self.calls.append(action)
        if action == "get_group_list":
            return [
                {"group_id": int(gid), "group_name": f"测试群{gid}", "member_count": 42}
                for gid in self.groups
            ]
        if action == "get_group_info":
            gid = params.get("group_id")
            return {"group_id": gid, "group_name": f"测试群{gid}", "member_count": 42}
        if action == "get_group_msg_history":
            gid = str(params.get("group_id"))
            count = int(params.get("count") or 100)
            anchor = params.get("message_seq")
            history = make_fake_history(gid, count * 2)
            history.sort(key=lambda m: m["time"])  # 正序
            if anchor:
                idx = next(
                    (i for i, m in enumerate(history) if str(m["message_seq"]) == str(anchor)), None
                )
                if idx is None:
                    return {"messages": []}
                page = history[max(0, idx - count): idx]
            else:
                page = history[-count:]
            page.sort(key=lambda m: m["time"], reverse=True)
            return {"messages": page}
        if action == "send_group_msg":
            return {"message_id": 1}
        return {}


class FakePlatform:
    def __init__(self, client):
        self._client = client
        class _Meta:
            id = "fake-qq"
        self.metadata = _Meta()

    def get_client(self):
        return self._client


class FakePlatformManager:
    def __init__(self, platform):
        self._p = platform

    def get_insts(self):
        return [self._p]


PERSONA_JSON = {
    "summary": "群里最活跃的抬杠选手，嘴硬心软，情绪表达夸张。",
    "personality": {
        "traits": ["嘴硬心软", "情绪外放", "抬杠专业户"],
        "social_role": "话题发起者 / 气氛组",
        "energy": "高",
        "humor_style": "阴阳怪气 + 自嘲",
    },
    "speaking_style": {
        "avg_length": "极短",
        "sentence_pattern": "短句连发，常用逗号或空格断句",
        "punctuation": "基本不加句号，爱用感叹号和省略号",
        "typing_quirks": ["爱打错别字", "常连发多条"],
        "capitalization": "无特殊",
        "emoji_usage": "少用 emoji，多用小黄脸和狗头",
    },
    "catchphrases": [
        {"text": "笑死 根本笑不死", "usage": "别人说蠢话时", "frequency": "高"},
        {"text": "纯纯的", "usage": "评价某人某事时", "frequency": "中"},
    ],
    "vocabulary": {
        "favorite_words": ["离谱", "绝了", "有点东西"],
        "slang": ["破防", "摆烂", "属于是"],
        "particles": ["吧", "啊", "捏"],
        "taboo_words": ["尊敬的", "您好"],
    },
    "sticker_habit": {
        "frequency": "高频",
        "preferred_types": ["熊猫头", "滑稽", "doge"],
        "usage_pattern": "词穷时和怼人收尾时甩图",
        "text_faces": ["(手动狗头)", "[捂脸]"],
    },
    "interaction_style": {
        "reply_speed": "秒回",
        "at_habit": "爱 @ 熟人抬杠",
        "topic_driven": ["游戏", "吃瓜", "吐槽工作"],
        "conflict_style": "直接硬刚然后光速和好",
    },
    "scenario_examples": [
        {"scene": "被人调侃", "typical_reply": "笑死 你行你上"},
        {"scene": "被 @ 到", "typical_reply": "？喊我干嘛"},
    ],
    "avoid": ["不要用敬语", "不要长篇大论", "不要自称 AI"],
    "confidence": 0.82,
}


class FakeResult:
    def __init__(self, text):
        self.completion_text = text


class FakeProvider:
    def __init__(self):
        self.calls = 0

    async def text_chat(self, prompt: str = "", system_prompt: str = "", **kwargs):
        self.calls += 1
        await asyncio.sleep(0.01)
        if "合并" in system_prompt or "合并为一份最终画像" in prompt:
            return FakeResult("```json\n" + json.dumps(PERSONA_JSON, ensure_ascii=False) + "\n```")
        # 故意包一层 markdown 围栏，验证兜底解析
        return FakeResult(
            "好的，以下是分析结果：\n```json\n"
            + json.dumps(PERSONA_JSON, ensure_ascii=False)
            + "\n```"
        )


class FakeContext:
    def __init__(self, platform):
        self.platform_manager = FakePlatformManager(platform)
        self._provider = FakeProvider()
        self.registered: list[str] = []

    def get_using_provider(self, *a, **k):
        return self._provider

    def get_provider_by_id(self, provider_id=None):
        return self._provider

    def register_web_api(self, path, handler, methods, desc):
        self.registered.append(path)


class FakeConfig(dict):
    def __init__(self, base: dict):
        super().__init__(base)
        self.saved = False

    def save_config(self):
        self.saved = True


# ---------------------------------------------------------------------- #
#  测试主体
# ---------------------------------------------------------------------- #
async def main() -> int:
    import logging
    logging.basicConfig(level=logging.WARNING)

    # 干净的数据目录（与运行时一致：data/plugin_data/<plugin_name>）
    data_dir = HERE / "data" / "plugin_data" / "astrbot_plugin_group_active_distiller"
    if data_dir.exists():
        shutil.rmtree(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)

    schema = json.loads((HERE / "_conf_schema.json").read_text(encoding="utf-8"))
    conf = {k: v.get("default") for k, v in schema.items()}
    conf.update({
        "llm_batch_size": 40,          # 小批量，快
        "llm_max_batches": 3,
        "llm_batch_overlap": 4,
        "default_fetch_count": 400,
        "incremental_fetch_count": 200,
        "fetch_page_interval_ms": 0,   # 测试不 sleep
        "auto_distill_min_messages": 10,
        "recent_sample_window_days": 0,
        "llm_retry_times": 1,
        "llm_timeout_seconds": 30,
        "discover_keywords": ["测试群"],
    })
    config = FakeConfig(conf)

    client = FakeOneBotClient({"123456": 400, "654321": 300})
    platform = FakePlatform(client)
    context = FakeContext(platform)

    from core.store import DistillerStore
    from core.collector import GroupCollector
    from core.distiller import PersonaDistiller, extract_json, normalize_persona
    from core.prompts import render_system_prompt

    store = DistillerStore(str(data_dir / "distiller.db"))
    await store.init()

    logs: list[str] = []

    async def log(scope, message, level="info"):
        logs.append(f"[{level}][{scope}] {message}")
        await store.log(scope, message, level)

    collector = GroupCollector(context, config, store, log=log)
    distiller = PersonaDistiller(context, config, store, log=log)

    ok = True

    def check(name, cond, extra=""):
        nonlocal ok
        mark = "PASS" if cond else "FAIL"
        if not cond:
            ok = False
        print(f"  [{mark}] {name} {extra}")
        return cond

    print("\n=== 1. 单元：JSON 兜底解析 ===")
    check("围栏解析", extract_json('```json\n{"a":1}\n```') == {"a": 1})
    check("前缀噪声", extract_json('分析如下：{"a":2} 以上') == {"a": 2})
    check("纯 JSON", extract_json('{"a":3}') == {"a": 3})
    check("非法返回 None", extract_json("完全不是 json") is None)
    check("嵌套字符串括号", extract_json('{"a":"}inside{"}') == {"a": "}inside{"})

    print("\n=== 2. 单元：人设归一化 ===")
    norm = normalize_persona(PERSONA_JSON, nickname="测试员")
    check("nickname 覆盖", norm["nickname"] == "测试员")
    check("confidence 夹取", 0 <= norm["confidence"] <= 1)
    empty = normalize_persona({}, nickname="空")
    check("空输入结构完整", all(k in empty for k in
        ("personality", "speaking_style", "catchphrases", "vocabulary",
         "sticker_habit", "interaction_style", "scenario_examples", "avoid")))

    print("\n=== 3. 采集：搜群 ===")
    groups = await collector.search_groups("测试群")
    check("搜到群数", len(groups) == 2, f"got={len(groups)}")
    await collector.register_groups(groups)
    db_groups = await store.list_groups()
    check("入库群数", len(db_groups) == 2, f"got={len(db_groups)}")

    print("\n=== 4. 采集：拉历史（全量） ===")
    res = await collector.collect_group("123456", count=400, full=True)
    check("拉取条数 > 0", res["fetched"] > 0, f"fetched={res['fetched']}")
    check("入库条数 > 0", res["inserted"] > 0, f"inserted={res['inserted']}")
    total = await store.count_messages("123456")
    check("库内消息数一致", total == res["inserted"], f"db={total}")

    print("\n=== 5. 采集：增量（去重生效） ===")
    res2 = await collector.collect_group("123456")
    after = await store.count_messages("123456")
    check("增量不重复入库", after == total, f"before={total} after={after}")
    check("增量确实拉了数据", res2["fetched"] >= 0, f"fetched={res2['fetched']}")

    print("\n=== 6. 消息解析：表情包 / at / reply 被记录 ===")
    msgs = await store.fetch_messages("123456", limit=500)
    has_sticker = any("[表情包:" in (m.get("text") or "") for m in msgs)
    has_at = any("@" in (m.get("text") or "") for m in msgs)
    has_face = any("[表情:" in (m.get("text") or "") for m in msgs)
    check("识别到表情包段", has_sticker)
    check("识别到 @ 段", has_at)
    check("识别到小黄脸", has_face)

    print("\n=== 7. 群友统计 ===")
    users = await store.list_users("123456", limit=20, min_count=1)
    check("有群友统计", len(users) > 0, f"got={len(users)}")
    check("长尾用户 99999 在列", any(u["user_id"] == "99999" for u in users))

    print("\n=== 8. 蒸馏：单人（分批 + 合并 + 兜底解析） ===")
    job_id = await store.create_job("123456", "10001")
    out = await distiller.distill_user("123456", "10001", job_id=job_id)
    check("版本号 = 1", out["version"] == 1)
    check("批次 > 0", out["batch_total"] > 0, f"batches={out['batch_total']}")
    check("置信度有效", 0 < float(out["confidence"]) <= 1, f"conf={out['confidence']}")
    check("system_prompt 非空", len(out["system_prompt"]) > 200, f"len={len(out['system_prompt'])}")
    check("prompt 含说话习惯", "说话方式" in out["system_prompt"])
    check("prompt 含表情包习惯", "表情包习惯" in out["system_prompt"])
    check("prompt 含口头禅", "笑死 根本笑不死" in out["system_prompt"])
    jobs = await store.list_jobs(limit=5)
    check("任务标记 done", jobs[0]["status"] == "done", f"status={jobs[0]['status']}")

    print("\n=== 9. 蒸馏：再跑一次 → 版本递增 ===")
    out2 = await distiller.distill_user("123456", "10001")
    check("版本号 = 2", out2["version"] == 2, f"got={out2['version']}")
    vers = await store.persona_versions("123456", "10001")
    check("版本历史 2 条", len(vers) == 2, f"got={len(vers)}")

    print("\n=== 10. 蒸馏：批量 Top N ===")
    batch = await distiller.distill_batch("123456", top_n=2, min_messages=5)
    check("批量成功数 > 0", any("error" not in r for r in batch), f"n={len(batch)}")

    print("\n=== 11. 查询：画像 / 表情包 ===")
    latest = await store.get_persona("123456", "10001")
    v_now = await store.persona_versions("123456", "10001")
    newest = max((v.get("version") or 0) for v in v_now) if v_now else 0
    check("取到最新画像", latest is not None and latest["version"] == newest,
          f"latest={latest['version'] if latest else None} newest={newest}")
    check("persona 是 dict", isinstance(latest.get("persona"), dict))
    st = await store.stickers("123456", "10001", limit=10)
    check("表情包统计非空", len(st) > 0, f"got={len(st)}")

    print("\n=== 12. 总览统计 ===")
    ov = await store.overview()
    check("overview 字段齐全",
          all(k in ov for k in ("groups", "messages", "users", "personas")), str(ov))

    print("\n=== 13. 日志落库 ===")
    recent = await store.recent_logs(50)
    check("有日志", len(recent) > 0, f"got={len(recent)}")
    await store.log("测试", "手动写入一条", "info")
    check("日志可写", len(await store.recent_logs(10)) > 0)

    print("\n=== 14. 群标记开关 ===")
    await store.set_group_flag("123456", "auto_collect", 0)
    g = await store.get_group("123456")
    check("关闭自动采集", int(g["auto_collect"]) == 0)
    await store.set_group_flag("123456", "auto_collect", 1)

    # ================= 以下为「按 QQ 号」跨群链路 ================= #
    print("\n=== 15. 跨群：查某 QQ 出现在哪些群 ===")
    rows = await store.user_groups("10001", min_count=1)
    check("跨群命中 >= 1 个群", len(rows) >= 1, f"got={len(rows)}")
    total_local = await store.count_user_messages("10001")
    check("跨群消息总数 > 0", total_local > 0, f"got={total_local}")
    check(
        "每条都带群名",
        all("group_name" in r for r in rows),
        f"keys={sorted(rows[0].keys())[:6] if rows else None}",
    )

    print("\n=== 16. 跨群：主动扫描并采集该 QQ 的全部记录 ===")
    info = await distiller.collect_user_everywhere("10002", collector=collector)
    check("扫描了群", info["groups_scanned"] >= 1, f"scanned={info['groups_scanned']}")
    check("命中的群 >= 1", info["groups_hit"] >= 1, f"hit={info['groups_hit']}")
    check("该 QQ 有消息", info["total_messages"] > 0, f"total={info['total_messages']}")
    check(
        "detail 带每群条数",
        all("messages" in d for d in info["detail"]),
        f"n={len(info['detail'])}",
    )

    print("\n=== 17. 跨群：合并语料（含上下文） ===")
    global_msgs = await store.fetch_user_messages_global("10002", limit=100000)
    check("跨群取出该 QQ 消息", len(global_msgs) > 0, f"got={len(global_msgs)}")
    check(
        "按时间正序",
        all(
            (global_msgs[i]["time"] or 0) <= (global_msgs[i + 1]["time"] or 0)
            for i in range(len(global_msgs) - 1)
        ),
    )
    check("只含目标 QQ", all(m["user_id"] == "10002" for m in global_msgs))
    ctx = await store.fetch_context_global("10002", limit=800)
    check("上下文条数 >= 目标消息", len(ctx) >= len(global_msgs), f"ctx={len(ctx)}")
    check("上下文含他人发言", any(m["user_id"] != "10002" for m in ctx))

    print("\n=== 18. 跨群：一次蒸馏（只给 QQ 号） ===")
    job = await store.create_job("*global*", "10002")
    out = await distiller.distill_user_global(
        "10002", collector=collector, collect=True, job_id=job
    )
    check("group_id 标记为 *global*", out["group_id"] == "*global*")
    check("版本号 >= 1", out["version"] >= 1, f"v={out['version']}")
    check("批次 > 0", out["batch_total"] > 0, f"batches={out['batch_total']}")
    check("素材条数 > 0", out["sample_count"] > 0, f"n={out['sample_count']}")
    check("覆盖群数 >= 1", out["groups_hit"] >= 1, f"hit={out['groups_hit']}")
    check("人设带 source_groups", bool(out["persona"].get("source_groups")))
    check("置信度有效", 0 < float(out["confidence"]) <= 1, f"conf={out['confidence']}")
    check("system_prompt 非空", len(out["system_prompt"]) > 200, f"len={len(out['system_prompt'])}")
    jobs_now = await store.list_jobs(limit=5)
    done_jobs = [j for j in jobs_now if j["group_id"] == "*global*"]
    check("跨群任务落库", len(done_jobs) >= 1, f"n={len(done_jobs)}")
    check("跨群任务状态", done_jobs[0]["status"] == "done", f"status={done_jobs[0]['status']}")

    print("\n=== 19. 跨群：不采集只蒸馏本地数据 ===")
    out2 = await distiller.distill_user_global("10002", collector=None, collect=False)
    check("无采集也能出结果", out2["version"] == out["version"] + 1, f"v={out2['version']}")
    vers2 = await store.persona_versions("*global*", "10002")
    check("跨群版本历史 >= 2", len(vers2) >= 2, f"got={len(vers2)}")

    print("\n=== 20. 跨群：未知 QQ 应报错而不是崩 ===")
    raised = False
    try:
        await distiller.distill_user_global("10099", collector=None, collect=False)
    except Exception as exc:
        raised = "没有" in str(exc) or "消息" in str(exc)
    check("未知 QQ 抛可读错误", raised)

    print("\n=== 21. 跨群：画像可被查询到 ===")
    gp = await store.get_persona("*global*", "10002")
    check("取到跨群画像", gp is not None and gp["version"] == out2["version"],
          f"v={gp['version'] if gp else None}")
    gpv = await store.get_persona("*global*", "10002", out["version"])
    check("能取指定旧版本", gpv is not None and gpv["version"] == out["version"],
          f"want_v={out['version']} got={gpv['version'] if gpv else None}")
    lst = await store.list_personas(user_id="10002")
    check("画像列表含跨群版本", any(r["group_id"] == "*global*" for r in lst))

    # ============ 以下为「用户 7 条诉求」逐条验收 ============ #
    print("\n=== 22. 【诉求2】全量分批：0 = 不截断，覆盖所有素材 ===")
    all_msgs = await store.fetch_user_messages_global("10001", limit=100000)
    n_target = len(all_msgs)
    ctx_all = await store.fetch_context_global("10001", limit=100000)
    full_batches, full_chars = distiller.sample_lines(
        ctx_all, "10001", batch_size=40, overlap=4,
        max_batches=0, char_limit=0,
    )
    lim_batches, lim_chars = distiller.sample_lines(
        ctx_all, "10001", batch_size=40, overlap=4,
        max_batches=2, char_limit=0,
    )
    check("0 = 不限批数，批次数 > 上限值", len(full_batches) > 2,
          f"full={len(full_batches)} limited={len(lim_batches)}")
    check("不限时字数 >= 限批时字数", full_chars >= lim_chars,
          f"full={full_chars} limited={lim_chars}")
    flat = [ln for b in full_batches for ln in b]
    hit_batches = sum(1 for b in full_batches if any("▶" in ln for ln in b))
    check("每个批次都含目标 QQ 的发言（▶ 标记）",
          hit_batches == len(full_batches) and len(full_batches) > 0,
          f"hit={hit_batches}/{len(full_batches)} lines={len(flat)}")
    # 尾段必须被覆盖：最后一条目标发言要出现在最后一批里
    last_target = [m for m in ctx_all if m["user_id"] == "10001"][-1]
    tail_hit = any(str(last_target["message_id"])[:0] == "" and
                   (last_target.get("text") or "")[:6] in ln
                   for ln in full_batches[-1])
    check("最后一段素材被喂进最后一批", tail_hit, f"last_batch_lines={len(full_batches[-1])}")
    check("批次数覆盖度 > 0.8", len(full_batches) >= max(1, (n_target // 40) * 0.8),
          f"batches={len(full_batches)} target={n_target}")

    print("\n=== 23. 【诉求2】配置默认值 = 全部 ===")
    raw_schema = json.loads((HERE / "_conf_schema.json").read_text(encoding="utf-8"))
    check("llm_max_batches 默认 0（不限）",
          int(raw_schema["llm_max_batches"]["default"]) == 0,
          f'default={raw_schema["llm_max_batches"]["default"]}')
    check("llm_sample_char_limit 默认 0（不截断）",
          int(raw_schema["llm_sample_char_limit"]["default"]) == 0,
          f'default={raw_schema["llm_sample_char_limit"]["default"]}')
    check("recent_sample_window_days 默认 0（不限时间）",
          int(raw_schema["recent_sample_window_days"]["default"]) == 0)

    print("\n=== 24. 【诉求3】进度实时：job_steps + 阶段 + ETA ===")
    prog_job = await store.create_job("*global*", "10001")
    phases: list[dict] = []

    async def on_prog(**kw):
        phases.append(kw)
        # 模拟 main._bg_track 里对 job 的实时写入
        if kw.get("phase") in {"listing", "scanning", "local"}:
            tot = int(kw.get("total") or 0) or 1
            await store.update_job(
                prog_job, status="running", stage=f"跨群采集 {kw.get('index')}/{tot}",
                progress=min(40, int(int(kw.get("index") or 0) * 40 / tot)),
            )
        elif kw.get("phase") == "batches":
            tot = int(kw.get("total") or 0) or 1
            await store.update_job(
                prog_job, status="running", stage=f"分批分析 {kw.get('index')}/{tot}",
                progress=min(90, 45 + int(int(kw.get("index") or 0) * 45 / tot)),
                batch_done=int(kw.get("index") or 0), batch_total=tot,
            )

    step_collect = await store.add_step(prog_job, "跨群采集", total=2)
    await store.update_step(step_collect, done=1, detail="群 1 命中 30 条")
    step_batch = await store.add_step(prog_job, "分批喂 LLM", total=3)
    await store.update_step(step_batch, done=2, detail="已分析 2/3 批")

    mid_job = await store.get_job(prog_job)
    steps_now = await store.list_steps(prog_job)
    # 先模拟 on_progress 真实推一次进度，再断言状态会从 queued 变 running
    await on_prog(phase="scanning", index=1, total=2, group_id="123456", messages=30)
    await on_prog(phase="batches", index=2, total=3)
    live_job = await store.get_job(prog_job)
    check("job 可实时读到 running", live_job["status"] == "running",
          f'status={live_job["status"]}')
    check("进度回调确实推进了 progress", int(live_job["progress"] or 0) > 0,
          f'progress={live_job["progress"]}')
    check("回调写入 stage 文案", "分批分析" in (live_job["stage"] or ""),
          f'stage={live_job["stage"]}')
    check("回调记录 batch_done/total",
          int(live_job["batch_done"] or 0) == 2 and int(live_job["batch_total"] or 0) == 3,
          f'done={live_job["batch_done"]} total={live_job["batch_total"]}')
    check("阶段明细有 2 条", len(steps_now) == 2, f"got={len(steps_now)}")
    check("阶段明细带 done/total",
          steps_now[0]["done"] == 1 and steps_now[0]["total"] == 2, str(steps_now[0]))
    check("阶段明细带 detail", "命中" in (steps_now[0]["detail"] or ""))
    check("阶段按 seq 递增", steps_now[0]["seq"] < steps_now[1]["seq"])

    # 进度必须真的会动（不是卡在 0）
    before = int(mid_job["progress"] or 0)
    await store.update_job(prog_job, progress=72, stage="分批分析 2/3")
    after = int((await store.get_job(prog_job))["progress"] or 0)
    check("进度可推进（不卡 0%）", after > before, f"before={before} after={after}")

    # ETA 计算（与 main.api_job_detail 同算法）
    await store._run(  # noqa: SLF001  直接改 created_at 方便算 ETA
        lambda c, jid: c.execute(
            "UPDATE distill_jobs SET created_at=? WHERE id=?",
            (int(time.time()) - 100, jid),
        ),
        prog_job,
    )
    dj = await store.get_job(prog_job)
    elapsed = max(1, int(dj["updated_at"]) - int(dj["created_at"]))
    prog = float(dj["progress"])
    eta = int(elapsed * (100 - prog) / prog) if prog > 3 else None
    check("ETA 能算出正数秒", eta is not None and eta > 0, f"eta={eta}s prog={prog}")
    check("预计耗时 = int(elapsed*(100-progress)/progress)",
          eta == int(elapsed * (100 - prog) / prog), f"eta={eta}")

    await store.finish_step(step_batch, detail="完成")
    await store.update_job(prog_job, status="done", progress=100, stage="完成")
    check("任务可置为 done", (await store.get_job(prog_job))["status"] == "done")

    print("\n=== 25. 【诉求3】取消任务 ===")
    cjob = await store.create_job("*global*", "10003")
    await store.cancel_job(cjob)
    check("取消后状态 canceled", (await store.get_job(cjob))["status"] == "canceled")
    check("is_job_canceled 为真", await store.is_job_canceled(cjob))

    print("\n=== 26. 【诉求4】群管理一键全选 / 批量开关 ===")
    n_all = await store.set_all_group_flags("auto_collect", 1)
    gs1 = await store.list_groups()
    check("批量开启自动采集生效", n_all >= 2 and all(int(g["auto_collect"]) == 1 for g in gs1),
          f"n={n_all}")
    n_off = await store.set_all_group_flags("auto_collect", 0)
    gs2 = await store.list_groups()
    check("批量关闭自动采集生效", n_off >= 2 and all(int(g["auto_collect"]) == 0 for g in gs2),
          f"n={n_off}")
    n_sel = await store.set_all_group_flags("auto_distill", 1, ["123456"])
    g_one = await store.get_group("123456")
    check("只对选中的群生效", n_sel == 1 and int(g_one["auto_distill"]) == 1, f"n={n_sel}")

    print("\n=== 27. 【诉求8】群覆盖勾选 → 批量蒸馏 ===")
    await store.set_all_group_flags("auto_collect", 1)
    picked = ["123456", "654321"]
    gd = await distiller.distill_selected_groups(
        picked, top_n=1, min_messages=1, job_id=await store.create_job("groups:2", "groups:2"),
    )
    check("返回处理了 2 个群", gd["groups"] == 2, f'groups={gd["groups"]}')
    check("至少成功蒸馏 1 人", gd["distilled"] >= 1, f'distilled={gd["distilled"]}')
    check("detail 带每个群的群号",
          all("group_id" in d for d in gd["detail"]), f'n={len(gd["detail"])}')
    check("选中的群确实被蒸过",
          {d["group_id"] for d in gd["detail"]} == set(picked),
          f'set={sorted({d["group_id"] for d in gd["detail"]})}')

    print("\n=== 28. 【诉求1】蒸馏完画像在按 QQ 号页面可见 ===")
    gp2 = await store.get_persona("*global*", "10002")
    check("跨群画像可按 *global* 取到", gp2 is not None)
    check("画像含 system_prompt", bool(gp2 and gp2.get("system_prompt")))
    check("画像 persona 可 JSON 化",
          isinstance(gp2.get("persona"), dict) and bool(json.dumps(gp2["persona"], ensure_ascii=False)))
    vers_pg = await store.persona_versions("*global*", "10002")
    check("版本下拉数据 >= 2 条", len(vers_pg) >= 2, f"got={len(vers_pg)}")
    check("版本项带 version/sample_count/created_at",
          all(k in vers_pg[0] for k in ("version", "sample_count", "created_at")),
          f'keys={sorted(vers_pg[0].keys())}')

    print("\n=== 29. 【诉求5】自己的数据库：统计 / 清理 / VACUUM ===")
    dstats = await store.db_stats()
    check("db_stats 有文件大小", int(dstats["file_size"]) > 0, f'size={dstats["file_size"]}')
    check("db_stats 有表清单", len(dstats["tables"]) >= 7, f'n={len(dstats["tables"])}')
    tnames = {t["table"] for t in dstats["tables"]}
    check("表清单含 messages/personas/job_steps",
          {"messages", "personas", "job_steps"} <= tnames, str(sorted(tnames)))
    check("db_stats 有 path", bool(dstats.get("path")))

    pr_logs = await store.prune("logs")
    check("清理日志有删除行数", pr_logs.get("logs", 0) >= 0, str(pr_logs))
    check("清理后日志变少", len(await store.recent_logs(10)) <= 2,
          f'left={len(await store.recent_logs(10))}')

    pr_jobs = await store.prune("jobs")
    left_jobs = await store.list_jobs(limit=200)
    check("清理任务后只剩运行中的", all(j["status"] in ("queued", "running") for j in left_jobs),
          f'n={len(left_jobs)}')

    bad_scope = False
    try:
        await store.prune("不存在的范围")
    except Exception:
        bad_scope = True
    check("未知清理范围报错而不是静默", bad_scope)

    vin = await store.vacuum()
    check("VACUUM 返回前后大小", "before" in vin and "after" in vin, str(vin))
    check("VACUUM 后文件可读", Path(dstats["path"]).exists()
          if dstats.get("path") else True)
    opt = await store.optimize()
    check("optimize 不抛错", opt is None or isinstance(opt, dict))

    print("\n=== 30. 【诉求7】表情包榜 / 画像列表页已删除 ===")
    main_src = (HERE / "main.py").read_text(encoding="utf-8")
    js_src = (HERE / "pages" / "蒸馏台" / "app.js").read_text(encoding="utf-8")
    html_src = (HERE / "pages" / "蒸馏台" / "index.html").read_text(encoding="utf-8")
    check("main.py 无 api_stickers", "async def api_stickers" not in main_src)
    check("前端不再调用 /stickers", '"/stickers"' not in js_src)
    check("HTML 无表情包榜页签", "panelSticker" not in html_src)
    check("HTML 无画像列表页签", "panelPersona" not in html_src)
    check("HTML 无群友排行页签", "panelUsers" not in html_src)
    check("路由表已去掉 /stickers", '"/stickers"' not in main_src)

    print("\n=== 31. 前端 / 后端接口一致性 ===")
    import re as _re
    routes = set(_re.findall(r'\("(/[a-z/]+)",\s*self\.api_', main_src))
    called = set(_re.findall(r'api(?:Get|Post)\(\s*"([^"]+)"', js_src))
    check("前端调用的接口后端都有",
          not (called - routes), f"missing={sorted(called - routes)}")
    check("前端用到 /jobs/detail（实时进度）", "/jobs/detail" in called)
    check("前端用到 /groups/bulk（批量开关）", "/groups/bulk" in called)
    check("前端用到 /groups/distill（勾选群蒸）", "/groups/distill" in called)
    check("前端用到 /db/prune（一键清理）", "/db/prune" in called)
    check("前端用到 /db/vacuum（VACUUM）", "/db/vacuum" in called)
    check("前端轮询 2s", "2000" in js_src)
    # DOM id 必须都存在于 HTML
    used_ids = set(_re.findall(r'\$\("#([A-Za-z][A-Za-z0-9_]*)"\)', js_src))
    html_ids = set(_re.findall(r'id="([A-Za-z][A-Za-z0-9_]*)"', html_src))
    check("JS 引用的 DOM id 全部存在",
          not (used_ids - html_ids), f"missing={sorted(used_ids - html_ids)}")
    check("进度卡片存在", "trackProgressCard" in html_ids and "tpBar" in html_ids)
    check("ETA 元素存在", "tpEta" in html_ids)
    check("全选元素存在（群覆盖表）", "trkAll" in html_ids)
    check("全选元素存在（群管理）", "groupAll" in html_ids)
    check("数据库页存在", "panelDb" in html_ids and "btnPrune" in html_ids)
    check("画像结果卡片在按QQ号页面",
          'id="trackPersonaCard"' in html_src and 'id="panelTrack"' in html_src)

    await store.close()

    print("\n" + "=" * 60)
    print("日志样本（最后 12 条）：")
    for line in logs[-12:]:
        print("  " + line)
    print("=" * 60)
    print(("✅ 全部通过" if ok else "❌ 存在失败项"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
